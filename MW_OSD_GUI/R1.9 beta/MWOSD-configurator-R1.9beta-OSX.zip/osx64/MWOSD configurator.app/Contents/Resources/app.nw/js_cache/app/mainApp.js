MainApp = function () {
	/* -------  SETTINGS -------- */
	this.versionmin = 15; // Min version supported - e.g. 12 for 1.6 eeprom layout
	this.versionmax = 16; // Max version supported - e.g. 15 for 1.8 eeprom layout

    var _this = this;

    this.mcmList = new McmList($('#mcmList'), McmEnum);
	this.startConnectionTimer = null;
    this.connectionMode = connectionMode.NORMAL;
	/* -------  PROPERTIES -------- */
	this.protocol = new Protocol(chrome.serial);
	this.guiModel = new GuiModel();
	this.scenario = new Scenario();
	this.livePreview = new ScreenResolutionEditor($('#main_screen'), 'pal', 'image/osd.jpg', new ScreenControl($('#main_screen_control')));
	this.emulator = new Emulator($('#emulator'));
	this.log = new Log($('#log'));

    this.versionManager = new VersionAppBuilder(this.livePreview, this.guiModel);

    this.presetControl = new PresetControl($('#preset_control'), 'settings/preset/presetArray-V1.json');

	this.screenFontsMap = new FontMap(null);
	this.indexFramesToWrite = 0;
	this.countWriteFailed = 0;
	this.protocol = new Protocol(chrome.serial);
	this.framesToWrite = [];
	this.senzorInterval = null;
    this.connectionWidget = new FormConnect();

    this.hexListUrl = 'https://api.github.com/repos/ShikOfTheRa/scarab-osd/releases';
    this.maxHexSize = 30720; // in dec p328 has 32KB memmory but we have to protect bootloader in last two kilobytes
    //this.maxHexSize = 20000; for test
    this.flashFw = new FlashFw(this.connectionWidget.ports, this.log, this.maxHexSize, this.hexListUrl);

	$('#saveSettingsToDisk').button();
	$('#loadSettingsFromDisk').button();

	this.guiModel.showAppVersion($('#manifest_app_version'));

	$("#tabs").tabs({ activate: function(event ,ui){
        tracker.sendAppView(ui.newTab.attr('li',"innerHTML")[0].getElementsByTagName("a")[0].innerHTML);
    } });

	/* -------  ------- -------- */

    this.flashFw.changeBaudRate = function(baud){
		_this.connectionWidget.changeBaudRate(baud);
        _this.log.addTextError('Baud was changed, PX4/Mavlink was selected');
        $.toast({
            text: 'Baud was changed to ' + baud,
            position: 'down-right',
            icon: 'info'
        });
	};

	this.protocol.handleChangeState = function (state) {
		_this.connectionWidget.changeState(state);

		if (state == _this.protocol.stateList.CONNECTED) {
			clearTimeout(_this.startConnectionTimer);
			_this.startConnectionTimer = setTimeout(function(){
                if(_this.connectionMode == connectionMode.NORMAL){
                    _this.log.addTextSuccess('Connected');
                    _this.startConnection();
                }else{
                    console.log('try set cli');
                    _this.setCliMode();
                }
			}, 1000);

		}

		if (state == _this.protocol.stateList.DISCONECTED) {
            clearTimeout(_this.startConnectionTimer);
            _this.log.addTextError('Disconnected');
			_this.scenario.setScenario(_this.scenario.scenarioList.IDDLE);
			clearInterval(_this.senzorInterval);
            _this.livePreview.setValue('ArmedStatus', 311);
            _this.guiModel.resetInfo();
		}

	};

    this.protocol.handleReceiveCliMode = function (state) {
        if(state){
            _this.log.addText('Cli mode was set');
            _this.protocol.setPassThrough();
        }else{
            _this.log.addTextError('Cli mode FAIL');
            _this.protocol.disconect();
        }
    };

    this.protocol.handleReceivePassthrouMode = function (state) {
        if(state){
            _this.log.addText('Passthrought was set');
			_this.startConnection();
        }else{
            _this.log.addTextError('Set passthrought Fail');
            _this.protocol.disconect();
        }
    };

	/* -------  HANDLES -------- */
    this.emulator.handleChangeValue = function (name, value) {
    	switch (name)
		{
			case 'armed':
                _this.livePreview.setValue('ArmedStatus', _this.protocol.getState() == _this.protocol.stateList.CONNECTED ? (value ? 313 : 312) : 311);
				break;
		}

    };


	this.protocol.handleListDevices = function (ports) {
		_this.connectionWidget.setPorts(ports);
	};

	this.protocol.handleReceiveFrame = function (frame) {
		if (_this.protocol.getState() == _this.protocol.stateList.CONNECTED) {
			//find out non cycle command
			if (frame) {
				switch (frame.command) {
					case  _this.protocol.commandList.OSD_SENSORS:
						ProfileStorageGlobal.setSenzorsFrameValue(frame);
						break;
                    case  _this.protocol.commandList.OSD_INFO:
                        ProfileStorageGlobal.setInfoFrameValue(frame);
                        break;
				}
			}

			//read write, because read write is cyrcle
			if (_this.scenario.getScenario() == _this.scenario.scenarioList.READ_EE) {
				if (frame && frame.command == _this.protocol.commandList.OSD_READ_CMD_EE) {
                    ProfileStorageGlobal.setReadWriteFrameValue(frame);
				}

				var needAddress = ProfileStorageGlobal.getOneAdressWhatYouNeed();
				if (needAddress !== false) {
					_this.protocol.requestForEE(needAddress);
				} else {
                    _this.livePreview.setValue('ArmedStatus', _this.emulator.elements.MODEarmed.getValue() ? 313 : 312);
					_this.scenario.setScenario(_this.scenario.scenarioList.IDDLE);

					_this.checkVersion(ProfileStorageGlobal.getMainProfile()[0].values);


				}
			} else if (_this.scenario.getScenario() == _this.scenario.scenarioList.WRITE_EE) {
				if (frame && frame.command == _this.protocol.commandList.OSD_READ_CMD_EE) { // because frame from write has same code as read this.commandList.OSD_READ_CMD_EE, this is from mw_osd :(
					_this.indexFramesToWrite = frame.specialValues.nextaddress == 0 ? 0 : (frame.specialValues.nextaddress / 10);
					_this.guiModel.setModeWriteToOsd();
					_this.guiModel.setProgress(_this.indexFramesToWrite, _this.framesToWrite.length);
                    _this.countWriteFailed = 0;
				}
				else
				{
                    _this.countWriteFailed++;
				}

				if(_this.countWriteFailed == 16){ // failed count
                    $.toast({
                        text: 'Write failed',
                        position: 'top-right',
                        icon: 'error'
                    });
                    _this.framesToWrite = [];
                    _this.scenario.setScenario(_this.scenario.scenarioList.IDDLE);
                    _this.formMenu.handleReadFromOsd();
                    _this.countWriteFailed = 0;
				}

				if (_this.indexFramesToWrite < _this.framesToWrite.length) {
					console.timeEnd();
                    console.time();
					_this.protocol.requestForWriteEE(_this.framesToWrite[_this.indexFramesToWrite]);
				} else {
					_this.framesToWrite = [];
					_this.scenario.setScenario(_this.scenario.scenarioList.IDDLE);
					_this.formMenu.handleReadFromOsd();
                    _this.countWriteFailed = 0;
				}
			}
		}
	};


	/* -------  FormConnect -------- */
	this.connectionWidget.connectToNode($('#connection-widget'));
	this.connectionWidget.handleSubmit = function (values) {
		if (_this.protocol.getState() == _this.protocol._serialConnector.stateList.DISCONECTED) {
			_this.log.addText('Connecting');
			_this.connectionMode = values.passthroughEnable ? connectionMode.PASSTHROUGH : connectionMode.NORMAL;
			_this.protocol.connect(values.port, values.baudRate, values.passthroughPort);
		} else if (_this.protocol.getState() == _this.protocol._serialConnector.stateList.CONNECTED) {
			_this.log.addText('Disconnecting');
			_this.protocol.disconect();
		}
	};

	this.connectionWidget.handleFlash = function (port) {
		if(!port){
			$.toast({
				text: 'No selected port',
				position: 'top-right',
				icon: 'error'
			});
			return;
		}


		if (_this.protocol.getState() == _this.protocol._serialConnector.stateList.DISCONECTED) {
			$('#flashFWDialog').dialog('open')
		} else {
			$.toast({
				text: 'Device must be disconected',
				position: 'top-right',
				icon: 'error'
			});
		}
	};

	this.protocol.handleConnectionFailed = function (msg) {
		$('#info-dialog-text').text('Cant connect to device');
		$('#info-dialog').dialog(
			{
				title: 'Connection problem',
				buttons: [
					{
						text: "OK",
						click: function () {
							$(this).dialog("close");
						}
					}
				]
			}
		);

		_this.log.addTextError('Cant connect to device');

		_this.scenario.setScenario(_this.scenario.scenarioList.IDDLE);
		clearInterval(_this.senzorInterval);
		_this.connectionWidget.changeState(_this.protocol.stateList.DISCONECTED);
	};

	/* -------  FormMenu -------- */
	this.formMenu = new FormMenu($('#menu-widget'));

	this.formMenu.handleReadFromOsd = function () {
		if (_this.protocol.getState() == _this.protocol.stateList.CONNECTED && _this.scenario.getScenario() == _this.scenario.scenarioList.IDDLE) {
            ProfileStorageGlobal.prepareToLoad();
			_this.scenario.setScenario(_this.scenario.scenarioList.READ_EE);
			_this.protocol.requestForEE(ProfileStorageGlobal.getOneAdressWhatYouNeed());
		} else {
			if (_this.protocol.getState() != _this.protocol.stateList.CONNECTED) {
				$.toast({
					text: 'You have to connect',
					position: 'top-right',
					icon: 'error'
				});
				_this.log.addText('You have to connect');
			} else {
				$.toast({
					text: 'Another task is in progress',
					position: 'top-right',
					icon: 'error'
				});
				_this.log.addTextError('Another task is in progress');
			}
		}
	};

	this.formMenu.handleWriteToOsd = function () {
		if (_this.protocol.getState() == _this.protocol.stateList.CONNECTED && _this.scenario.getScenario() == _this.scenario.scenarioList.IDDLE) {
			_this.indexFramesToWrite = 0;
            _this.countWriteFailed = 0;
			_this.framesToWrite = ProfileStorageGlobal._mainProfile;
			_this.scenario.setScenario(_this.scenario.scenarioList.WRITE_EE);
			_this.guiModel.setModeWaitingForOsd();
			_this.protocol.requestForWriteEE(_this.framesToWrite[_this.indexFramesToWrite]);
		} else {
			if (_this.protocol.getState() != _this.protocol.stateList.CONNECTED) {
				$.toast({
					text: 'You have to connect',
					position: 'top-right',
					icon: 'error'
				});
			} else {
				$.toast({
					text: 'Another task is in progress',
					position: 'top-right',
					icon: 'error'
				});
			}
		}
	};

	this.formMenu.handleDefault = function () {
		if (_this.protocol.getState() == _this.protocol.stateList.CONNECTED && _this.scenario.getScenario() == _this.scenario.scenarioList.IDDLE) {

			var areYouSure = new AreYouSure(function(){
					_this.scenario.setScenario(_this.scenario.scenarioList.DEFAULT);
					_this.guiModel.setModeWaitingForOsd();

					var counter = 3;
					var defaultInterval = setInterval(function () {
						if (counter > 3) {
							clearInterval(defaultInterval);
							_this.scenario.setScenario(_this.scenario.scenarioList.IDDLE);
							_this.formMenu.handleReadFromOsd();
						} else {
							_this.protocol.sendDefault();
							counter++;
						}

					}, 100);

					_this.protocol.sendDefault();

					$.toast({
						text: 'Unit was reset to default',
						position: 'top-right',
						icon: 'success'
					});
				},
				function(){
					console.log('cancel');
				}
			);

			areYouSure.show('Reset unit to default', 'Are you sure?');

		} else {
			if (_this.protocol.getState() != _this.protocol.stateList.CONNECTED) {
				$.toast({
					text: 'You have to connect',
					position: 'top-right',
					icon: 'error'
				});
			} else {
				$.toast({
					text: 'Another task is in progress',
					position: 'top-right',
					icon: 'error'
				});
			}
		}
	};

	this.formMenu.handleRestart = function () {
		if (_this.protocol.getState() == _this.protocol.stateList.CONNECTED && _this.scenario.getScenario() == _this.scenario.scenarioList.IDDLE) {
			_this.scenario.setScenario(_this.scenarioList.RESTART);
			_this.guiModel.setModeWaitingForOsd();

			var counter = 3;
			var defaultInterval = setInterval(function () {
				if (counter > 3) {
					clearInterval(defaultInterval);
					_this.scenario.setScenario(_this.scenario.scenarioList.IDDLE);
					_this.formMenu.handleReadFromOsd();
				} else {
					_this.protocol.sendRestart();
					counter++;
				}

			}, 100);

		} else {
			if (_this.protocol.getState() != _this.protocol.stateList.CONNECTED) {
				$.toast({
					text: 'You have to connect',
					position: 'top-right',
					icon: 'error'
				});
			} else {
				$.toast({
					text: 'Another task is in progress',
					position: 'top-right',
					icon: 'error'
				});
			}
		}
	};

    this.formMenu.handleLoadFont = function () {
        _this.loadFont();
    };

	/* -------  File dialog Edit Font -------- */
    this.editFontsButton = $('#fileDialogEditFont').dialog({
        autoOpen: false,
        width: 1160,
        height: 700,
        modal: true,
        resizable: false,
        close: function () {
            _this.screenFontsMap.setFontsData(_this.appStrips.fontsData());
            _this.livePreview.setNewFontMap();// after close dialog copy edited fonts data to livePreview preview
            _this.appLogoEditor.setNewFontMap(_this.screenFontsMap.getFontDataForEachElement([6,7,8,9,10,11]));
        }
    });

    this.editLogoButton = $('#fileDialogEditLogo').dialog({
        autoOpen: false,
        width: 1160,
        height: 800,
        modal: true,
        resizable: true,
		open: function(){
            ProfileStorageGlobal.changeMainProfile(function(profile){
                if(profile && profile[0] && profile[0] < 16){
                    $('#fileDialogEditLogo').dialog('close')
                }
            });
		},
        close: function () {
        	var fontsMap = _this.appLogoEditor.getFontsMap();
			for(var i = 0; i < fontsMap.length; i++){
                _this.screenFontsMap.setNewImageDataToIndex(6 + i, fontsMap[i]);
			}

            _this.livePreview.setNewFontMap();
            _this.appStrips.setNewFontData(_this.screenFontsMap.getFontData().replace('1', '0'));
        }
    });

	/* -------  File dialog load Font -------- */
    this.loadFontsButton = $('#loadFontDialog').dialog({
		title: 'Load Font',
        autoOpen: false,
        width: 700,
        height: 400,
        modal: true,
        resizable: true,
        close: function () {
        }
    });

    this.mcmList.loadFont = function (url) {
        _this.appStrips.loadDataByAjax(url, function () {
            _this.screenFontsMap.setFontsData(_this.appStrips.fontsData());
            _this.livePreview.setNewFontMap(_this.screenFontsMap);
            _this.appLogoEditor.setNewFontMap(_this.screenFontsMap.getFontDataForEachElement([6,7,8,9,10,11]));
            $.toast({
                text: 'MCM was loaded',
                position: 'top-right',
                icon: 'info'
            });
        });
    };

    this.mcmList.loadFontString = function (fondData) {
        _this.appStrips.loadDataFromString(fondData);
		_this.screenFontsMap.setFontsData(_this.appStrips.fontsData());
		_this.livePreview.setNewFontMap(_this.screenFontsMap);
		_this.appLogoEditor.setNewFontMap(_this.screenFontsMap.getFontDataForEachElement([6,7,8,9,10,11]));
		$.toast({
			text: 'MCM was loaded',
			position: 'top-right',
			icon: 'info'
		});
    };

	$('#saveSettingsToDisk').click(function(){

		var blobData = {
			profile:  ProfileStorageGlobal.getMainProfile()
		};

		var blob = new Blob([JSON.stringify(blobData)], {type: "application/json"});

		var downloadLink = $('<a>');
		downloadLink.attr('href', window.URL.createObjectURL(blob));
		downloadLink.attr('download', 'MWOSD-settings-' + (new Date().toISOString().slice(0, -5)) + '.json');
		downloadLink[0].click();

		$.toast({
			text: 'Settings file was saved to download folder',
			position: 'top-right',
			icon: 'info'
		});
		_this.log.addText('Settings file was saved to download folder');
	});

	$('#loadSettingsFromDisk').click(function(){
		chrome.fileSystem.chooseEntry(
			{
				type: 'openFile', accepts: [{
				extensions: ['json']
			}]
			},
			function (fileEntry) {
				if (chrome.runtime.lastError || !fileEntry) {
					console.log("User did not choose a file");
					return;
				}

				fileEntry.file(function (file) {
					var reader = new FileReader();
					reader.onload = function (e) {
						var parsed = JSON.parse(e.target.result);
						if(!parsed || !parsed.profile){
							$.toast({
								text: 'Unknow settings file',
								position: 'top-right',
								icon: 'error'
							});
							return false;
						}

                        if(!parsed.profile[0] || !parsed.profile[0].values){
                            $.toast({
                                text: 'Settings are broken'  ,
                                position: 'top-right',
                                icon: 'info'
                            });
                            _this.log.addText('Settings are broken');
                            return;
                        }


                       var infoValues = ProfileStorageGlobal.getInfoValues();
                       var currentVersion =  _this.versionmax;
                       if(infoValues){
                           currentVersion = infoValues
					   }

                       var result = ProfileMigrateGlobal.migrate(parsed.profile[0].values.values[0], currentVersion, parsed.profile);
                       parsed.profile = result.profile;

                       if(result.changeToVersion){
                           $.toast({
                               text: 'Loaded settings were migrate to version ' + result.changeToVersion + ', please check your settings',
                               position: 'top-right',
                               icon: 'info'
                           });

                           _this.log.addText('Loaded settings were migrate to version ' + result.changeToVersion + ', please check your settings');
                       }

                       ProfileStorageGlobal.setMainProfile(parsed.profile);

                        $.toast({
                            text: 'Settings was loaded',
                            position: 'top-right',
                            icon: 'info'
                        });
                        _this.log.addText('Settings was loaded');
					};
					reader.readAsText(file);
				});

			});
	});

	/* -------  File dialog load Font -------- */
	this.loadFWButton = $('#flashFWDialog').dialog({
		title: 'Firmware flasher',
		autoOpen: false,
		width: 800,
		height: 550,
		modal: true,
		resizable: false,
		closeOnEscape: false,
		open: function(){
			_this.flashFw.loadHexList();
		},
		close: function () {
		},
		beforeClose: function(){
			if(_this.flashFw.flashing){
				$.toast({
					text: 'Flashing is in progress',
					position: 'top-right',
					icon: 'error'
				});
				return false;
			}
		}
	});

	/* -------  Open Font editor -------- */
	this.formMenu.handleOpenFontEditor = function () {
		_this.editFontsButton.dialog('open');
	};

    /* -------  Open Logo editor -------- */
    this.formMenu.handleOpenLogoEditor = function () {
        _this.editLogoButton.dialog('open');
    };

	/* -------  Font write -------- */
	this.formMenu.handleWriteFont = function () {

		if (_this.protocol.getState() == _this.protocol.stateList.CONNECTED && _this.scenario.getScenario() == _this.scenario.scenarioList.IDDLE) {

			_this.scenario.setScenario(_this.scenario.scenarioList.WRITE_FONT);
			var fontData = _this.screenFontsMap.getFontData().replace("MAX7456", '').replace(new RegExp('\r?\n', 'g'), '');

			_this.guiModel.setModeWaitingForOsd();

			_this.protocol.sendFontUploadInit();

			var fontIndexToWrite = 0;
			var fontWriteInterval = setInterval(function () {
				if (fontIndexToWrite > 255 || _this.protocol.getState() != _this.protocol.stateList.CONNECTED) {
					clearInterval(fontWriteInterval);
					_this.scenario.setScenario(_this.scenario.scenarioList.IDDLE);
					return;
				}

				_this.guiModel.setModeWriteToOsd();
				_this.guiModel.setProgress(fontIndexToWrite + 1, 256);

				_this.protocol.sendChar(fontData.substr(fontIndexToWrite * 512, 512), fontIndexToWrite);
				fontIndexToWrite++;

			}, 105);

		} else {
			if (_this.protocol.getState() != _this.protocol.stateList.CONNECTED) {
				$.toast({
					text: 'You have to connect',
					position: 'top-right',
					icon: 'error'
				});
			} else {
				$.toast({
					text: 'Another task is in progress',
					position: 'top-right',
					icon: 'error'
				});
			}
		}
	};
	this.runEditStrips();
    this.runEditLogo();
};

/**
 *
 */
MainApp.prototype.run = function () {
    tracker.sendAppView('MWOSD');

    var _this = this;
    setInterval(function(){
        if(_this.protocol.getState() != _this.protocol.stateList.CONNECTED){
            _this.protocol.getDevices();
		}
	}, 500);
};

/**
 *
 * @type {{IDDLE: number, READ_EE: number, WRITE_EE: number, WRITE_FONT: number, DEFAULT: number, RESTART: number}}
 */
MainApp.prototype.scenarioList = {
	IDDLE: 0,
	READ_EE: 1,
	WRITE_EE: 2,
	WRITE_FONT: 3,
	DEFAULT: 4,
	RESTART: 5,
};

/**
 * edit font
 */
MainApp.prototype.runEditStrips = function () {
	var _this = this;
	this.appStrips = new AppStrips(); //create main app class
	this.appStrips.run(); // and run :)

	this.appStrips.loadDataByAjaxDefault(function () {
        _this.screenFontsMap.setFontsData(_this.appStrips.preview.getFontData());
        _this.appLogoEditor.setNewFontMap(_this.screenFontsMap.getFontDataForEachElement([6,7,8,9,10,11]));
		_this.livePreview.run(_this.screenFontsMap).then(function(){
            _this.versionManager.changeVersion(_this.versionmax, true)
		});
	}); // load max7456 fata file from url by ajax


	//load font file
	$('#load-mcm').click(
		function () {
			_this.loadFont();
		}
	);

    $('#load-from-file-mcm').click(
        function () {
            chrome.fileSystem.chooseEntry(
                {
                    type: 'openFile', accepts: [{
                        extensions: ['mcm']
                    }]
                },
                function (fileEntry) {
                    if (chrome.runtime.lastError || !fileEntry) {
                        console.log("User did not choose a file");
                        return;
                    }

                    fileEntry.file(function (file) {
                        var reader = new FileReader();
                        reader.onload = function (e) {
                            _this.appStrips.loadDataFromString(e.target.result);
                            _this.screenFontsMap.setFontsData(e.target.result);
                            _this.livePreview.setNewFontMap();
                        };
                        reader.readAsText(file);

                        $.toast({
                            text: 'MCM file loaded',
                            position: 'top-right',
                            icon: 'info'
                        });
                    });

                });
        }
    );

	//save font file
	$('#save-to-file-mcm').click(
		function () {
			var data = _this.appStrips.fontsData();
			chrome.fileSystem.chooseEntry({type: 'saveFile'},
				function (writableFileEntry) {
					if (writableFileEntry) {
						writableFileEntry.createWriter(function (writer) {
							writer.onwriteend = function (e) {
								$.toast({
									text: 'File saved',
									position: 'top-right',
									icon: 'success'
								});

								_this.log.addText('File saved');
							};

							writer.write(new Blob([data], {type: 'text/plain'}));
						}, function (e) {
						});
					}

				});
		}
	);

    //save font file
    $('#save-mcm').click(
        function () {
            var data = _this.appStrips.fontsData();
            chrome.storage.local.set({'user_mcm': data}, function () {
                $.toast({
                    text: 'User\'s font has been saved',
                    position: 'top-right',
                    icon: 'success'
                });

                _this.log.addText('User\'s font has been saved');

            });
        }
    );

    //load image
    $('#load-image-logo').click(
        function () {
            chrome.fileSystem.chooseEntry(
                {
                    type: 'openFile', accepts: [{
                        extensions: ['jpeg', 'jpg', 'png']
                    }]
                },
                function (fileEntry) {

                    if (chrome.runtime.lastError || !fileEntry) {
                        console.log("User did not choose a file");
                        return;
                    }

                    fileEntry.file(function (file) {
                        var url = URL.createObjectURL(file);
                        _this.appLogoEditor.loadImageByurl(url);
                    });

                });
        }
    );

};

/**
 * edit logo
 */
MainApp.prototype.runEditLogo = function () {
    this.appLogoEditor = new AppLogoEditor(); //create main app class
    this.appLogoEditor.run(); // and run :)
};

/**
 *
 * @param frame
 * @returns {boolean}
 */
MainApp.prototype.checkVersion = function (frame) {
    for (var address in frame.values) {

    	if ((address == 0 && frame.values[address] < this.versionmin) || (address == 0 && frame.values[address] > this.versionmax)) {
            if(this.protocol.getState() == this.protocol.CONNECTED){
                this.protocol.disconect();
            }

            if (address == 0 && frame.values[address] < this.versionmin) {
                $('#info-dialog-text').text('This GUI version does not support this OSD - an upgrade of your OSD firmware is required to operate with this GUI.');
            }
            else if (address == 0 && frame.values[address] > this.versionmax) {
                $('#info-dialog-text').text('This GUI version does not support this OSD - an upgrade of the GUI is required to operate with the firmware on this OSD.');
            }
            $('#info-dialog').dialog(
                {
                    title: 'Version Mismatch Warning',
                    buttons: [
                        {
                            text: "OK",
                            click: function () {
                                $(this).dialog("close");
                            }
                        }
                    ]
                }
            );
            this.log.addText('Version Mismatch');
            return false;
        } else if (address == 0) {
//            this.log.addText('EEPROM version: ' + frame.values[address]);
        }

        if(address == 0){
            this.versionManager.changeVersion(frame.values[address], false)
        }
    }

    return true;
};

MainApp.prototype.loadFont = function () {
	this.mcmList.buildTable();
    this.loadFontsButton.dialog('open');
};

/**
 *
 */
 MainApp.prototype.startConnection = function(){
    ProfileStorageGlobal.prepareToLoad();
    this.scenario.setScenario(this.scenario.scenarioList.READ_EE);
    this.protocol.requestForEE(ProfileStorageGlobal.getOneAdressWhatYouNeed());

    var _this = this;
    /* -------  SENZOR INTERVAL -------- */
    this.senzorInterval = setInterval(function () {
        if (_this.scenario.getScenario() == _this.scenario.scenarioList.IDDLE) {
        	var isInav = ProfileStorageGlobal._infoProfile && ProfileStorageGlobal._infoProfile[0] == 12; //12 = inav

            _this.protocol.requestForSenzors();
            _this.protocol.sendMSPstatus(_this.emulator.elements.MODEarmed.getValue(),_this.emulator.elements.MODEstable.getValue(),_this.emulator.elements.MODEhorizon.getValue(),_this.emulator.elements.MODEbaro.getValue(),_this.emulator.elements.MODEmag.getValue(),_this.emulator.elements.MODErth.getValue(),_this.emulator.elements.MODEhold.getValue(),_this.emulator.elements.MODEmission.getValue(),_this.emulator.elements.MODEcamstab.getValue(),_this.emulator.elements.MODEosdswitch.getValue(),_this.emulator.elements.MODEair.getValue(),_this.emulator.elements.MODEother.getValue(), isInav);
            _this.protocol.sendMSPboxid();
            _this.protocol.sendMSPrawgps(_this.emulator.elements.GPSfix.getValue(), _this.emulator.elements.GPSsats.getValue(), _this.emulator.elements.GPSaltitude.getValue(), _this.emulator.elements.GPSspeed.getValue(), _this.emulator.elements.GPSheading.getValue());
            _this.protocol.sendMSPcompgps(_this.emulator.elements.GPSdistancetohome.getValue(), _this.emulator.elements.GPSheadinghome.getValue());
            _this.protocol.sendMSPattitude(_this.emulator.elements.ACCpitch.getValue(), _this.emulator.elements.ACCroll.getValue(), _this.emulator.elements.MAGheading.getValue());
            _this.protocol.sendMSPaltitude(_this.emulator.elements.BAROaltitude.getValue(), _this.emulator.elements.BAROvario.getValue());
            _this.protocol.sendMSPanalog(_this.emulator.elements.ANALall.getValue());
            _this.protocol.sendMSPrc(_this.emulator.elements.GimbalRight.getValue(), _this.emulator.elements.GimbalLeft.getValue(), _this.emulator.elements.AUX12.getValue(), _this.emulator.elements.AUX34.getValue());
            _this.protocol.sendMSPfcversion();
        }
    }, 500);
};

/**
 *
 */
MainApp.prototype.setCliMode = function(){
    this.protocol.setCliMode();
};


