var layoutAddress;

VersionAppBuilder = function(LivePreview, GuiModel){

    this.currentVersion = null;

    this.huSettingsFile = {
        v13: 'settings/v15/settingsHud.json',
        v14: 'settings/v15/settingsHud.json',
        v16: 'settings/v16/settingsHud.json',
    };

    this.LivePreview = LivePreview;
    this.LivePreview.setHudFile(this.huSettingsFile.v13);

    this.GuiModel        = GuiModel;
};

VersionAppBuilder.prototype.changeVersion = function (version, clear) {

    if(version == this.currentVersion){
        return false;
    }

    this.currentVersion = version;
    this.GuiModel.clearForm();
    switch(version){
        case 15:

            layoutAddress = layoutAddressV15;
            this.GuiModel.buildForm(SettingsElementsV15);
            this.LivePreview.setHudFile(this.huSettingsFile.v14);

            if(clear){
                setTimeout(function () {
                    ProfileStorageGlobal.clear();
                    ProfileStorageGlobal.setMainProfile(JSON.parse(DefaultV15));
                }, 500);
            }
            break;
        case 16:
            layoutAddress = layoutAddressV16;
            this.GuiModel.buildForm(SettingsElementsV16);
            this.LivePreview.setHudFile(this.huSettingsFile.v16);
            if(clear) {
                setTimeout(function () {
                    ProfileStorageGlobal.clear();
                    ProfileStorageGlobal.setMainProfile(JSON.parse(DefaultV16));
                }, 500);
            }
            break;
        default:
            //layoutAddress = layoutAddressV16;
            this.GuiModel.buildForm(SettingsElementsV16);
            this.LivePreview.setHudFile(this.huSettingsFile.v16);
            if(clear) {
                setTimeout(function () {
                    ProfileStorageGlobal.clear();
                    ProfileStorageGlobal.setMainProfile(JSON.parse(DefaultV16));
                }, 200);
            }
    }

    return true;
};




