FormConnect = function () {
    var _this = this;
	this.state = this.stateList.DISCONECTED;
	this.node = null;
    this.portsRaw = [];

	this.cover = $('<div>').hide();
	this.ports = $('<select>');
	this.baudRate = $('<select>');
    this.passThroughPort = $('<select>').attr('disabled', 'disabled');
    this.passthroughEnable = $('<input>').attr('type', 'checkbox').attr('checked', false).attr('title', 'Connect over passthrough').tooltip();
	this.connectionButon = $('<button>').addClass('mainBtn');
	this.flashButton = $('<button>').addClass('mainBtn');
	this.flashButton.button({label: "<img src='icons/icon_flash.svg' /><br />Flash"});

	this.handleSubmit = function (values) {
	};
	this.handleFlash = function (values) {
	};

    this.passthroughEnable.change(function(){
		_this.passThroughPort.selectmenu($(this).is(':checked') ? 'enable' : 'disable');
	});

	for (var baudRateKey in this.baudRateList) {
		this.baudRate.append($('<option>').attr('value', baudRateKey).html(this.baudRateList[baudRateKey]));
	}

    for (var passThroughKey in this.passthroughList) {
        this.passThroughPort.append($('<option>').attr('value', passThroughKey).html(this.passthroughList[passThroughKey]));
    }

    this.ports.append($('<option>').attr('value', 0).html('=== loading ==='));

	this.cover.append(this.ports).append(this.passThroughPort).append(this.passthroughEnable).append(this.baudRate).append($('<br>')).append(this.connectionButon).append(this.flashButton);

	this._changeState();

	this.connectionButon.click(function (event) {
		chrome.storage.local.set({'ports': _this.ports.val()}, function () {
		});
		chrome.storage.local.set({'baudRate': _this.baudRate.val()}, function () {
		});
        chrome.storage.local.set({'passthroughPort': _this.passThroughPort.val()}, function () {
        });
        chrome.storage.local.set({'passthroughEnable': _this.passthroughEnable.is(':checked')}, function () {
        });

		_this.handleSubmit({port: _this.ports.val(), baudRate: _this.baudRate.val(), passthroughPort: _this.passThroughPort.val(), passthroughEnable: _this.passthroughEnable.is(':checked')}, function () {
		});
	});

	this.flashButton.click(function (event) {
		chrome.storage.local.set({'ports': _this.ports.val()}, function () {
		});
		_this.handleFlash(_this.ports.val());
	});

    this.show();
};

/**
 *
 * @param node
 */
FormConnect.prototype.connectToNode = function (node) {
	this.node = node;
	this.node.html(this.cover);
};

/**
 *
 * @param state
 */
FormConnect.prototype.changeState = function (state) {
	this.state = state;
	this._changeState();
};

/**
 *
 * @type {{9600: number}}
 */
FormConnect.prototype.baudRateList = {
	9600:   '9600',
  	38400:  '38400',
  	19200:  '19200',
  	57600:  '57600 (Mavlink)',
 	115200: '115200 (Default)'
};

/**
 *
 * @type {{9600: number}}
 */
FormConnect.prototype.passthroughList = {
    0:  'UART1',
    1:  'UART2',
    2:  'UART3',
    3:  'UART4',
    30:  'SoftSerial1',
    31:  'SoftSerial2'
};

/**
 *
 * @type {{DISCONECTED: number, CONNECTING: number, CONNECTED: number, DISCONECTING: number}}
 */
FormConnect.prototype.stateList = {
	DISCONECTED: 0,
	CONNECTING: 1,
	CONNECTED: 2,
	DISCONECTING: 3
};

/**
 *
 */
FormConnect.prototype.show = function () {
	this.cover.show();
	this.connectionButon.button();
	this.flashButton.button();
    this.ports.selectmenu();
    this.passThroughPort.selectmenu();
    this.baudRate.selectmenu();
	var _this = this;

	chrome.storage.local.get('baudRate', function (value) {
		_this.baudRate.val(value.baudRate ? value.baudRate : _this.baudRateList[115200]);
        _this.baudRate.selectmenu('refresh');

        _this.ports.selectmenu('refresh');//hack :(
	});

    chrome.storage.local.get('passthroughPort', function (value) {
        _this.passThroughPort.val(value.passthroughPort ? value.passthroughPort : 0);
        _this.passThroughPort.selectmenu('refresh');
    });

    chrome.storage.local.get('passthroughEnable', function (value) {
        _this.passthroughEnable.prop('checked', value.passthroughEnable ?  value.passthroughEnable : 0).trigger('change');
    });
};

FormConnect.prototype.changeBaudRate = function(baud) {
	if(this.baudRateList[baud]){
        this.baudRate.val(baud);

        var _this = this;
        chrome.storage.local.set({'baudRate': baud}, function () {
            _this.baudRate.selectmenu('refresh');
        });
	}
};

/**
 *
 */
FormConnect.prototype.hide = function () {
	this.cover.hide();
};

/**
 *
 * @param ports
 */
FormConnect.prototype.setPorts = function (ports) {
	if(ports.length != this.portsRaw.length){
        this.ports.html('');
        for (var portKey in ports) {
            var option = $('<option>').attr('value', ports[portKey].path).html(ports[portKey].path);
            this.ports.append(option);
        }

        var _this = this;
        chrome.storage.local.get('ports', function (value) {
            if(value && value.ports){
                _this.ports.val(value.ports);
                _this.ports.selectmenu('refresh');
            }
        });


        this.ports.selectmenu('refresh');
	}

    this.portsRaw = ports;
};

/**
 *
 * @private
 */
FormConnect.prototype._changeState = function () {
	switch (this.state) {
		case this.stateList.DISCONECTED:
			this.flashButton.show();
			this.connectionButon.button({label: "<img src='icons/usb_icon_connect.svg' /><br />Connect"}).removeAttr('disabled');
			break;

		case this.stateList.CONNECTED:
			this.flashButton.hide();
			this.connectionButon.button({label: "<img src='icons/usb_icon_disconnect.svg' /><br />Disconect"}).removeAttr('disabled');
			break;

		case this.stateList.CONNECTING:
			this.flashButton.hide();
            this.connectionButon.button({label: "<img src='icons/usb_icon_connect.svg' /><br />Connecting"}).attr('disabled', 'disabled');
			break;

		case this.stateList.DISCONECTING:
			this.flashButton.hide();
            this.connectionButon.button({label: "<img src='icons/usb_icon_disconnect.svg' /><br />Disconect"}).attr('disabled', 'disabled');
			break;
	}
};
