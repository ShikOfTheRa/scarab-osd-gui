/**
 *
 * @param target
 * @param presetDataFile
 * @constructor
 */
PresetControl = function (target, presetDataFile) {
    var _this = this;

    this.target = target;
    this.presetDataFile = presetDataFile;
    this.numberOfLayouts = 3;

    this.labels = [
        ['Apply to Normal', 'Apply to OSD switch'],
        ['Apply to TX - LOW', 'Apply to TX - MID', 'Apply to TX - HIGH']

    ];

    this.buttons = [];

    this.render();

    ProfileStorageGlobal.changeMainProfile(function(profile, type) {
        if (type == ProfileStorageGlobal.type.CHANGE_LOAD_FROM_PRESET || type == ProfileStorageGlobal.type.CHANGE_FORM_VALUE || type == ProfileStorageGlobal.type.CHANGE_LOAD_FROM_FILE || type == ProfileStorageGlobal.type.CHANGE_LOAD_FROM_DEVICE || type == ProfileStorageGlobal.type.CHANGE_CLEAR) {
            if (profile[38] !== void 0) {
                _this.changeLayoutType(profile[38]);
            }
        }
    });
};

/**
 *
 */
PresetControl.prototype.render = function()
{
	var _this = this;
	$.get(this.presetDataFile, function(preset){

        _this.target.html('');
        var table = $('<table>').addClass('noHover');
		var presetArray = JSON.parse(preset);

        var select = $('<select>');
        for(var key in presetArray){

            var presetRow = presetArray[key];

            var option = $('<option>').html(presetRow['name']);
            option.data('values', presetRow.values);
            select.append(option);
        }


        for(var i = 0; i < _this.numberOfLayouts; i++){
            var tr = $('<tr>');

            var td = $('<td>');
            var tdButon = $('<button>').button().data('layoutId', i).addClass('layout_load');

            tdButon.click(function(){
                var element =  $(this);
                element.html('LOADING ...');

                var layoutId = $(this).data('layoutId');
                var data = select.children('option:selected').data('values');
                setTimeout(function(){
                    ProfileStorageGlobal.setValuesForLayout(layoutId, data);
                }, 1000);

                ProfileStorageGlobal.changeMainProfile(function(profile, type){
                    if(type == ProfileStorageGlobal.type.CHANGE_LOAD_FROM_PRESET){
                        element.html(element.data('label'));
                    }
                });

            });

            _this.buttons.push(tdButon);

            if(i == 0){
                var tdInner = $('<td>').attr('rowspan', _this.numberOfLayouts);
                tdInner.append(select);
                tr.append(tdInner);
            }

            td.append(tdButon);
            tr.append(td);

            table.append(tr);
        }

        _this.target.append(table);
       // select.selectmenu();

        _this.changeLayoutType(0);
	});
};

PresetControl.prototype.changeLayoutType = function(type){
    var labels = this.labels[type];

    for(var buttonKey in this.buttons){
        if(!labels[buttonKey]){
            this.buttons[buttonKey].hide();
            continue;
        }

        this.buttons[buttonKey].html(labels[buttonKey]);
        this.buttons[buttonKey].data('label', labels[buttonKey]);
        this.buttons[buttonKey].show();
    }
};
