/**
 *
 * @constructor
 */
GuiModel = function () {
	this.elementsGroup = [];

	var _this = this;
	this._handleChangeValue = function (id, value, position) {
		if (position) {
            ProfileStorageGlobal.setValue(position, value & 0xff);
		}
	};

	this._statusElement = new Status($('#status-widget'));
	this._senzorElement = new Senzor($('#senzor-widget'));
    this._infoElement 	= new Info($('#info-widget'));
    this._tabs 			= $('#tabs');


    //evenets
    ProfileStorageGlobal.changeState(function(state, progress){
		switch(state){
			case ProfileStorageGlobal.state.STATE_CLEAN:
                _this._statusElement.setMode(_this._statusElement._modeList.IDLE);
                _this._senzorElement.hide();
                _this._infoElement.hide();
				break;
            case ProfileStorageGlobal.state.STATE_FILLING:
				if(progress == 0){
                    _this._statusElement.setMode(_this._statusElement._modeList.WAITING_FOR_OSD);
				}else{
                    _this._statusElement.setMode(_this._statusElement._modeList.READ_OSD);
                    _this._statusElement.setProgress(progress);
				}
                break;
		}
	});

    ProfileStorageGlobal.changeSensorValues(function(values){
        _this._senzorElement.setValues(values);
    });

    ProfileStorageGlobal.changeInfoValues(function(values){
        if(values[0] == 0 || (values[0] >= 13 && values[0] <= 20) ){
            var selectedTab =  _this._tabs.tabs('option', 'active');
            console.log(selectedTab);
            if(selectedTab == 15){
                _this._tabs.tabs( "option", "active", 1 );
            }

            _this._tabs.tabs({
                disabled: [ 15 ]
            });
        }
        else
        {
            _this._tabs.tabs({
                disabled: [  ]
            });
        }

        _this._infoElement.setValues(values);
    });

    ProfileStorageGlobal.changeMainProfile(function(profile, type, oldProfile, data){
        for(var key in _this.elementsGroup){
            _this.elementsGroup[key].setValues(profile);
        }
    });
};

GuiModel.prototype.buildForm = function (SettingsElements) {
    //build form elements
    for (var key in SettingsElements) {
        for (var groupKey in SettingsElements[key].group) {
            
            if (!this.elementsGroup[SettingsElements[key].group[groupKey].id]) {
                var targetNode = $('#' + SettingsElements[key].group[groupKey].id);
                if (SettingsElements[key].group[groupKey].classGroup) {
                    this.elementsGroup[SettingsElements[key].group[groupKey].id] = new window[SettingsElements[key].group[groupKey].classGroup](targetNode, SettingsElements[key].group[groupKey].id, SettingsElements[key].group.description);
                } else {
                    this.elementsGroup[SettingsElements[key].group[groupKey].id] = new FormGroup(targetNode, SettingsElements[key].group[groupKey].id, SettingsElements[key].group.description);
                }

                this.elementsGroup[SettingsElements[key].group[groupKey].id].handleChangeValue = this._handleChangeValue;
            }

            switch (SettingsElements[key].type) {
                case SettingsElementsType.select:
                    this.elementsGroup[SettingsElements[key].group[groupKey].id].addElement(new SelectElement(SettingsElements[key].id, SettingsElements[key].description, SettingsElements[key].properties), SettingsElements[key].position, SettingsElements[key].secondByte);
                    break;
                case SettingsElementsType.checkbox:
                    this.elementsGroup[SettingsElements[key].group[groupKey].id].addElement(new CheckBoxElement(SettingsElements[key].id, SettingsElements[key].description, SettingsElements[key].properties), SettingsElements[key].position, SettingsElements[key].secondByte);
                    break;
                case SettingsElementsType.range:
                    this.elementsGroup[SettingsElements[key].group[groupKey].id].addElement(new RangeElement(SettingsElements[key].id, SettingsElements[key].description, SettingsElements[key].properties), SettingsElements[key].position, SettingsElements[key].secondByte);
                    break;
                case SettingsElementsType.hidden:
                    this.elementsGroup[SettingsElements[key].group[groupKey].id].addElement(new HiddenElement(SettingsElements[key].id, SettingsElements[key].description, SettingsElements[key].properties), SettingsElements[key].position, SettingsElements[key].secondByte);
                    break;
            }
        }

    }

    for (var key in this.elementsGroup) {
        this.elementsGroup[key].render();
    }
};

GuiModel.prototype.clearForm = function () {
    for (var key in this.elementsGroup) {
        var group = this.elementsGroup[key];

        group.destroy();
    }
    this.elementsGroup = [];
};


GuiModel.prototype.resetInfo = function () {
    this._statusElement.setMode(this._statusElement._modeList.IDLE);
    this._senzorElement.hide();
    this._infoElement.hide();
};

/**
 *
 */
GuiModel.prototype.setModeWriteToOsd = function () {
	this._statusElement.setMode(this._statusElement._modeList.WRITE_OSD);
};

/**
 *
 */
GuiModel.prototype.setProgress  = function (progress, length) {
    this._statusElement.setProgress( Math.round((100 / length) * (progress + 1)));
};


/**
 *
 */
GuiModel.prototype.setModeWaitingForOsd = function () {
    this._statusElement.setMode(this._statusElement._modeList.WAITING_FOR_OSD);
};


/**
 *
 * @param target
 */
GuiModel.prototype.showAppVersion = function (target) {
	var manifest = chrome.runtime.getManifest();
	target.html(manifest.version);
};



