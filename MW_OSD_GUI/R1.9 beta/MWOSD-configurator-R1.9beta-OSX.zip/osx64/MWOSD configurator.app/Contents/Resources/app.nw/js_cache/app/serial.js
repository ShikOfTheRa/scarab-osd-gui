/**
 *
 * @param serial
 * @constructor
 */
SerialConnector = function (serial) {
    this._serial = serial;
    this._connectionId = null;
    this._connectionString = null;
    this._connectionBitrate = null;
    this._state = this.stateList.DISCONECTED;

    this._serialDelayObject = null;

    this._serialDelay = function(deviceName, baudRate, connection){
        this.attempt = 0;

        this.timeDelay = [500, 1000, 2000, 4000, 8000, 16000];//in ms
        this.timeDelayIndex = 0;

        this.deviceName = deviceName;
        this.baudRate 	= baudRate;
        this.connection = connection;
        this.timer = null;

        this.try = function(){
            console.log('try', this.timeDelayIndex);
            clearTimeout(this.timer);
            var _this = this;
            this.timer = setTimeout(function(){
                console.log('run try');
                _this.timeDelayIndex++;
                _this.connection._connect(_this.deviceName, _this.baudRate);
            }, this.timeDelay[this.timeDelayIndex]);
        };

        this.isLast = function(){
            return this.timeDelayIndex == this.timeDelay.length;
        };

        this.stop = function(){
            clearTimeout(this.timer);
            this.timeDelayIndex = 0;
        };

        this.destroy = function(){
            clearTimeout(this.timer);
            _this.connection = null;
        }
    };


    this.handleChangeState = function (state) {
        console.log('change state ' + state);
    };

    this.handleErrorOverRun = function (error) {

    };

    this.handleErrorFrameError = function (error) {

    };

    this.handleListDevices = function (state) {
    };

    this.handleConnectionFailed = function (msg) {

    };

    /**
     *
     * @param Uint8Array data
     */
    this.handleReceiveData = function (data) {
    };

    /**
     *
     * @param Uint8Array data
     */
    this.handleDataSent = function () {
    };

    var _this = this;
    var onReceiveCallback = function (info) {
        if (info.connectionId == _this._connectionId && info.data) {
            _this.handleReceiveData(new Uint8Array(info.data));
        }
    };

    var onReceiveErrorCallback = function (info) {
        if (info.connectionId == _this._connectionId) {
            console.log({onReceiveErrorCallback : info});

            switch (info.error) {
                case 'disconnected':
                case 'device_lost':
                case 'break':
                case 'system_error':
                    _this._state = _this.stateList.DISCONECTED;
                    _this._connectionId = null;
                    _this.handleChangeState(_this._state);
                    break;
                case 'overrun':
                    console.log('handle error: overrun');
                    _this.handleErrorOverRun(info.error);
                    break;
                case 'frame_error':
                    console.log('handle error: frame_error');
                    _this.handleErrorFrameError(info.error);
                    break;
                default:
                    _this._state = _this.stateList.DISCONECTED;
                    _this._connectionId = null;
                    _this.handleChangeState(_this._state);
                // do nothing;
            }
        }
    };

    this._serial.onReceive.addListener(onReceiveCallback);
    this._serial.onReceiveError.addListener(onReceiveErrorCallback);
};

/**
 *
 * @type {{DISCONECTED: number, CONNECTING: number, CONNECTED: number, DISCONECTING: number}}
 */
SerialConnector.prototype.stateList = {
    DISCONECTED: 0,
    CONNECTING: 1,
    CONNECTED: 2,
    DISCONECTING: 3
};

/**
 *
 */
SerialConnector.prototype.reconect = function(){
    console.log('reconect');
    var _this = this;
    jQuery.when(_this.disconect()).then(function() {
        console.log('conect call');
        _this.connect(_this._connectionString, _this._connectionBitrate);
    });
};

/**
 *
 * @returns {number|*}
 */
SerialConnector.prototype.getState = function () {
    return this._state;
};

/**
 *
 * @param callBack
 */
SerialConnector.prototype.getDevices = function () {
    this._serial.getDevices(this.handleListDevices);
};

/**
 *
 * @param deviceName
 * @param bitrate
 */
SerialConnector.prototype.connect = function (deviceName, bitrate) {
    try{
        var _this = this;
        var checkPortCallBack = function (ports) {

            for (var i = 0; i < ports.length; i++) {
                if (ports[i].path == deviceName) {
                    _this._connect(deviceName, parseInt(bitrate));
                    return;
                }
            }
            throw "Device " + deviceName + " not found";
        };

        this._serial.getDevices(checkPortCallBack);
    }catch(ex){
        console.log({connectException : ex});
        this._state = this.stateList.DISCONECTED;
        this._connectionId = null;
        this.handleChangeState(this._state);
    }

};


/**
 *
 */
SerialConnector.prototype.disconect = function () {
    this._disconect();
};


/**
 *
 */
SerialConnector.prototype._disconect = function () {
    console.log('disconect');
    var dfd = jQuery.Deferred();
    if (this.getState() == this.stateList.CONNECTED) {
        var _this = this;
        var onDisconectCallback = function () {
            console.log('disconect DONE');
            _this._state = _this.stateList.DISCONECTED;
            _this._connectionId = null;
            _this._connectErrorCount = 0;
            _this.handleChangeState(_this._state);
            dfd.resolve('disconected');
        };

        this._state = _this.stateList.DISCONECTING;
        this.handleChangeState(this._state);
        this._serial.disconnect(this._connectionId, onDisconectCallback);
    }else{
        this._connectionId = null;
        dfd.resolve('disconected');
    }

    return dfd.promise();
};

/**
 *
 * @param byteArray
 */
SerialConnector.prototype.send = function (byteArray) {
    if (this._connectionId) {
        var buf = new ArrayBuffer(byteArray.length);
        var bufView = new Uint8Array(buf);

        for (var i = 0; i < byteArray.length; i++) {
            bufView[i] = byteArray[i];
        }

        this._serial.send(this._connectionId, buf, this.handleDataSent);
        return;
    }
};


/**
 *
 * @param byteArray
 */
SerialConnector.prototype.sendString = function (str) {
    if (this._connectionId) {
        var buf=new ArrayBuffer(str.length  + 1);
        var bufView=new Uint8Array(buf);
        for (var i=0; i < str.length; i++) {
            bufView[i] = str.charCodeAt(i);
        }

        bufView[str.length] = 13;
        this._serial.send(this._connectionId, buf, this.handleDataSent);
        return;
    }
};

/**
 * internal DONT use
 * @param deviceName
 * @param bitrate
 */
SerialConnector.prototype._connect = function (deviceName, bitrate) {
    console.log('_connect', this.getState());
    if (this.getState() != this.stateList.DISCONECTED && !this._serialDelayObject) {
        return false;
    }

    console.log('_connect almost success');

    var _this = this;

    bitrate = bitrate || 9600;
    this._state = _this.stateList.CONNECTING;
    this.handleChangeState(_this._state);


    var onConnect = function (connectionInfo) {
        console.log({connectionInfo : connectionInfo});
        if (chrome.runtime.lastError || connectionInfo == null) {

            if(!_this._serialDelayObject){
                _this._serialDelayObject = new _this._serialDelay(deviceName, bitrate, _this);
            }

            if(_this._serialDelayObject.isLast()){

                _this._connectionId = null;
                _this._state = _this.stateList.DISCONECTED;

                if(chrome.runtime.lastError){
                    console.log(chrome.runtime.lastError);
                    _this.handleConnectionFailed(chrome.runtime.lastError.message);
                }else{
                    _this._serialDelayObject.destroy();
                    _this._serialDelayObject = null;
                    console.log('Connection error');
                    _this.handleConnectionFailed('Connection error');
                }
            }else{
                _this._serialDelayObject.try();
            }
        }else{
            _this._connectionId = connectionInfo.connectionId;
            _this._connectionString = deviceName;
            _this._connectionBitrate = bitrate;
            _this._state = _this.stateList.CONNECTED;
            _this._connectErrorCount = 0;
            _this.handleChangeState(_this._state);
        }
    };

    var options = {
        'bitrate': bitrate,
    };

    //onConnect();
    chrome.serial.connect(deviceName, options, onConnect);
};

SerialConnector.prototype.getInfo = function(callBack) {
    this._serial.getInfo(this._connectionId, callBack);
};
