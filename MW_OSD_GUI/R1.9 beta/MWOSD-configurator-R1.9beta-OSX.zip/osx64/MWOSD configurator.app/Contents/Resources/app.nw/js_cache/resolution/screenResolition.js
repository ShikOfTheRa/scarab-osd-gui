/* ##################################################### */
/* SCREEN SETTING
 /* ##################################################### */

var layoutS = {
	LAYOUT_1: 0,
    LAYOUT_2: 1,
    LAYOUT_3: 2,
};


/* ##################################################### */



/* ##################################################### */
/* SCREEN CLASS
 /* ##################################################### */
/**
 * manin app class for edit screen for mw_osd
 * @param element
 * @constructor
 */
ScreenResolutionEditor = function (element, screenMode, backgroundImageUrl, control) {

	screenMode = screenMode || 'pal';
	var _this = this;
	this.scale = 1; // only int
	this.fontWidth = 12 * this.scale;
	this.fontHeight = 18 * this.scale;
	this.backgroundImageUrl = backgroundImageUrl;
	this.screenSize = screenMode == 'pal' ? scrennSetting.pal : scrennSetting.ntsc;

    this.activeLayout = layoutS.LAYOUT_1;
    this.layoutType = 0;
    this.control = control;

	this.canvas = element;
	this.ctx = this.canvas[0].getContext("2d");
	this.parentNode = element;
	this.imageObj = new Image(); // backgroundimage
	this.osdGrid = $('<table>').attr('id', 'resolutionEditor');
	this.canvasGrid = [];
    this.cellGrid = [];
	this.elements = [];
    this.modificator = [];
	this.markedTimeout = null;
	this.fontMap = null;
	this.screenFontsMap;

    this.layoutsTab = $('#layouts-tabs');

    /**
     *
     * @param elementId
     * @param x
     * @param y
     */
	this.handleMove = function(elementId, x, y){
        var positionInProfile 	= (_this.getElementPositionInProfile(elementId) * 2 ) + layoutAddress[_this.activeLayout][0];
        ProfileStorageGlobal.setLayoutPosition(positionInProfile, _this.getElementPositionFlat(elementId));
	};

    /**
     *
     * @param name
     * @param value
     * @param layoutId
     */
    this.control.changeVisible = function(name, value, layoutId){
        var positionInProfile 	= (_this.getElementPositionInProfile(name) * 2 ) + layoutAddress[layoutId][0];
        if(positionInProfile <layoutAddress[layoutId][0]){
            positionInProfile 	= (_this.getModificatorPositionInProfile(name) * 2 ) + layoutAddress[layoutId][0];
		}

        if(positionInProfile < layoutAddress[layoutId][0]){
           return;
        }

        ProfileStorageGlobal.setElementInLayoutVisible(positionInProfile, value);
        if(layoutId != _this.activeLayout){
            _this.setActiveLayout(layoutId);
        }
	};

	this.handleClickToElement = function(elementName){};

	ProfileStorageGlobal.changeMainProfile(function(profile, type, oldProfile, data){

	    BaseSettings.profile = profile;
	    if(type == ProfileStorageGlobal.type.CHANGE_LOAD_FROM_PRESET || type == ProfileStorageGlobal.type.CHANGE_FORM_VALUE || type == ProfileStorageGlobal.type.CHANGE_LOAD_FROM_FILE || type == ProfileStorageGlobal.type.CHANGE_LOAD_FROM_DEVICE || type == ProfileStorageGlobal.type.CHANGE_CLEAR){
	        if(profile[38] !== void 0  ){
                _this.changeLayoutType(profile[38]);
            }
        }

        if(type == ProfileStorageGlobal.type.CHANGE_LOAD_FROM_PRESET && data && data['layoutId']){
            _this.setActiveLayout(data['layoutId']);
        }

		/*if(type != ProfileStorageGlobal.type.CHANGE_LOAD_FROM_FILE && type != ProfileStorageGlobal.type.CHANGE_LOAD_FROM_DEVICE && type != ProfileStorageGlobal.type.CHANGE_VISIBLE && type != ProfileStorageGlobal.type.CHANGE_MOVE){
			return;
		}*/

        _this.layoutSettings = [[], [], []];
		for (var index in profile){
			for (var layoutId in layoutAddress) {
                if (index >= layoutAddress[layoutId][0] && index <= layoutAddress[layoutId][1]) {
                    _this.layoutSettings[layoutId][index] = profile[index];
                    break;
                }
            }
		}


		if(type != ProfileStorageGlobal.type.CHANGE_MOVE && type != ProfileStorageGlobal.type.CHANGE_LOAD_FROM_DEVICE && type != ProfileStorageGlobal.type.CHANGE_LOAD_FROM_FILE && type != ProfileStorageGlobal.type.CHANGE_LOAD_FROM_PRESET){
            _this.setActiveLayout(_this.activeLayout);
		}

        if(type == ProfileStorageGlobal.type.CHANGE_LOAD_FROM_FILE || type == ProfileStorageGlobal.type.CHANGE_LOAD_FROM_PRESET){
            _this.initControl();
            _this.setActiveLayout(_this.activeLayout);
        }
    });

    ProfileStorageGlobal.changeState(function(state, progress){
        if(state == ProfileStorageGlobal.state.STATE_DONE){
            _this.initControl();
            _this.setActiveLayout(_this.activeLayout);
        }
    });

    ProfileStorageGlobal.changeInfoValues(function(values){
        var needRedraw = false;
        for(var name in _this.elements){
            var element = _this.elements[name];
            if(element.params && element.params.neededInfo == true)
            {
                element.settings.infoData = values;
                needRedraw = true;
            }
        }

        if(needRedraw){
            _this._reDrawScreen();
        }
    });

    this.layoutSettings = [[], [], []];
};

/**
 *
 * @param screenFontsMap
 */
ScreenResolutionEditor.prototype.run = function (screenFontsMap) {
    var _this = this;
    this.screenFontsMap = screenFontsMap;
    return this.loadImageByUrl(this.backgroundImageUrl).then(function(){
        return _this.render();
    });
};

/**
 *
 * @param screenFontsMap
 */
ScreenResolutionEditor.prototype.setHudFile = function (hudFile) {
    var _this = this;

    return $.getJSON(hudFile, function(settings){
        _this.loadElementsSettings(settings, _this.screenFontsMap)
    });
};

/**
 *
 * @param elementSettings
 * @param screenFontsMap
 * @returns {*}
 */
ScreenResolutionEditor.prototype.loadElementsSettings = function(elementSettings, screenFontsMap){
    this.removeAllElements();
    var deferred = $.Deferred();

    for (var elementKey in elementSettings.elements) {
        var element = elementSettings.elements[elementKey];
        if (element.class) {
            this.addElement(element.code, new window[element.class](screenFontsMap), element.position, element.params);
            var x = parseInt(element.value) % this.screenSize[0];
            var y = Math.floor(parseInt(element.value) / this.screenSize[0]);

            this.setDisplayedElement(element.code, element.enable, x, y);
        }
    }

    for (var elementKey in elementSettings.elements) {
        var element = elementSettings.elements[elementKey];
        if (element.modificatorFor) {
            this.addModificator(element.code, element.position, element.modificatorFor);
        }
    }

    this.setActiveLayout(this.activeLayout);

    this.control.setSettings(elementSettings);
    this.control.reDraw();

    this._reDrawScreen();
    deferred.resolve();

    return deferred.promise();
};

/**
 * render background image and table with canvases
 *
 */
ScreenResolutionEditor.prototype.render = function () {
    var deferred = $.Deferred();

    this.removeAllElements();
	this.canvas[0].height = this.fontHeight * this.screenSize[1];
	this.canvas[0].width = this.fontWidth * this.screenSize[0];
	this.canvas.attr('width', this.fontWidth * this.screenSize[0] + 'px');
	this.canvas.attr('height', this.fontHeight * this.screenSize[1] + 'px');
	this.ctx.scale(this.scale / 2, this.scale / 2);
	this.ctx.drawImage(this.imageObj, 0, 0);
	this.markedElement = null;

	this.osdGrid.attr('style', 'margin-left: 1px; position: absolute; top: 16px; width:' + this.canvas[0].width + 'px; height:' + this.canvas[0].height + 'px');

	this.dragEndDrop = {
		mousedown: false,
		prevPoSition: [0, 0],
		actualPosition: [0, 0],
		elementName: null
	};

	var _this = this;
	for (var y = 0; y < this.screenSize[1]; y++) {
		var row = $('<tr>');

		this.osdGrid.append(row);
		this.canvasGrid[y] = [];
        this.cellGrid[y] = [];
		for (var x = 0; x < this.screenSize[0]; x++) {
			var canvas = $('<canvas>');
			canvas[0].height = this.fontHeight;
			canvas[0].width = this.fontWidth;

			$(canvas).attr('x', x).attr('y', y);

			this.canvasGrid[y][x] = canvas[0].getContext('2d');

            this.cellGrid[y][x] = $('<td>').data('x', x).data('y', y).append(canvas);
            var cell = this.cellGrid[y][x];
			row.append(cell);
			/*if (x == this.screenSize[0] - 1) {
				cell.attr('style', 'border-left: 1px solid black');
			}*/

            this.cellGrid[y][x].mouseenter(function(){

				if(_this.dragEndDrop.mousedown == true){
                    _this.dragEndDrop.actualPosition = [$(this).data('y'), $(this).data('x')];

                    if(_this.dragEndDrop.actualPosition[1] != _this.dragEndDrop.prevPoSition[1]){
                        _this.moveElementToPositionX(_this.dragEndDrop.elementName, _this.dragEndDrop.actualPosition[1] - _this.dragEndDrop.prevPoSition[1]);
                        _this._reDrawScreen();

					}

                    if(_this.dragEndDrop.actualPosition[0] != _this.dragEndDrop.prevPoSition[0]){
                        _this.moveElementToPositionY(_this.dragEndDrop.elementName, _this.dragEndDrop.actualPosition[0] - _this.dragEndDrop.prevPoSition[0]);
                        _this._reDrawScreen();
                    }

                    _this.handleMove(_this.dragEndDrop.elementName,
                        _this.getElementPosition(_this.dragEndDrop.elementName)[0],
                        _this.getElementPosition(_this.dragEndDrop.elementName)[1]
                    );

                    _this.hightlightElement(_this.dragEndDrop.elementName);
                    _this.dragEndDrop.prevPoSition = [$(this).data('y'), $(this).data('x')];
				}else{
                    _this.hightlightElement($(this).data('elementName'));
				}
			});

            this.cellGrid[y][x].mouseleave(function(){
            	if(!_this.dragEndDrop.mousedown){
                    _this.hightlightElement(null);
				}
            });

            this.cellGrid[y][x].mousedown(function(event) {
                switch (event.which) {
                    case 1: // left button
						_this.dragEndDrop = {
							mousedown: true,
                            elementName: $(this).data('elementName'),
                            actualPosition: [$(this).data('y'), $(this).data('x')],
                            prevPoSition: [$(this).data('y'), $(this).data('x')]
						};
                        _this.handleClickToElement($(this).data('elementName'));
                        break;
                    case 2: // middle
                        _this.control.scrollTo($(this).data('elementName'));
                }
            });

            this.cellGrid[y][x].mouseup(function(event) {
                _this.dragEndDrop.mousedown = false;
            });
		}
	}

	this.layoutsTab.append(
		$('<li>').addClass('layout_label_1').html('Normal').click(function(){
			_this.setActiveLayout(layoutS.LAYOUT_1);
		})
	).append(
        $('<li>').addClass('layout_label_2').html('OSD switch').click(function(){
            _this.setActiveLayout(layoutS.LAYOUT_2);
        })
    ).append(
        $('<li>').addClass('layout_label_3').html('TX - HIGH').click(function(){
            _this.setActiveLayout(layoutS.LAYOUT_3);
        })
    );


    this.osdGrid.mouseleave(function(){
        _this.hightlightElement(null);
    });

    this.control.render();

	this.parentNode.after(this.osdGrid);

    $('.layout_label_3').hide();

    deferred.resolve();
    return deferred.promise();
};

ScreenResolutionEditor.prototype.changeLayoutType = function(type){
    this.layoutType = type;

    if(type == 0){
        //only two
        $('.layout_label_3').hide();
        $('.layout_label_1').html('Normal');
        $('.layout_label_2').html('OSD switch');

        if(this.activeLayout == 2){
            this.setActiveLayout(0)
        }
        $('#main_screen_control  table tr  td:nth-child(4)').hide();
    }

    if(type == 1){
        $('.layout_label_3').show();
        $('.layout_label_1').html('TX - LOW');
        $('.layout_label_2').html('TX - MID');

        $('#main_screen_control  table tr  td:nth-child(4)').show();
    }
};

/**
 *
 */
ScreenResolutionEditor.prototype.getElementPositionFlat = function(name){
    if (this.elements[name]) {
        var position = this.getElementPosition(name);
        return (position[1] * this.screenSize[0]) + position[0];
    }

    return 0
};

/**
 *
 * @param element
 * @returns {{isEnable: boolean, x: number, y: number}}
 */
ScreenResolutionEditor.prototype.getElementValueFromLayoutSetting = function(element, layoutId){
    var byte1 = this.layoutSettings[layoutId][(element.positionInProfile * 2) + (layoutAddress[0][0] + (layoutId * layoutLength))];
    var byte2 = this.layoutSettings[layoutId][(element.positionInProfile * 2) + (layoutAddress[0][0] + (layoutId * layoutLength)) + 1];
    var isEnable = byte2 >= 0xC0;

    byte2 = (byte2 >= 0xC0) ? byte2 - 192 : byte2;
    var position = (byte2 << 8) | byte1;
    var x = position % scrennSetting.pal[0];
    var y = Math.floor(position / scrennSetting.pal[0]);
    return {isEnable: isEnable, x: x, y: y};
};

/**
 *
 * @param layoutID
 */
ScreenResolutionEditor.prototype.initControl = function(){
    for(var name in this.elements){
        var element = this.elements[name];

        for(var layoutSetingsKey in this.layoutSettings){
        	if(this.layoutSettings[layoutSetingsKey][(element.positionInProfile * 2) + (layoutAddress[0][0] + (layoutSetingsKey * layoutLength))] != undefined){
                var values = this.getElementValueFromLayoutSetting(element, (layoutSetingsKey - 1) + 1);
        		this.control.setValue(layoutSetingsKey, name, values.isEnable);
            }
		}
    }
};

/**
 *
 * @param layoutID
 */
ScreenResolutionEditor.prototype.setActiveLayout = function(layoutID){

    if(this.layoutType == 0 && layoutID == 2){
        layoutID = 0;
    }

    if(!layoutAddress || !layoutAddress[0])
    {
        return;
    }

	this.activeLayout = layoutID;
	this.clearScreen();

    //feed screen
    for(var name in this.elements){
        var element = this.elements[name];
        if(this.layoutSettings[this.activeLayout][(element.positionInProfile * 2) + (layoutAddress[0][0] + (this.activeLayout * layoutLength))] != undefined){
            var values = this.getElementValueFromLayoutSetting(element, this.activeLayout);
			this.moveElementToPosition(name, values.x, values.y);
			this.setDisplayElement(name, values.isEnable);
        }else{

            this.setDisplayElement(name, 0);
		}
    }


    for(var name in this.modificator){
        var modificator = this.modificator[name];
        if(this.layoutSettings[this.activeLayout][(modificator.positionInProfile * 2) + (layoutAddress[0][0] + (this.activeLayout * layoutLength))] != undefined){
            var values = this.getElementValueFromLayoutSetting(modificator, this.activeLayout);
            this.elements[modificator.modificatorFor].settings.modificator[name] = values;
        }
    }

    this.layoutsTab.find('li').removeClass('activeTab');
    this.layoutsTab.find('li:nth-child('+ (this.activeLayout + 1) + ')').addClass('activeTab');

    this.control.setActiveLayout(this.activeLayout);

    this._reDrawScreen();
};

/**
 * add element to register, it must be setting class from element.js file, name is ID, must be unique
 *
 * @param name
 * @param settings
 */
ScreenResolutionEditor.prototype.addElement = function (name, settings, positionInProfile, params) {
	this.elements[name] = {
        positionInProfile: positionInProfile,
		isDisplayed: false,
		settings: settings,
		position: [0, 0],
		value: null,
        params: params

	};
};

/**
 *
 * @param name
 * @param settings
 */
ScreenResolutionEditor.prototype.addModificator = function(name, positionInProfile, modificatorFor){
    this.modificator[name] = {
        positionInProfile: positionInProfile,
        modificatorFor: modificatorFor
    }
};

/**
 *
 * @param name
 */
ScreenResolutionEditor.prototype.setDisplayElement = function (name, displeyed) {
    if (this.elements[name]) {
        this.elements[name].isDisplayed = displeyed;
    }
};

/**
 *
 * @param name
 */
ScreenResolutionEditor.prototype.isDisplayedElement = function (name) {
	if (this.elements[name]) {
		return this.elements[name].isDisplayed && this.elements[name].settings.get(this.elements[name].value).length > 0;
	}

	return false;
};

/**
 *
 * @param name
 */
ScreenResolutionEditor.prototype.markElement = function (name) {
	if (this.elements[name]) {
		this.markedElement = name;
		this._rebuildMarkElements();
	}

	return false;
};

/**
 *
 * @param name
 */
ScreenResolutionEditor.prototype.hightlightElement = function (name) {
    for (var y = 0; y < this.cellGrid.length; y++) {
        for (var x = 0; x < this.cellGrid[y].length; x++) {
            this.cellGrid[y][x].removeClass('hightlight');
            this.cellGrid[y][x].removeClass('hightlight-red');
        }
    }

	if(!this.elements[name]){
        this.control.hightlightElement(false);
		return;
	}

	var element = this.elements[name];
    var list = element.settings.get(element.value);
	if(element){
		for(var itemKey in list){
			var cell =  this.cellGrid[element.position[1] + list[itemKey].position[1]][element.position[0] +  list[itemKey].position[0]];

			if(cell){
                this.cellGrid[element.position[1] + list[itemKey].position[1]][element.position[0] +  list[itemKey].position[0]].addClass(element.settings.canMove ? 'hightlight' : 'hightlight-red');
			}
		}

        this.control.hightlightElement(name);
	}
};

/**
 *
 * @param name
 */
ScreenResolutionEditor.prototype._rebuildMarkElements = function () {

	this.osdGrid.find('td').removeClass('marked');
	var _this = this;

	clearTimeout(_this.markedTimeout);

	if (this.elements[this.markedElement]) {
		var element = this.elements[this.markedElement];
		var list = element.settings.get(element.value);
		for (var i = 0; i < list.length; i++) {
			this.osdGrid.find('tr:nth-child(' + (list[i].position[1] + 1 + element.position[1]) + ')').find('td:nth-child(' + (list[i].position[0] + 1 + element.position[0]) + ')').addClass('marked');
		}

		if (!(this.elements[this.markedElement].isDisplayed == false)) {

			_this.markedTimeout = setTimeout(function () {
				$('.marked').removeClass('marked');
			}, 3000)
		}

	}

	return false;
};


/**
 *
 * @param name
 * @returns {*}
 */
ScreenResolutionEditor.prototype.getElementPosition = function (name) {
	if (this.elements[name]) {
		return [this.elements[name].position[0] - this.elements[name].settings.offsetX, this.elements[name].position[1] - this.elements[name].settings.offsetY];
	}

	return [0, 0]
};

/**
 *
 * @param name
 * @returns {*}
 */
ScreenResolutionEditor.prototype.getElementPositionInProfile = function (name) {
    if (this.elements[name]) {
        return this.elements[name].positionInProfile;
    }

    return -1
};

/**
 *
 * @param name
 * @returns {*}
 */
ScreenResolutionEditor.prototype.getModificatorPositionInProfile = function (name) {
    if (this.modificator[name]) {
        return this.modificator[name].positionInProfile;
    }

    return -1
};

/**
 *
 * @param name
 * @returns {*}
 */
ScreenResolutionEditor.prototype.removeAllElements = function () {
	this.elements = [];
    this.modificator = [];
	this.clearScreen();
};

/**
 *
 */
ScreenResolutionEditor.prototype.clearScreen = function () {
	for (var y = 0; y < this.canvasGrid.length; y++) {
		for (var x = 0; x < this.canvasGrid[y].length; x++) {
			var ctx = this.canvasGrid[y][x];
			ctx.clearRect(0, 0, this.canvas[0].width, this.canvas[0].height);
            this.cellGrid[y][x].data('elementName', null);
		}
	}
};

/**
 * move element to relative position, and check whether is posible move element to position
 *
 * @param x
 * @param y
 * @param name
 */
ScreenResolutionEditor.prototype.moveElementToPositionX = function (name, x) {
	if (this.elements[name]) {
		var element = this.elements[name];

		if(!element.settings.canMove){
			return false;
		}

		element.position = [element.position[0] + x, element.position[1]];
		return x;
	} else {
		return false;
	}
};

ScreenResolutionEditor.prototype.moveElementToPosition = function (name, x, y) {
    if (this.elements[name]) {
        var element = this.elements[name];

        if(!element.settings.canMove){
            return false;
        }
        x = this.elements[name].settings.offsetX + x;
        y = this.elements[name].settings.offsetY + y;

        element.position = [x, y];
        return x;
    } else {
        return false;
    }
};

/**
 * move element to relative position, and check whether is posible move element to position
 *
 * @param x
 * @param y
 * @param name
 */
ScreenResolutionEditor.prototype.moveElementToPositionY = function (name, y) {
	if (this.elements[name]) {
		var element = this.elements[name];

		if(!element.settings.canMove){
			return false;
		}

		element.position = [element.position[0], element.position[1] + y];
		return y;
	} else {
		console.log('element ' + name + ' doesnt exist');
		return false;

	}
};

/**
 *
 * if add element, so it is hiden, we have to set display to on, if we want to display element
 *
 * @param name
 * @param displayedState
 */
ScreenResolutionEditor.prototype.setDisplayedElement = function (name, displayedState, x, y) {
	var displayedState = Boolean(displayedState);
	if (this.elements[name]) {
		x = this.elements[name].settings.offsetX + x;
		y = this.elements[name].settings.offsetY + y;

		this.elements[name].position = [x, y];

		if (this.elements[name].isDisplayed && !displayedState) {
			this.elements[name].isDisplayed = false ^ this.elements[name].isDisplayed;
			return true;
		}

		if (!this.elements[name].isDisplayed && displayedState) {
			//check is in area
			this.elements[name].isDisplayed = true ^ this.elements[name].isDisplayed;
			return true;
		}
	} else {
		console.log('element ' + name + ' doesnt exist');
	}
};

/**
 * internal function
 *
 * @param name
 */
ScreenResolutionEditor.prototype._reDrawScreen = function () {
	this.clearScreen();
	this._rebuildMarkElements();
	for (var elementKey in this.elements) {
		var element = this.elements[elementKey];

		if (!element.isDisplayed) {
			continue;
		}

		var list = element.settings.get(element.value);

		for (var i = 0; i < list.length; i++) {
			var fontWrite = list[i].element;

			if (this.scale != fontWrite.scale) {
				fontWrite.setScale(this.scale);
			}

			if (
				this.canvasGrid[element.position[1] + list[i].position[1]]
				&&
				this.canvasGrid[element.position[1] + list[i].position[1]][element.position[0] + list[i].position[0]]
			) {
				var imageData = this.canvasGrid[element.position[1] + list[i].position[1]][element.position[0] + list[i].position[0]].getImageData(0, 0, fontWrite.imgData.width, fontWrite.imgData.height);

				this.canvasGrid[element.position[1] + list[i].position[1]][element.position[0] + list[i].position[0]].putImageData(this._combineImageData(imageData, fontWrite.imgData), 0, 0);
				this.cellGrid[element.position[1] + list[i].position[1]][element.position[0] + list[i].position[0]].data('elementName', elementKey);
			}
		}
	}

	this.hightlightElement();
};

/**
 *
 * @param data1
 * @param data2
 * @private
 */
ScreenResolutionEditor.prototype._combineImageData = function (ImageData1, ImageData2) {
	for (var i = 0; i < ImageData1.data.length; i = i + 4) { // iterate through the imageDataArray
		if (ImageData1.data[i] == 0 && ImageData1.data[i + 1] == 0 && ImageData1.data[i + 2] == 0 && ImageData1.data[i + 3] == 0) {
			ImageData1.data[i] = ImageData2.data[i];
			ImageData1.data[i + 1] = ImageData2.data[i + 1];
			ImageData1.data[i + 2] = ImageData2.data[i + 2];
			ImageData1.data[i + 3] = ImageData2.data[i + 3];
		}

	}

	return ImageData1;

};

/**
 * set value to setting class, be careful for type of variable
 *
 * @param name
 */
ScreenResolutionEditor.prototype.setValue = function (name, value) {
	if (this.elements[name] && value != null && this.elements[name].value != value) {
		this.elements[name].value = value;
        this._reDrawScreen();
	}
}
;

/**
 *
 * @param fonMap
 */
ScreenResolutionEditor.prototype.setNewFontMap = function () {
	this._reDrawScreen();
};

/**
 *
 * @param name
 */
ScreenResolutionEditor.prototype.createImageFromElement = function(name){
	if(this.elements[name]){

        var element = this.elements[name];
        var list = element.settings.get(element.value, true);

        //count max dimension
		var maxX = 0;
		var maxY = 0;

		var baseSize = [0, 0];


		//scale
        for (var i = 0; i < list.length; i++) {
            var fontWrite = list[i].element;

            if (this.scale != fontWrite.scale) {
                fontWrite.setScale(this.scale);
            }
        }

		for (var i = 0; i < list.length; i++) {
			maxX = Math.max(maxX, list[i].position[0]);
            maxY = Math.max(maxY, list[i].position[1]);

            baseSize = [ list[i].element.baseSize[0], list[i].element.baseSize[1]];

        }
        maxX += 1;
        maxY += 1;

        var canvas = $('<canvas>');
        canvas.attr('width', (baseSize[0] * maxX) + 'px');
        canvas.attr('height', (baseSize[1] * maxY)  + 'px');

        var ctx = canvas[0].getContext("2d");

        for (var i = 0; i < list.length; i++) {
            var fontWrite = list[i].element;

			ctx.putImageData(fontWrite.imgData, list[i].position[0] * baseSize[0] , list[i].position[1] * baseSize[1]);
        }

       return canvas;
	}
};

/**
 *
 * @param url
 */
ScreenResolutionEditor.prototype.loadImageByUrl = function (url) {
    var deferred = $.Deferred();

	this.imageObj.src = url;
    this.imageObj.onload = function () {
        deferred.resolve();
    };

    return deferred.promise();
};


/* ##################################################### */
