
var DefaultV16 = '[{"index":0,"values":{"command":9,"values":{"0":16,"1":1,"2":0,"3":0,"4":34,"5":0,"6":8,"7":0,"8":0,"9":4},"specialValues":{}}},{"index":10,"values":{"command":9,"values":{"10":200,"11":0,"12":3,"13":0,"14":0,"15":1,"16":1,"17":1,"18":200,"19":0},"specialValues":{}}},{"index":20,"values":{"command":9,"values":{"20":50,"21":100,"22":2,"23":0,"24":2,"25":0,"26":2,"27":1,"28":0,"29":1},"specialValues":{}}},{"index":30,"values":{"command":9,"values":{"30":0,"31":7,"32":0,"33":0,"34":0,"35":0,"36":0,"37":0,"38":1,"39":8},"specialValues":{}}},{"index":40,"values":{"command":9,"values":{"40":0,"41":0,"42":0,"43":30,"44":30,"45":20,"46":77,"47":87,"48":79,"49":83},"specialValues":{}}},{"index":50,"values":{"command":9,"values":{"50":68,"51":0,"52":32,"53":32,"54":32,"55":32,"56":0,"57":0,"58":0,"59":0},"specialValues":{}}},{"index":60,"values":{"command":9,"values":{"60":15,"61":6,"62":0,"63":0,"64":0,"65":0,"66":0,"67":150,"68":0,"69":0},"specialValues":{}}},{"index":70,"values":{"command":9,"values":{"70":0,"71":255,"72":3,"73":0,"74":2,"75":244,"76":1,"77":32,"78":192,"79":50},"specialValues":{}}},{"index":80,"values":{"command":9,"values":{"80":192,"81":52,"82":192,"83":182,"84":192,"85":143,"86":0,"87":173,"88":0,"89":36},"specialValues":{}}},{"index":90,"values":{"command":9,"values":{"90":192,"91":113,"92":0,"93":40,"94":192,"95":203,"96":192,"97":202,"98":192,"99":96},"specialValues":{}}},{"index":100,"values":{"command":9,"values":{"100":193,"101":126,"102":1,"103":126,"104":193,"105":55,"106":193,"107":36,"108":1,"109":66},"specialValues":{}}},{"index":110,"values":{"command":9,"values":{"110":1,"111":2,"112":192,"113":15,"114":192,"115":76,"116":193,"117":248,"118":0,"119":106},"specialValues":{}}},{"index":120,"values":{"command":9,"values":{"120":193,"121":46,"122":1,"123":113,"124":193,"125":120,"126":193,"127":194,"128":192,"129":187},"specialValues":{}}},{"index":130,"values":{"command":9,"values":{"130":192,"131":187,"132":0,"133":3,"134":0,"135":7,"136":0,"137":92,"138":0,"139":251},"specialValues":{}}},{"index":140,"values":{"command":9,"values":{"140":0,"141":6,"142":1,"143":62,"144":192,"145":52,"146":0,"147":195,"148":0,"149":100},"specialValues":{}}},{"index":150,"values":{"command":9,"values":{"150":192,"151":16,"152":1,"153":186,"154":0,"155":86,"156":1,"157":220,"158":0,"159":233},"specialValues":{}}},{"index":160,"values":{"command":9,"values":{"160":0,"161":242,"162":0,"163":212,"164":0,"165":152,"166":0,"167":128,"168":0,"169":218},"specialValues":{}}},{"index":170,"values":{"command":9,"values":{"170":0,"171":82,"172":0,"173":158,"174":0,"175":122,"176":0,"177":32,"178":192,"179":50},"specialValues":{}}},{"index":180,"values":{"command":9,"values":{"180":192,"181":52,"182":192,"183":182,"184":192,"185":143,"186":0,"187":173,"188":0,"189":36},"specialValues":{}}},{"index":190,"values":{"command":9,"values":{"190":192,"191":113,"192":0,"193":40,"194":192,"195":203,"196":192,"197":202,"198":192,"199":96},"specialValues":{}}},{"index":200,"values":{"command":9,"values":{"200":193,"201":126,"202":1,"203":126,"204":193,"205":55,"206":193,"207":36,"208":1,"209":66},"specialValues":{}}},{"index":210,"values":{"command":9,"values":{"210":1,"211":2,"212":192,"213":15,"214":192,"215":76,"216":193,"217":248,"218":0,"219":106},"specialValues":{}}},{"index":220,"values":{"command":9,"values":{"220":193,"221":46,"222":1,"223":113,"224":193,"225":120,"226":193,"227":194,"228":192,"229":187},"specialValues":{}}},{"index":230,"values":{"command":9,"values":{"230":192,"231":187,"232":0,"233":3,"234":0,"235":7,"236":0,"237":92,"238":0,"239":251},"specialValues":{}}},{"index":240,"values":{"command":9,"values":{"240":0,"241":6,"242":1,"243":62,"244":192,"245":52,"246":0,"247":195,"248":0,"249":100},"specialValues":{}}},{"index":250,"values":{"command":9,"values":{"250":192,"251":16,"252":1,"253":186,"254":0,"255":86,"256":1,"257":220,"258":0,"259":233},"specialValues":{}}},{"index":260,"values":{"command":9,"values":{"260":0,"261":242,"262":0,"263":212,"264":0,"265":152,"266":0,"267":128,"268":0,"269":218},"specialValues":{}}},{"index":270,"values":{"command":9,"values":{"270":0,"271":82,"272":0,"273":158,"274":0,"275":122,"276":0,"277":32,"278":192,"279":50},"specialValues":{}}},{"index":280,"values":{"command":9,"values":{"280":192,"281":52,"282":192,"283":182,"284":192,"285":143,"286":0,"287":173,"288":0,"289":36},"specialValues":{}}},{"index":290,"values":{"command":9,"values":{"290":192,"291":113,"292":0,"293":40,"294":192,"295":203,"296":192,"297":202,"298":192,"299":96},"specialValues":{}}},{"index":300,"values":{"command":9,"values":{"300":193,"301":126,"302":1,"303":126,"304":193,"305":55,"306":193,"307":36,"308":1,"309":66},"specialValues":{}}},{"index":310,"values":{"command":9,"values":{"310":1,"311":2,"312":192,"313":15,"314":192,"315":76,"316":193,"317":248,"318":0,"319":106},"specialValues":{}}},{"index":320,"values":{"command":9,"values":{"320":193,"321":46,"322":1,"323":113,"324":193,"325":120,"326":193,"327":194,"328":192,"329":187},"specialValues":{}}},{"index":330,"values":{"command":9,"values":{"330":192,"331":187,"332":0,"333":3,"334":0,"335":7,"336":0,"337":92,"338":0,"339":251},"specialValues":{}}},{"index":340,"values":{"command":9,"values":{"340":0,"341":6,"342":1,"343":62,"344":192,"345":52,"346":0,"347":195,"348":0,"349":100},"specialValues":{}}},{"index":350,"values":{"command":9,"values":{"350":192,"351":16,"352":1,"353":186,"354":0,"355":86,"356":1,"357":220,"358":0,"359":233},"specialValues":{}}},{"index":360,"values":{"command":9,"values":{"360":0,"361":242,"362":0,"363":212,"364":0,"365":152,"366":0,"367":128,"368":0,"369":218},"specialValues":{}}},{"index":370,"values":{"command":9,"values":{"370":0,"371":82,"372":0,"373":158,"374":0,"375":122,"376":0,"377":0,"378":0,"379":150},"specialValues":{}}},{"index":380,"values":{"command":9,"values":{"380":0,"381":0,"382":0,"383":255,"384":3,"385":0,"386":2,"387":244,"388":1,"389":16},"specialValues":{}}},{"index":390,"values":{"command":9,"values":{"390":1,"391":0,"392":0,"393":34,"394":0,"395":8,"396":0,"397":0,"398":4,"399":200},"specialValues":{}}},{"index":400,"values":{"command":9,"values":{"400":0,"401":3,"402":0,"403":0,"404":1,"405":1,"406":1,"407":200,"408":0,"409":50},"specialValues":{}}},{"index":410,"values":{"command":9,"values":{"410":100,"411":2,"412":0,"413":2,"414":0,"415":2,"416":1,"417":0,"418":1,"419":0},"specialValues":{}}}]';

var layoutAddressV16 = [
    [77, 176], [177, 276], [277, 376]
];


/**
 *
 * @type {*[]}
 */
SettingsElementsV16 = [
    {
        id: 'S_AUTOCELL',
        position: 1,
        description: 'Auto Detect',
        type: SettingsElementsType.select,
        group: [
            SettingsElementsGroup.G_Voltage
//            SettingsElementsGroup.G_Other, //FOR TEST
//            SettingsElementsGroup.G_Alarms,//FOR TEST
//            SettingsElementsGroup.G_Amperage,//FOR TEST
//            SettingsElementsGroup.G_GPS,//FOR TEST
//            SettingsElementsGroup.G_HUD//FOR TEST
        ],
        properties: {
            order: 2,
            values: [
                'Use battery cell count / alarm',
                'Autodetect cell count and cell alarm'
            ]
        }
    },
    {
        id: 'S_VIDVOLTAGEMIN',
        position: 2,
        description: 'Video Voltage Alarm',
        type: SettingsElementsType.range,
        group: [SettingsElementsGroup.G_VVoltage],
        properties: {
            max: 255,
            divider: 10
        }
    },
    {
        id: 'S_RSSI_ALARM',
        position: 3,
        description: 'RSSI Alarm',
        type: SettingsElementsType.range,
        properties: {
            max: 100,
//			divider: 10,
        },
        group: [SettingsElementsGroup.G_RSSI]
    },
    {
        id: 'S_AUTOCELL_ALARM',
        position: 4,
        description: 'Autodetect cell alarm value',
        type: SettingsElementsType.range,
        properties: {
            max: 255,
            divider: 10,
            order: 3,
        },
        group: [SettingsElementsGroup.G_Voltage]
    },
    {
        id: 'S_MWRSSI',
        position: 5,
        description: 'RSSI source',
        type: SettingsElementsType.select,
        properties: {
            order: 1,
            values: [
                'Direct OSD connect Analog',
                'Direct OSD connect - 50hz PWM',
                'RSSI from Flight Controller',
                'RSSI from RC channel'
            ]
        },
        group: [SettingsElementsGroup.G_RSSI]
    },
    {
        id: 'S_RSSI_CH',
        position: 6,
        description: 'RSSI channel',
        type: SettingsElementsType.select,
        properties: {
            values: {
                1: "1",
                2: "2",
                3: "3",
                4: "4",
                5: "5",
                6: "6",
                7: "7",
                8: "8",
                9: "9",
                10: "10",
                11: "11",
                12: "12",
                13: "13",
                15: "15",
                16: "16"
            }
        },
        group: [SettingsElementsGroup.G_RSSI]
    },
    {
        id: 'S_TX_TYPE',
        position: 7,
        description: 'Transmiter type',
        type: SettingsElementsType.select,
        properties: {
            order: 7,
            values: [
                'Roll/Pitch/Yaw/Throttle',
                'Roll/Pitch/Throttle/Yaw',
                'Throttle/Roll/Pitch/Yaw'
            ]},
        group: [
            SettingsElementsGroup.G_GOSD,
            SettingsElementsGroup.G_MAVLINK
        ]
    },
    {
        id: 'S_VOLTAGEMIN',
        position: 8,
        description: 'Voltage Alarm',
        type: SettingsElementsType.range,
        properties: {
            max: 255,
            divider: 10
        },
        group: [SettingsElementsGroup.G_Voltage]
    },
    {
        id: 'S_BATCELLS',
        position: 9,
        description: 'Battery Cell Count',
        type: SettingsElementsType.select,
        properties: {
            values: {
                1: "1S (3.7V)",
                2: "2S (7.4V)",
                3: "3S (11.1V)",
                4: "4S (14.8V)",
                5: "5S (18.5V)",
                6: "6S (22.2V)",                
            }
        },
        group: [SettingsElementsGroup.G_Voltage]
    },
    {
        id: 'S_DIVIDERRATIO',
        position: 10,
        description: 'Main Voltage Adjust',
        type: SettingsElementsType.range,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_Voltage]
    },
    {
        id: 'S_MAINVOLTAGE_VBAT',
        position: 11,
        description: 'Main Voltage source',
        type: SettingsElementsType.select,
        properties: {
            order: 1,
            values: [
                'Use direct connect voltage',
                'Use Flight Controller voltage'
            ]
        },
        group: [SettingsElementsGroup.G_Voltage]
    },
    {
        id: 'S_SIDEBARHEIGHT',
        position: 12,
        description: 'HUD sidebar height',
        type: SettingsElementsType.select,
        properties: {
            values: {
                3: "3",
                4: "4",
                5: "5",
                6: "6"
            }
        },
        group: [SettingsElementsGroup.G_HUD]
    },
    {
        id: 'S_MWAMPERAGE',
        position: 13,
        description: 'Amperage',
        type: SettingsElementsType.select,
        properties: {
            values: [
                'Use direct connect current sensor',
                'Use Flight Controller amperage',
                'Use Virtual Sensor (throttle)'
            ]
        },
        group: [SettingsElementsGroup.G_Amperage]
    },
    {
        id: 'S_TX_REVERSE',
        position: 14,
        description: 'Transmiter reverse',
        type: SettingsElementsType.select,
        properties: {
             order: 8,
           values: [
                'No reversing',
                'Ch1',
                'Ch2',
                'Ch1, Ch2',
                'Ch3',
                'Ch1, Ch3',
                'Ch2, Ch3',
                'Ch1, Ch2, Ch3',
                'Ch4',
                'Ch1, Ch4',
                'Ch2, Ch4',
                'Ch1, Ch2, Ch4',
                'Ch3, Ch4',
                'Ch1, Ch3, Ch4',
                'Ch2, Ch3, Ch4',
                'Ch1, Ch2, Ch3, Ch4'
            ]
        },
        group: [
            SettingsElementsGroup.G_GOSD,
            SettingsElementsGroup.G_MAVLINK
        ]
    },
    {
        id: 'S_MAV_SYS_ID',
        position: 15,
        description: 'Mavlink System ID',
        type: SettingsElementsType.range,
        properties: {
            order: 1,
            min: 0,
            max: 254
        },
        group: [SettingsElementsGroup.G_MAVLINK]
    },
    {
        id: 'S_ALARMS_TEXT',
        position: 16,
        description: 'Text alarms',
        type: SettingsElementsType.select,
        properties: {
            order: 4,
            values: [
                'Hide text alarms',
                'Show text alarms'
            ]
        },
        group: [SettingsElementsGroup.G_Display]
    },
    {
        id: 'S_CALLSIGN_ALWAYS',
        position: 17,
        description: 'Display callsign',
        type: SettingsElementsType.select,
        properties: {
            values: [
                'Disabled',
                'Show Permanently',
                'Display for 4 seconds every minute',
                'Grafic logo'
            ]
        },
        group: [SettingsElementsGroup.G_CallSign]
    },
    {
        id: 'S_VIDDIVIDERRATIO',
        position: 18,
        description: 'Video Voltage Adjust',
        type: SettingsElementsType.range,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_VVoltage]
    },
    {
        id: 'S_THROTTLE_PWM',
        position: 19,
        description: 'Throttle display',
        type: SettingsElementsType.select,
        properties: {
            order: 6,
            max: 255,
            values: [
                'Display % value',
                'Display PWM value'
            ]
        },
        group: [SettingsElementsGroup.G_Display]
    },
    {
        id: 'S_AMPER_HOUR_ALARM',
        position: 20,
        description: 'mAh Alarm',
        type: SettingsElementsType.range,
        properties: {
            max: 255,
            divider: 0.01,
            step: 100
        },
        group: [SettingsElementsGroup.G_Amperage]
    },
    {
        id: 'S_AMPERAGE_ALARM',
        position: 21,
        description: 'Amp Alarm',
        type: SettingsElementsType.range,
        properties: {
            max: 255
        },
        group: [SettingsElementsGroup.G_Amperage]
    },
    {
        id: 'S_VARIO_SCALE',
        position: 22,
        description: 'VARIO indicator size',
        type: SettingsElementsType.select,
        properties: {
            order: 10,
            values: {
                1: "Single character",
                2: "Three rows high",
                3: "Five rows high",
                4: "Seven rows high",
                5: "Nine rows high"
            }
        },
        group: [SettingsElementsGroup.G_Display]
    },
    {
        id: 'S_GPS_MASK',
        position: 23,
        description: 'GPS display type',
        type: SettingsElementsType.select,
        group: [SettingsElementsGroup.G_Display],
        properties: {
            values: [
                'Display real co-ordinates',
                'Display with false major digits'
            ]
        },
    },
    {
        id: 'S_USEGPSHEADING',
        position: 24,
        description: 'FixedWing alt/heading (MSP FC only)',
        type: SettingsElementsType.select,
        properties: {
            values: [
                'Use BARO altitude, MAG heading',
                'Use BARO altitude, GPS heading',
                'Use GPS altitude, GPS heading'
            ]
        },
        group: [SettingsElementsGroup.G_Other]
    },
    {
        id: 'S_UNITSYSTEM',
        position: 25,
        description: 'Units Of Measure',
        type: SettingsElementsType.select,
        properties: {
            order: 3,
            values: [
                'Metric',
                'Imperial',
            ]
        },
        group: [SettingsElementsGroup.G_Display]
    },
    {
        id: 'S_VIDEOSIGNALTYPE',
        position: 26,
        description: 'Video Signal Type',
        type: SettingsElementsType.select,
        properties: {
            order: 2,
            values: [
                'NTSC',
                'PAL',
                'AUTO'
            ]
        },
        group: [SettingsElementsGroup.G_Other]
    },
    {
        id: 'S_SHOWBATLEVELEVOLUTION',
        position: 27,
        description: 'Main Battery Icon',
        type: SettingsElementsType.select,
        properties: {
            order: 13,
            values: [
                'Static battery icon',
                'Remaining capacity icon'
            ]
        },
        group: [SettingsElementsGroup.G_Voltage]
    },
    {
        id: 'S_RESETSTATISTICS',
        position: 28,
        description: 'Statistics',
        type: SettingsElementsType.select,
        properties: {
            order: 5,
            values: [
                'Show total flight',
                'Show since last armed'
            ]
        },
        group: [SettingsElementsGroup.G_Other]
    },
    {
        id: ' S_MAPMODE',
        position: 29,
        description: 'Map mode display type',
        type: SettingsElementsType.select,
        properties: {
            order: 14,
            values: [
                'Disabled',
                'Show home position',
                'Show aircraft position',
                'Show both positions',
                'Show aircraft position and direction'
            ]
        },
        group: [SettingsElementsGroup.G_Display]
    },
    {
        id: 'S_VREFERENCE',
        position: 30,
        description: 'Analog sensor reference',
        type: SettingsElementsType.select,
        properties: {
            order: 1,
            values: [
                '1.1v - 4s max',
                '5.0v - 6s or analog sensors'
            ]
        },
        group: [SettingsElementsGroup.G_Other]
    },
    {
        id: 'S_SIDEBARWIDTH,',
        position: 31,
        description: 'HUD sidebar width',
        type: SettingsElementsType.select,
        properties: {
            values: {
                3: "3",
                4: "4",
                5: "5",
                6: "6",
                7: "7",
                8: "8",
                9: "9",
                10: "10",
                11: "11",
                12: "12",
                13: "13",
                14: "14"
            }
        },
        group: [SettingsElementsGroup.G_HUD]
    },
   {
        id: 'S_GPSTIME',
        position: 32,
        description: 'Flight date & time',
        type: SettingsElementsType.select,
        properties: {
            values: {
                0: "Do not display",
                1: "Display at arming",
            }
        },
        group: [SettingsElementsGroup.G_Display]
    },
/*    {
        id: 'S_GPSTZAHEAD',
        position: 33,
        description: 'GPS head',
        type: SettingsElementsType.checkbox,
        properties: {},
        group: [SettingsElementsGroup.G_GPS]
    }, */
    {
        id: 'S_GPSTZ',                    
        position: 34,
        description: 'GPS time zone',
        type: SettingsElementsType.range,
        properties: {
            order: 20 ,
            min: -11 + 128,
            max: 14 + 128,
            translate: new TranslateSignedInt()
        },
        group: [SettingsElementsGroup.G_Display]
    }, 
    {
        id: 'S_VTX_POWER',
        position: 35,
        description: 'VTX Power',
        type: SettingsElementsType.select,
        properties: {
            values: [
                '50mW',
                '200mW',
                '600mW',
                '800mW'
            ]
        },
        group: [SettingsElementsGroup.G_VTX]
    },
    {
        id: 'S_VTX_BAND',
        position: 36,
        description: 'VTX Band',
        type: SettingsElementsType.select,
        properties: {
            values: [
                'A',
                'B',
                'E',
                'F',
                'C (Raceband)'
            ]
        },
        group: [SettingsElementsGroup.G_VTX]
    },
    {
        id: 'S_VTX_CHANNEL',
        position: 37,
        description: 'VTX Channel',
        type: SettingsElementsType.select,
        properties: {
            values: [
                'CH 1',
                'CH 2',
                'CH 3',
                'CH 4',
                'CH 5',
                'CH 6',
                'CH 7',
                'CH 8',
            ]},
        group: [SettingsElementsGroup.G_VTX]
    },
    {
        id: 'S_RCWSWITCH',
        position: 38,
        description: ['OSD Screen Switch'],
        type: SettingsElementsType.select,
        properties: {
            order: 1,
            values: [
                'Use Flight Controller OSD switch',
                'Use RC channel'
            ]
        },
        group: [SettingsElementsGroup.G_RCSWITCH]
    },
    {
        id: 'S_RCWSWITCH_CH',
        position: 39,
        description: 'Screen switch RC Channel',
        type: SettingsElementsType.select,
        properties: {
            values: {
                1: "1",
                2: "2",
                3: "3",
                4: "4",
                5: "5",
                6: "6",
                7: "7",
                8: "8",
                9: "9",
                10: "10",
                11: "11",
                12: "12",
                13: "13",
                15: "15",
                16: "16"
            }
        },
        group: [SettingsElementsGroup.G_RCSWITCH]
    },
    {
        id: 'S_DISTANCE_ALARM',
        position: 40,
        description: 'Distance Alarm',
        type: SettingsElementsType.range,
        properties: {
            max: 255,
            divider: 0.01,
            step: 100
        },
        group: [SettingsElementsGroup.G_Alarms]
    },
    {
        id: 'S_ALTITUDE_ALARM',
        position: 41,
        description: 'Altitude Alarm',
        type: SettingsElementsType.range,
        properties: {
            max: 255,
            divider: 0.01,
            step: 100
        },
        group: [SettingsElementsGroup.G_Alarms]
    },
    {
        id: 'S_SPEED_ALARM',
        position: 42,
        description: 'Speed Alarm',
        type: SettingsElementsType.range,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_Alarms]
    },
    {
        id: 'S_FLYTIME_ALARM',
        position: 43,
        description: 'Timer Alarm',
        type: SettingsElementsType.range,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_Alarms]
    },
    {
        id: 'S_AUDVARIO_DEADBAND',
        position: 44,
        description: 'Audio Vario deadband',
        type: SettingsElementsType.range,
        properties: {order: 11, max: 254},
        group: [SettingsElementsGroup.G_Custom]
    }, {
        id: 'S_AUDVARIO_TH_CUT',
        position: 45,
        description: 'Audio Vario throttle switch',
        type: SettingsElementsType.range,
        properties: {
            order: 12,
            min: 10,
            max: 20,
            step: 100,
            divider: 0.01
        },
        group: [SettingsElementsGroup.G_Custom]
    },
    {
        id: 'S_CS0',
        position: 46,
        description: 'S_CS0',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS1',
        position: 47,
        description: 'S_CS1',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS2',
        position: 48,
        description: 'S_CS2',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS3',
        position: 49,
        description: 'S_CS3',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS4',
        position: 50,
        description: 'S_CS4',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS5',
        position: 51,
        description: 'S_CS5',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS6',
        position: 52,
        description: 'S_CS6',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS7',
        position: 53,
        description: 'S_CS7',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS8',
        position: 54,
        description: 'S_CS8',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS9',
        position: 55,
        description: 'S_CS9',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    },{
        id: 'S_PWM_PPM',
        position: 56,
        description: 'AEROMAX OSD - RC source type',
        type: SettingsElementsType.select,
        properties: {
            order: 9,
            values: [
                'PWM',
                'PPM'
            ]
        },
        group: [SettingsElementsGroup.G_GOSD]
    },{
        id: 'S_ELEVATIONS',
        position: 57,
        description: 'AHI minor elevations',
        type: SettingsElementsType.select,
        properties: {
            values: [
                'Disabled',
                'Enabled'
            ]
        },
        group: [SettingsElementsGroup.G_HUD]
    },{
        id: 'S_ALTRESOLUTION',
        position: 58,
        description: 'High resolution altitude display cutoff',
        type: SettingsElementsType.range,
        group: [SettingsElementsGroup.G_Display],
        properties: {max: 99},
    },{
        id: 'S_FLIGHTMODETEXT',
        position: 59,
        description: 'Flight mode display - MSP FC',
        type: SettingsElementsType.select,
        group: [SettingsElementsGroup.G_Display],
        properties: {
            values: [
                'Text Mode',
                'Icon mode'
            ]
        },
    },{
        id: 'S_BRIGHTNESS',
        position: 60,
        description: 'Brightness',
        type: SettingsElementsType.select,
        group: [SettingsElementsGroup.G_Display],
        properties: {
            values: {
                1 :'Default',
                0: 'High',
                10: 'Medium',
                15: 'Low',
            }
        },
    },{
        id: 'S_MAV_ALARM_LEVEL',
        position: 61,
        description: 'Mavlink alarms',
        type: SettingsElementsType.select,
        group: [SettingsElementsGroup.G_MAVLINK],
        properties: {
            order: 2,
            values: [
                'Emergency',
                'Alert',
                'Critical',
                'Error',
                'Warning',
                'Notice',
                'Info',
                'Debug',
            ]
        },
    },{
    id: 'S_MAV_AUTO',
        position: 64,
        description: 'Mavlink - autoconfigure serial port',
        type: SettingsElementsType.checkbox,
        group: [SettingsElementsGroup.G_MAVLINK],
        properties: {order: 3},
    },{
        id: 'S16_AMPZERO',
        position: 65,
        secondByte: 66,
        description: 'Amps Zero Adjust',
        type: SettingsElementsType.range,
        properties: {max: 1023},
        group: [SettingsElementsGroup.G_Amperage]
    },
    {
        id: ' S16_AMPDIVIDERRATIO',
        position: 67,
        secondByte: 68,
        description: 'Amps adjust',
        type: SettingsElementsType.range,
        properties: {max: 1023},
        group: [SettingsElementsGroup.G_Amperage]
    },
    {
        id: 'S16_RSSIMIN',
        position: 69,
        secondByte: 70,
        description: 'RSSI calibration Minimum',
        type: SettingsElementsType.range,
        properties: {max: 1023},
        group: [SettingsElementsGroup.G_RSSI]
    },
    {
        id: 'S16_RSSIMAX',
        position: 71,
        secondByte: 72,
        description: 'RSSI calibration Maximum',
        type: SettingsElementsType.range,
        properties: {max: 1023},
        group: [SettingsElementsGroup.G_RSSI]
    },
    {
        id: 'S16_AIRSPEEDZERO',
        position: 73,
        secondByte: 74,
        description: 'AUX sensor Zero calibration',
        type: SettingsElementsType.range,
        properties: {max: 1023},
        group: [SettingsElementsGroup.G_Custom]
    },
    {
        id: 'S16_AIRSPEEDCAL',
        position: 75,
        secondByte: 76,
        description: 'AUX sensor calibration',
        type: SettingsElementsType.range,
        properties: {max: 1023},
        group: [SettingsElementsGroup.G_Custom]
    }
];

