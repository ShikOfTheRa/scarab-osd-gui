McmEnum = [
    {
        name: 'bold.mcm',
        url: 'data/mcm/bold.mcm'
    },
    {
        name: 'large.mcm',
        url: 'data/mcm/large.mcm'
    },
    {
        name: 'default.mcm',
        url: 'data/mcm/default.mcm'
    }
];