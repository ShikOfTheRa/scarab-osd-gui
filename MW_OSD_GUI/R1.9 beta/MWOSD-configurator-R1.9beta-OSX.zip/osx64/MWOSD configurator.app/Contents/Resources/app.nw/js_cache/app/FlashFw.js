FlashFw = function(port, Log, maxHexSize, hexListUrl){
    var _this = this;
    this.maxHexSize = maxHexSize;

    this.Log = Log;
    this.hexListUrl = hexListUrl;
    this.hexListJson = {};
    this.descriptionList = {};
    this.port = port;

    this.FLAVOR_PICKED = analytics.EventBuilder.builder()
        .category('flash_fw')
        .action('flash');

    this.listFWVersion = $('#listFWVersion');
    this.listFWVersion.selectmenu();

    this.listFWDevice = $('#listFWDevice');
    this.listFWDevice.selectmenu();
    this.listFWDevice.selectmenu('disable');

    this.listFWVariant = $('#listFWVariant');
    this.listFWVariant.selectmenu();
    this.listFWVariant.selectmenu('disable');

    this.fwTestVersion = $('#fwTestVersion');
    this.fwTestVersion.change(function(){
        _this.fillSelectVersion();
    });

    this.descriptionBox = $('#fw_description');

    this.listFWType = $('#listFWType');
    this.listFWType.selectmenu();
    this.listFWType.selectmenu('disable');

    this.loadFileFromDiskButton = $('#loadFwFromDisk').button().click(function(){_this.openFile()});
    this.loadFileFromWebButton = $('#loadFwFromWeb').button().click(function(){
        var version = _this.listFWVersion.val();
        var device = _this.listFWDevice.val();
        var variant = _this.listFWVariant.val();
        var type = _this.listFWType.val();

        if(_this.hexListJson && _this.hexListJson[version] && _this.hexListJson[version][device] && _this.hexListJson[version][device][variant] && _this.hexListJson[version][device][variant][type])
        {
            _this.loadHexFromWeb(version + ' -> ' +device + ' -> ' +variant + ' -> ' +type, _this.hexListJson[version][device][variant][type]);
        }else{
            $.toast({
                text: "Please select FIRMWARE version.",
                position: 'top-right',
                icon: 'error'
            });
            _this.Log.addText('Please select FIRMWARE version.');
            return;
        }
    });
    this.loadFileFromWebButton.attr('disabled', 'disabled');

    this.flashStatusContainer = $('#flashStatusFWContainter');
    this.flashFWDescription = $('#flashFWDescription');
    this.flashFWButton      = $('#flashFWButton').button().addClass('danger').click(function(){
        _this._flashFW(_this.port.val(), _this.hexFileForFlash);
    });

    this.progressWrite = $('#progressWrite').progressbar({
        max: 100,
    }).removeClass('ui-corner-all').addClass('progress progress_write');
    this.progressVerify = $('#progressVerify').progressbar({
        max: 100,
    }).removeClass('ui-corner-all').addClass('progress progress_verify');

    this.changeBaudRate = function(baud){
        console.log('change baudrate not impemented');
    };

    this.reset();

    this.handleSetFw = function(){

    };

    this.handleFlashDone = function(){
        $.toast({
            text: "Flash done",
            position: 'top-right',
            icon: 'success'
        });
        _this.Log.addText('Flash done');
        _this.flashStatusContainer.html('Done');
        _this.setStageLoadedFlashDone();
    };

    this.handleError = function(error){
        $.toast({
            text: error,
            position: 'top-right',
            icon: 'error'
        });
        _this.Log.addText('Error: ' + error);
        _this.setStageLoadedFlashDone();

        var FLAVOR_PICKED = analytics.EventBuilder.builder()
            .category('flash_fw')
            .action('flash_error')
            .label(error);

        tracker.send(FLAVOR_PICKED);
    };
    this.handleFlashProgress = this.setProgress;

    this.setStageBegin();

};

FlashFw.prototype.reset = function(){
    this.flashing = 0;
    this.hexListJson = {};
    this.fwFilesHex = {};
    this.hexFileForFlash = '';
    this.setStageBegin();

    this.fillDescription(false);

    this.listFWDevice.selectmenu('disable');
    this.listFWVariant.selectmenu('disable');
    this.listFWType.selectmenu('disable');

    this.listFWDevice.html('');
    this.listFWVariant.html('');
    this.listFWType.html('');

    this.listFWDevice.selectmenu("destroy").selectmenu(); //hack
    this.listFWVariant.selectmenu("destroy").selectmenu(); //hack
    this.listFWType.selectmenu("destroy").selectmenu(); //hack
};

FlashFw.prototype.setFwString = function(fw){
    this.hexFileForFlash = fw;
    this.handleSetFw();
    this.setStageLoadedFW();
};

FlashFw.prototype.buildHexUrls = function(data){
    for(var dataKey in data)
    {
        var version = data[dataKey];
        var versionSplitted = version.tag_name.split('.');


        if(!(versionSplitted[0] == "1" && versionSplitted[1] == "8")){
            continue;
        }

        var firmwares = {};

        for(var fwKey in version.assets)
        {
            var asset = version.assets[fwKey];
            var nameSplitted = asset.name.split('.');

            if(!firmwares[nameSplitted[0]]){
                firmwares[nameSplitted[0]] = {};
            }

            nameSplitted[1] = nameSplitted[1] && nameSplitted[1] != 'hex' ? nameSplitted[1] : 'default';
            if(!firmwares[nameSplitted[0]][nameSplitted[1]]){
                firmwares[nameSplitted[0]][nameSplitted[1]] = {};
            }

            nameSplitted[2] = nameSplitted[2] && nameSplitted[2] != 'hex' ? nameSplitted[2] : 'default';
            if(!firmwares[nameSplitted[0]][nameSplitted[1]][nameSplitted[2]]){
                firmwares[nameSplitted[0]][nameSplitted[1]][nameSplitted[2]] = '';
            }

            firmwares[nameSplitted[0]][nameSplitted[1]][nameSplitted[2]] = asset.browser_download_url;
        }

        this.hexListJson[version.tag_name]= firmwares;
        this.descriptionList[version.tag_name] = {header: version.name, body: version.body};
    }

    this.fillSelectVersion()
};

FlashFw.prototype.fillSelectVersion = function(){
    var _this = this;

    this.fillDescription(false);

    this.listFWVersion.html($('<option>').html("=== select ==="));

    var keysSorted = Object.keys(this.hexListJson).sort(function(a,b){return _this.hexListJson[a]-_this.hexListJson[b]});

    for(var key in keysSorted)
    {
        var isTest = this.descriptionList[keysSorted[key]].header.toLowerCase().indexOf('test') !== -1;
        if(isTest && !this.fwTestVersion.is(':checked')){
            continue;
        }

        this.listFWVersion.append($('<option>').html(keysSorted[key] + ' ' + (isTest ? '(TEST)' : this.fwTestVersion.is(':checked') ? '(RELEASE)' : '')).val(keysSorted[key]));
    }
    this.listFWVersion.selectmenu("destroy").selectmenu(); //hack
    this.listFWVersion.selectmenu({ change: function(){
        _this.fillSelectDevice($(this).val());
        _this.fillSelectVariant($(this).val(), null);
        _this.fillSelectType($(this).val(), null, null);
        _this.fillDescription($(this).val());
    }});

    this.fillSelectDevice(this.listFWVersion.val());
    this.fillSelectVariant(this.listFWVersion.val(), null);
    this.fillSelectType(this.listFWVersion.val(), null, null);
    this.fillDescription(this.listFWVersion.val());
};

FlashFw.prototype.fillSelectDevice = function(version){
    var _this = this;
    if(this.hexListJson && this.hexListJson[version]){

        this.listFWDevice.html($('<option>').html("=== select ==="));

        for(var name in this.hexListJson[version])
        {
            this.listFWDevice.append($('<option>').html(name));
        }

        this.listFWDevice.selectmenu('enable');
    }else{
        this.listFWDevice.selectmenu('disable');
        this.listFWDevice.html('');
    }

    this.listFWDevice.selectmenu("destroy").selectmenu(); //hack
    this.listFWDevice.selectmenu({ change: function(){
        _this.fillSelectVariant(_this.listFWVersion.val(), $(this).val());
        _this.fillSelectType($(this).val(), null, null);
    }});
};

FlashFw.prototype.fillDescription = function(version){
    if(this.descriptionList[version]){
        this.descriptionBox.html($('<h5>').html(this.descriptionList[version].header)).append($('<div>').html(this.descriptionList[version].body.replace(/\r\n/ig, '<br />')));

        this.descriptionBox.each(function(){
            var str = $(this).html();
            var regex = /((https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?)/ig
            var replaced_text = str.replace(regex, "<a href='$1' target='_blank'>$1</a>");
            $(this).html(replaced_text);
        });

    }else{
        this.descriptionBox.html('');
    }

};

FlashFw.prototype.fillSelectVariant = function(version, device){
    var _this = this;
    if(this.hexListJson && this.hexListJson[version] && this.hexListJson[version][device]){

        this.listFWVariant.html($('<option>').html("=== select ==="));
        for(var name in this.hexListJson[version][device])
        {
            this.listFWVariant.append($('<option>').html(name));
        }

        this.listFWVariant.selectmenu('enable');
    }else{
        this.listFWVariant.selectmenu('disable');
        this.listFWVariant.html('');
    }

    this.listFWVariant.selectmenu("destroy").selectmenu(); //hack

    this.listFWVariant.selectmenu({ change: function(){
        _this.fillSelectType(_this.listFWVersion.val(), _this.listFWDevice.val(),  $(this).val());
    }});
};

FlashFw.prototype.fillSelectType = function(version, device, variant){
    var _this = this;
    if(this.hexListJson && this.hexListJson[version] && this.hexListJson[version][device] && this.hexListJson[version][device][variant]){

        this.listFWType.html($('<option>').html("=== select ==="));
        for(var name in this.hexListJson[version][device][variant])
        {
            this.listFWType.append($('<option>').html(name));
        }

        this.listFWType.selectmenu('enable');
    }else{
        this.listFWType.selectmenu('disable');
        this.listFWType.html('');
    }

    this.listFWType.selectmenu("destroy").selectmenu(); //hack

    this.listFWType.selectmenu({ change: function(){
            var version = _this.listFWVersion.val();
            var device = _this.listFWDevice.val();
            var variant = _this.listFWVariant.val();
            var type = _this.listFWType.val();

            if(_this.hexListJson && _this.hexListJson[version] && _this.hexListJson[version][device] && _this.hexListJson[version][device][variant] && _this.hexListJson[version][device][variant][type]) {
                _this.loadFileFromWebButton.removeAttr('disabled', 'disabled');
            }else{
                _this.loadFileFromWebButton.attr('disabled', 'disabled');
            }
        }});

};

FlashFw.prototype.setHexRawData = function(name, hexRawData){
    this.fwFilesHex[name] = hexRawData;
    this.hexFileForFlash = hexRawData;

    for(var hexListKey in this.hexListJson){
        if(this.hexListJson[hexListKey].name == name){
            this.flashFWDescription.html(this.hexListJson[hexListKey].description);
            break;
        }
    }

    this.setFwString(hexRawData);
};

FlashFw.prototype.loadHexList = function(){
    var _this = this;
    if(!jQuery.isEmptyObject(this.hexListJson)){
        return;
    }

    $.ajax( {
        url: _this.hexListUrl,
        dataType: "json"
    })
    .done(function(data) {
        _this.buildHexUrls(data);
    })
    .fail(function() {
        console.log('load hex list fail')
    });
};

FlashFw.prototype.loadHexFromWeb = function(name, fwUrl){
    var _this = this;
    if(this.fwFilesHex[name]){
        _this.setHexRawData(name, this.fwFilesHex[name]);
    }

    this.flashStatusContainer.html('Downloading FW file');
    $.ajax( {
        url: fwUrl,
        dataType: "text"
    })
    .done(function(data) {
        _this.flashStatusContainer.html('');
        var parsedHex = stk500.parseHex(data);
        if(!parsedHex){
            _this.handleError('Firmware is broken');
            return;
        }

        if(parsedHex.length > _this.maxHexSize){
            _this.handleError('Firmware is too big, max ' + _this.maxHexSize + 'bytes but ' + parsedHex.length + 'bytes given');
            return;
        }

        $.toast({
            text: name + ' was loaded',
            position: 'top-right',
            icon: 'success'
        });
        _this.Log.addText(name + ' was loaded');

        _this.FLAVOR_PICKED =_this.FLAVOR_PICKED.label(name);
        _this.setHexRawData(name, data);
    })
    .fail(function(error) {
        console.log(error);
        $.toast({
            text: 'Load HEX failed: ' + error.responseText,
            position: 'top-right',
            icon: 'error'
        });
    });
};


FlashFw.prototype.openFile = function(){
    var _this = this;
    chrome.fileSystem.chooseEntry(
        {
            type: 'openFile', accepts: [{
            extensions: ['hex']
        }]
        },
        function (fileEntry) {
            if (chrome.runtime.lastError || !fileEntry) {
                console.log("User did not choose a file");
                return;
            }

            fileEntry.file(function (file) {
                var reader = new FileReader();
                reader.onload = function (e) {

                    var parsedHex = stk500.parseHex(e.target.result);
                    if(!parsedHex){
                        _this.handleError('Firmware is broken');
                        return;
                    }

                    if(parsedHex.length > _this.maxHexSize){
                        _this.handleError('Firmware is too big, max ' + _this.maxHexSize + ' but ' + parsedHex.length + ' given');
                        return;
                    }

                    $.toast({
                        text: 'HEX was loaded',
                        position: 'top-right',
                        icon: 'success'
                    });

                    _this.FLAVOR_PICKED = _this.FLAVOR_PICKED.label('from_disk -> ' + file.path);
                    _this.Log.addText('HEX was loaded');
                    _this.setStageBegin();
                    _this.setFwString(e.target.result);
                    _this.fillDescription(false);
                };

                reader.readAsBinaryString(file);
            });
        }
    );
};


FlashFw.prototype._flashFW = function(port, fw){
    var _this = this;

    tracker.send(this.FLAVOR_PICKED);

    if(this.listFWVariant.val() == 'px4' || this.listFWVariant.val() == 'ardupilot')
    {
        this.changeBaudRate(57600);
    }

    this.setStageFlashing();
    var flashOnce = function(){
        var dfd = jQuery.Deferred();
        stk500.upload(port, fw, function(){
            dfd.resolve();
        },
        function(progressPercent){
            dfd.notify(progressPercent);
        },
        function(error){
            dfd.reject( error );
        },
        function(error){
            _this.handleError(error);
        }
        );

        return dfd.promise();
    };

    $.when(flashOnce()).then(
        function() { //done
            _this.handleFlashDone();
        },
        function( error ) { //fail
            $.when(flashOnce()).then(
                function() { //done
                    _this.handleFlashDone();
                },
                function( error ) { //fail
                    _this.handleError(error);
                },
                function( progressPercent ) { // progress
                    _this.handleFlashProgress(progressPercent);
                }
            );
        },
        function( progressPercent ) { // progress
            _this.handleFlashProgress(progressPercent);
        }
    );
};

FlashFw.prototype.setProgress = function(progressPercent){
        if(progressPercent < 100){
            this.progressWrite.progressbar({
                value: progressPercent
            });

            this.progressVerify.progressbar({
                value: 0
            });
        }else{

            this.progressWrite.progressbar({
                value: 100
            });

            this.progressVerify.progressbar({
                value: progressPercent - 100
            });
        }

    if(this.flashing == 1){
        if(progressPercent > 0){
            this.flashStatusContainer.html(progressPercent <= 100 ? 'Writing - DO NOT POWER OFF' : 'Verifing');
            if(progressPercent <= 100 && progressPercent % 10 == 0){
                this.Log.addText('Writing: ' + progressPercent + '%');
            }else if(progressPercent > 100 && progressPercent % 10 == 0){
                this.Log.addText('Verifing: ' + (progressPercent - 100) + '%');
            }

        }else{
            this.flashStatusContainer.html('Waiting for bootloader reset');
            this.Log.addText('Waiting for bootloader reset');
        }

    }

};

FlashFw.prototype.setStageBegin = function(){
    this.flashStatusContainer.html('');
    this.flashFWDescription.html('');
    this.flashFWButton.button( "disable" );
    this.flashStatusContainer.html('');
    this.flashing = 0;
    this.progressWrite.progressbar({
        value: 0
    });
    this.progressVerify.progressbar({
        value: 0
    });
};

FlashFw.prototype.setStageLoadedFW = function(){
    this.flashStatusContainer.html('');
    this.flashFWButton.button( "enable" );
    this.loadFileFromDiskButton.button( "enable" );
    this.loadFileFromWebButton.button( "enable" );
    this.flashStatusContainer.html('');
    this.flashing = 0;
    this.progressWrite.progressbar({
        value: 0
    });
    this.progressVerify.progressbar({
        value: 0
    });
};

FlashFw.prototype.setStageFlashing = function(){
    this.flashStatusContainer.html('');
    this.flashFWButton.button( "disable" );
    this.loadFileFromDiskButton.button( "disable" );
    this.loadFileFromWebButton.button( "disable" );

    this.flashing = 1;
    this.setProgress(0);
};

FlashFw.prototype.setStageLoadedFlashDone = function(){
    this.flashStatusContainer.html('');
    this.flashFWButton.button( "enable" );
    this.loadFileFromDiskButton.button( "enable" );
    this.loadFileFromWebButton.button( "enable" );

    this.flashing = 0;
};




