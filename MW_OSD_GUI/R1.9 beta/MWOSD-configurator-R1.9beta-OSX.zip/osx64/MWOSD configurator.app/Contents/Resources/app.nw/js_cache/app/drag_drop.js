var DragAndDrop = function(target, destination, preview){

    this.target         = target;
    this.destination    = destination;
    this.preview        = preview;

    this.init();
};

DragAndDrop.prototype.init = function(){

    var canvas = mainApp.livePreview.createImageFromElement('Voltage- main');
    var dragIcon = document.createElement('img');
    dragIcon.src = canvas[0].toDataURL("image/png");
    var _this = this;


    var allowDrop = function (ev) {
        ev.preventDefault();
    };

    var drop = function (ev) {
        ev.preventDefault();
        var data = ev.dataTransfer.getData("text");
       // console.log(data);
    };

    this.target.on('dragstart', function(ev) {
        ev.originalEvent.dataTransfer.setDragImage(dragIcon, -10, -10);
        $('#main_screen').attr('style', 'opacity: 0.4');
    });

    this.target.on('dragend', function(ev) {
        $('#main_screen').attr('style', 'opacity: 1');
    });

    this.destination.on('dragover', function(ev) {
        ev.originalEvent.preventDefault();
    });

    this.destination.find('td').on('drop', function(ev) {
        ev.originalEvent.preventDefault();

        var taget = $(ev.originalEvent.target);
        mainApp.livePreview.setDisplayElement('Voltage- main', true);
        mainApp.livePreview.moveElementToPosition('Voltage- main', taget.attr('x') * 1, taget.attr('y') * 1);
    });
};
