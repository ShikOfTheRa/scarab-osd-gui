AreYouSure = function (handleOk, handleCancel) {
	this.handleOk = handleOk;
	this.handleCancel = handleCancel;


};

AreYouSure.prototype.show = function(header, body) {
	var _this = this;
	$('#are_you_sure-text').text(body);

	$('#are_you_sure').dialog(
		{
			title: header,
			modal: true,
			resize: false,
			buttons: [
				{
					text: "OK",
					click: function () {
						_this.handleOk();
						$(this).dialog("close");
					}
				},
				{
					text: "CANCEL",
					click: function () {
						_this.handleCancel();
						$(this).dialog("close");
					}
				}
			]
		}
	);

};




