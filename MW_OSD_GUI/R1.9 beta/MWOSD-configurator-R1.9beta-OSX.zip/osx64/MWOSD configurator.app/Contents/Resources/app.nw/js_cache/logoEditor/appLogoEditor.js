var AppLogoEditor = function (targetNode, withAddress) {

    var _this = this;

    this.imageLoader = new ImageLoader({
        widthMax: 36,
        heightMax: 36,
        widthMin: 36,
        heightMin: 36,
    });
    this.imageLoader.handleOutOfSize = function(imageSize){
        $.toast({
            text: 'Wrong image size, expected 36x36 got ' + imageSize[0] + 'x' + imageSize[1],
            position: 'top-right',
            icon: 'error'
        });
    };


    this.stripsEditors = [[], [], []];


    $("#select_color_logo").buttonset();
    $("#select_color_logo").find('input').change(function () {
        for(var i = 0; i < 6; i++){
            _this.stripsEditors[i].fillType = $(this).attr('id').replace('Logo', '');
        }
    });

    $("#clearAllLogo")
        .button()
        .click(function (event) {
            event.preventDefault();
            for(var i = 0; i < 6; i++){
                _this.stripsEditors[i].deepClearScreen();
            }
        });

    for(var i = 0; i < 6; i++){
        this.stripsEditors[i] = new ScreenStripsEditor($('#editorTableLogo_' + i), false);
        $('#editorTableLogo_' + i ).addClass('editorTable').addClass('editorTable').addClass('noMargin');
    }

    this.imageLoader.onChangefontDataOnPosition = function (fontData, position) {
        _this.stripsEditors[position > 2 ? position - 13 : position].setNewImageData(fontData);
    }

};

/**
 *
 */
AppLogoEditor.prototype.run = function () {
    for(var i = 0; i < 6; i++){
        this.stripsEditors[i].render();
        this.stripsEditors[i].disabled = true;
    }
};

/**
 *
 * @param fontMap
 */
AppLogoEditor.prototype.setNewFontMap = function(fontMap){
    for(var i = 0; i < 6; i++){
        this.stripsEditors[i].setNewImageData(fontMap[i]);
        this.stripsEditors[i].disabled = false;
    }
};

/**
 *
 * @param fontMap
 */
AppLogoEditor.prototype.getFontsMap = function(){
    var result = [];

    for(var i = 0; i < 6; i++){
        result[i] = this.stripsEditors[i].fontData;
    }

    return result;
};

/**
 *
 * @param urlTarget
 */
AppLogoEditor.prototype.loadImageByurl = function (urlTarget) {
    this.imageLoader.loadImageByUrl(urlTarget);
};
