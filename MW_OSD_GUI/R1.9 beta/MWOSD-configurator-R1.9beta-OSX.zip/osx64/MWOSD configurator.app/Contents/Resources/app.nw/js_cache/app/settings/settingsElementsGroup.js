/**
 *
 * @type {{select: string, checkbox: string, range: string}}
 */
SettingsElementsType = {
    select: 'SelectElement',
    checkbox: 'CheckBoxElement',
    range: 'RangeElement',
};

/**
 *
 * @type {{main: string}}
 */
SettingsElementsGroup = {
    G_Voltage: {
        id: 'main_voltage',
        description: 'Main Voltage'
    },
    G_VVoltage: {
        id: 'video_voltage',
        description: 'Video Voltage'
    },
    G_Amperage: {
        id: 'amperage',
        description: 'Amperage'
    },
    G_RSSI: {
        id: 'rssi',
        description: 'RSSI'
    },
    G_VREF: {
        id: 'reference_voltage',
        description: 'Reference Voltage'
    },
    G_Display: {
        id: 'display',
        description: 'Display',
    },
    G_Other: {
        id: 'other',
        description: 'Other'
    },
    G_COMPASS: {
        id: 'compass',
        description: 'Compass'
    },
    G_Alarms: {
        id: 'alarms',
        description: 'Alarms'
    },
    G_CallSign: {
        id: 'callsign',
        classGroup: 'WidgetCallSign'
    },
    G_RCSWITCH: {
        id: 'rcswitch',
        classGroup: 'WidgetLayout'
    },
    G_MAVLINK: {
        id: 'mavlink',
        description: 'Mavlink',
    },
    G_GOSD: {
        id: 'gosd',
        description: 'G-OSD',
    },
    G_Custom: {
        id: 'custom',
        description: 'Custom',
    },
    G_VTX: {
        id: 'vtx',
        description: 'VTX',
    },
    G_GPS: {
        id: 'gps',
        description: 'GPS',
    },
    G_HUD: {
        id: 'hud',
        description: 'HUD'
    },
    G_DISPLAY: {
        id: 'display',
        description: 'Display'
    }
};

