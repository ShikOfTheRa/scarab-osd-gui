
var DefaultV15 = '[{"index":0,"values":{"command":9,"values":{"0":15,"1":1,"2":0,"3":0,"4":34,"5":2,"6":8,"7":1,"8":0,"9":4},"specialValues":{}}},{"index":10,"values":{"command":9,"values":{"10":200,"11":1,"12":3,"13":1,"14":0,"15":1,"16":1,"17":1,"18":200,"19":0},"specialValues":{}}},{"index":20,"values":{"command":9,"values":{"20":50,"21":100,"22":2,"23":0,"24":2,"25":0,"26":2,"27":1,"28":0,"29":1},"specialValues":{}}},{"index":30,"values":{"command":9,"values":{"30":0,"31":7,"32":0,"33":0,"34":0,"35":0,"36":0,"37":0,"38":1,"39":8},"specialValues":{}}},{"index":40,"values":{"command":9,"values":{"40":0,"41":0,"42":0,"43":30,"44":30,"45":20,"46":77,"47":87,"48":79,"49":83},"specialValues":{}}},{"index":50,"values":{"command":9,"values":{"50":68,"51":0,"52":32,"53":32,"54":32,"55":32,"56":0,"57":0,"58":0,"59":0},"specialValues":{}}},{"index":60,"values":{"command":9,"values":{"60":150,"61":0,"62":0,"63":0,"64":255,"65":3,"66":0,"67":2,"68":244,"69":1},"specialValues":{}}},{"index":70,"values":{"command":9,"values":{"70":32,"71":192,"72":50,"73":192,"74":52,"75":192,"76":182,"77":192,"78":143,"79":0},"specialValues":{}}},{"index":80,"values":{"command":9,"values":{"80":173,"81":0,"82":36,"83":0,"84":113,"85":0,"86":40,"87":192,"88":203,"89":192},"specialValues":{}}},{"index":90,"values":{"command":9,"values":{"90":202,"91":192,"92":96,"93":193,"94":126,"95":1,"96":126,"97":193,"98":55,"99":193},"specialValues":{}}},{"index":100,"values":{"command":9,"values":{"100":36,"101":1,"102":66,"103":1,"104":2,"105":192,"106":15,"107":192,"108":76,"109":193},"specialValues":{}}},{"index":110,"values":{"command":9,"values":{"110":248,"111":0,"112":106,"113":193,"114":46,"115":1,"116":113,"117":193,"118":120,"119":193},"specialValues":{}}},{"index":120,"values":{"command":9,"values":{"120":194,"121":192,"122":187,"123":192,"124":187,"125":0,"126":3,"127":0,"128":7,"129":0},"specialValues":{}}},{"index":130,"values":{"command":9,"values":{"130":92,"131":0,"132":85,"133":1,"134":6,"135":1,"136":62,"137":192,"138":52,"139":0},"specialValues":{}}},{"index":140,"values":{"command":9,"values":{"140":195,"141":0,"142":100,"143":192,"144":16,"145":1,"146":186,"147":192,"148":86,"149":1},"specialValues":{}}},{"index":150,"values":{"command":9,"values":{"150":220,"151":0,"152":233,"153":0,"154":242,"155":0,"156":212,"157":0,"158":152,"159":0},"specialValues":{}}},{"index":160,"values":{"command":9,"values":{"160":128,"161":0,"162":218,"163":0,"164":82,"165":0,"166":158,"167":0,"168":122,"169":0},"specialValues":{}}},{"index":170,"values":{"command":9,"values":{"170":32,"171":192,"172":50,"173":192,"174":52,"175":192,"176":182,"177":192,"178":143,"179":0},"specialValues":{}}},{"index":180,"values":{"command":9,"values":{"180":173,"181":0,"182":36,"183":0,"184":113,"185":0,"186":40,"187":192,"188":203,"189":192},"specialValues":{}}},{"index":190,"values":{"command":9,"values":{"190":202,"191":192,"192":96,"193":193,"194":126,"195":1,"196":126,"197":193,"198":55,"199":193},"specialValues":{}}},{"index":200,"values":{"command":9,"values":{"200":36,"201":1,"202":66,"203":1,"204":2,"205":192,"206":15,"207":192,"208":76,"209":193},"specialValues":{}}},{"index":210,"values":{"command":9,"values":{"210":248,"211":0,"212":106,"213":193,"214":46,"215":1,"216":113,"217":193,"218":120,"219":193},"specialValues":{}}},{"index":220,"values":{"command":9,"values":{"220":194,"221":192,"222":187,"223":192,"224":187,"225":0,"226":3,"227":0,"228":7,"229":0},"specialValues":{}}},{"index":230,"values":{"command":9,"values":{"230":92,"231":0,"232":85,"233":1,"234":6,"235":1,"236":62,"237":192,"238":52,"239":0},"specialValues":{}}},{"index":240,"values":{"command":9,"values":{"240":195,"241":0,"242":100,"243":192,"244":16,"245":1,"246":186,"247":192,"248":86,"249":1},"specialValues":{}}},{"index":250,"values":{"command":9,"values":{"250":220,"251":0,"252":233,"253":0,"254":242,"255":0,"256":212,"257":0,"258":152,"259":0},"specialValues":{}}},{"index":260,"values":{"command":9,"values":{"260":128,"261":0,"262":218,"263":0,"264":82,"265":0,"266":158,"267":0,"268":122,"269":0},"specialValues":{}}},{"index":270,"values":{"command":9,"values":{"270":32,"271":192,"272":50,"273":192,"274":52,"275":192,"276":182,"277":192,"278":143,"279":0},"specialValues":{}}},{"index":280,"values":{"command":9,"values":{"280":173,"281":0,"282":36,"283":0,"284":113,"285":0,"286":40,"287":192,"288":203,"289":192},"specialValues":{}}},{"index":290,"values":{"command":9,"values":{"290":202,"291":192,"292":96,"293":193,"294":126,"295":1,"296":126,"297":193,"298":55,"299":193},"specialValues":{}}},{"index":300,"values":{"command":9,"values":{"300":36,"301":1,"302":66,"303":1,"304":2,"305":192,"306":15,"307":192,"308":76,"309":193},"specialValues":{}}},{"index":310,"values":{"command":9,"values":{"310":248,"311":0,"312":106,"313":193,"314":46,"315":1,"316":113,"317":193,"318":120,"319":193},"specialValues":{}}},{"index":320,"values":{"command":9,"values":{"320":194,"321":192,"322":187,"323":192,"324":187,"325":0,"326":3,"327":0,"328":7,"329":0},"specialValues":{}}},{"index":330,"values":{"command":9,"values":{"330":92,"331":0,"332":85,"333":1,"334":6,"335":1,"336":62,"337":192,"338":52,"339":0},"specialValues":{}}},{"index":340,"values":{"command":9,"values":{"340":195,"341":0,"342":100,"343":192,"344":16,"345":1,"346":186,"347":192,"348":86,"349":1},"specialValues":{}}},{"index":350,"values":{"command":9,"values":{"350":220,"351":0,"352":233,"353":0,"354":242,"355":0,"356":212,"357":0,"358":152,"359":0},"specialValues":{}}},{"index":360,"values":{"command":9,"values":{"360":128,"361":0,"362":218,"363":0,"364":82,"365":0,"366":158,"367":0,"368":122,"369":0},"specialValues":{}}},{"index":370,"values":{"command":9,"values":{"370":0,"371":0,"372":150,"373":0,"374":0,"375":0,"376":255,"377":3,"378":0,"379":2},"specialValues":{}}},{"index":380,"values":{"command":9,"values":{"380":244,"381":1,"382":15,"383":1,"384":0,"385":0,"386":34,"387":2,"388":8,"389":1},"specialValues":{}}},{"index":390,"values":{"command":9,"values":{"390":0,"391":4,"392":200,"393":1,"394":3,"395":1,"396":0,"397":1,"398":1,"399":1},"specialValues":{}}},{"index":400,"values":{"command":9,"values":{"400":200,"401":0,"402":50,"403":100,"404":2,"405":0,"406":2,"407":0,"408":2,"409":1},"specialValues":{}}}]';
var layoutAddressV15 = [
    [70, 169], [170, 269], [270, 369]
];
var layoutLength = 100;

/**
 *
 * @type {*[]}
 */
SettingsElementsV15 = [
    {
        id: 'S_AUTOCELL',
        position: 1,
        description: 'Auto Detect',
        type: SettingsElementsType.select,
        group: [SettingsElementsGroup.G_Voltage],
        properties: {
            order: 2,
            values: [
                'Use battery cell count / alarm',
                'Autodetect cell count and cell alarm'
            ]
        }
    },
    {
        id: 'S_VIDVOLTAGEMIN',
        position: 2,
        description: 'Video Voltage Alarm',
        type: SettingsElementsType.range,
        group: [SettingsElementsGroup.G_VVoltage],
        properties: {
            max: 255,
            divider: 10
        }
    },
    {
        id: 'S_RSSI_ALARM',
        position: 3,
        description: 'RSSI Alarm',
        type: SettingsElementsType.range,
        properties: {
            max: 100,
//			divider: 10,
        },
        group: [SettingsElementsGroup.G_RSSI]
    },
    {
        id: 'S_AUTOCELL_ALARM',
        position: 4,
        description: 'Autodetect cell alarm value',
        type: SettingsElementsType.range,
        properties: {
            max: 255,
            divider: 10,
            order: 3,
        },
        group: [SettingsElementsGroup.G_Voltage]
    },
    {
        id: 'S_MWRSSI',
        position: 5,
        description: 'RSSI source',
        type: SettingsElementsType.select,
        properties: {
            order: 1,
            values: [
                'Direct OSD connect Analog',
                'Direct OSD connect - 50hz PWM',
                'RSSI from Flight Controller',
                'RSSI from RC channel'
            ]
        },
        group: [SettingsElementsGroup.G_RSSI]
    },
    {
        id: 'S_RSSI_CH',
        position: 6,
        description: 'RSSI channel',
        type: SettingsElementsType.select,
        properties: {
            values: {
                1: "1",
                2: "2",
                3: "3",
                4: "4",
                5: "5",
                6: "6",
                7: "7",
                8: "8",
                9: "9",
                10: "10",
                11: "11",
                12: "12",
                13: "13",
                15: "15",
                16: "16"
            }
        },
        group: [SettingsElementsGroup.G_RSSI]
    },
    {
        id: 'S_TX_TYPE',
        position: 7,
        description: 'Transmiter type',
        type: SettingsElementsType.select,
        properties: {
            order: 7,
            values: [
                'Roll/Pitch/Yaw/Throttle',
                'Roll/Pitch/Throttle/Yaw',
                'Throttle/Roll/Pitch/Yaw'
            ]},
        group: [SettingsElementsGroup.G_Other]
    },
    {
        id: 'S_VOLTAGEMIN',
        position: 8,
        description: 'Voltage Alarm',
        type: SettingsElementsType.range,
        properties: {
            max: 255,
            divider: 10
        },
        group: [SettingsElementsGroup.G_Voltage]
    },
    {
        id: 'S_BATCELLS',
        position: 9,
        description: 'Battery Cell Count',
        type: SettingsElementsType.select,
        properties: {
            values: {
                1: "1S (3.7V)",
                2: "2S (7.4V)",
                3: "3S (11.1V)",
                4: "4S (14.8V)",
                5: "5S (18.5V)",
                6: "6S (22.2V)",                
            }
        },
        group: [SettingsElementsGroup.G_Voltage]
    },
    {
        id: 'S_DIVIDERRATIO',
        position: 10,
        description: 'Main Voltage Adjust',
        type: SettingsElementsType.range,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_Voltage]
    },
    {
        id: 'S_MAINVOLTAGE_VBAT',
        position: 11,
        description: 'Main Voltage source',
        type: SettingsElementsType.select,
        properties: {
            order: 1,
            values: [
                'Use direct connect voltage',
                'Use Flight Controller voltage'
            ]
        },
        group: [SettingsElementsGroup.G_Voltage]
    },
    {
        id: 'S_SIDEBARHEIGHT',
        position: 12,
        description: 'HUD sidebar height',
        type: SettingsElementsType.select,
        properties: {
            values: {
                3: "3",
                4: "4",
                5: "5",
                6: "6"
            }
        },
        group: [SettingsElementsGroup.G_HUD]
    },
    {
        id: 'S_MWAMPERAGE',
        position: 13,
        description: 'Amperage',
        type: SettingsElementsType.select,
        properties: {
            values: [
                'Use direct connect current sensor',
                'Use Flight Controller amperage',
                'Use Virtual Sensor (throttle)'
            ]
        },
        group: [SettingsElementsGroup.G_Amperage]
    },
    {
        id: 'S_TX_REVERSE',
        position: 14,
        description: 'Transmiter reverse',
        type: SettingsElementsType.select,
        properties: {
             order: 8,
           values: [
                'No reversing',
                'Ch1',
                'Ch2',
                'Ch1, Ch2',
                'Ch3',
                'Ch1, Ch3',
                'Ch2, Ch3',
                'Ch1, Ch2, Ch3',
                'Ch4',
                'Ch1, Ch4',
                'Ch2, Ch4',
                'Ch1, Ch2, Ch4',
                'Ch3, Ch4',
                'Ch1, Ch3, Ch4',
                'Ch2, Ch3, Ch4',
                'Ch1, Ch2, Ch3, Ch4'
            ]
        },
        group: [SettingsElementsGroup.G_Other]
    },
    {
        id: 'S_MAV_SYS_ID',
        position: 15,
        description: 'Mavlink System ID',
        type: SettingsElementsType.range,
        properties: {
            order: 16,
            min: 0,
            max: 254
        },
        group: [SettingsElementsGroup.G_Other]
    },
    {
        id: 'S_ALARMS_TEXT',
        position: 16,
        description: 'Text alarms',
        type: SettingsElementsType.select,
        properties: {
            order: 4,
            values: [
                'Hide text alarms',
                'Show text alarms'
            ]
        },
        group: [SettingsElementsGroup.G_Other]
    },
    {
        id: 'S_CALLSIGN_ALWAYS',
        position: 17,
        description: 'Display callsign',
        type: SettingsElementsType.select,
        properties: {
            values: [
                'Disabled',
                'Show Permanently',
                'Display for 4 seconds every minute'
            ]
        },
        group: [SettingsElementsGroup.G_CallSign]
    },
    {
        id: 'S_VIDDIVIDERRATIO',
        position: 18,
        description: 'Video Voltage Adjust',
        type: SettingsElementsType.range,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_VVoltage]
    },
    {
        id: 'S_THROTTLE_PWM',
        position: 19,
        description: 'Throttle display',
        type: SettingsElementsType.select,
        properties: {
            order: 6,
            max: 255,
            values: [
                'Display % value',
                'Display PWM value'
            ]
        },
        group: [SettingsElementsGroup.G_Other]
    },
    {
        id: 'S_AMPER_HOUR_ALARM',
        position: 20,
        description: 'mAh Alarm',
        type: SettingsElementsType.range,
        properties: {
            max: 255,
            divider: 0.01,
            step: 100
        },
        group: [SettingsElementsGroup.G_Amperage]
    },
    {
        id: 'S_AMPERAGE_ALARM',
        position: 21,
        description: 'Amp Alarm',
        type: SettingsElementsType.range,
        properties: {
            max: 255
        },
        group: [SettingsElementsGroup.G_Amperage]
    },
    {
        id: 'S_VARIO_SCALE',
        position: 22,
        description: 'VARIO indicator size',
        type: SettingsElementsType.select,
        properties: {
            order: 10,
            values: {
                1: "Single character",
                2: "Three rows high",
                3: "Five rows high",
                4: "Seven rows high",
                5: "Nine rows high"
            }
        },
        group: [SettingsElementsGroup.G_Other]
    },
    {
        id: 'S_GPS_MASK',
        position: 23,
        description: 'GPS display type',
        type: SettingsElementsType.select,
        group: [SettingsElementsGroup.G_GPS],
        properties: {
            values: [
                'Display real co-ordinates',
                'Display with false major digits'
            ]
        },
    },
    {
        id: 'S_USEGPSHEADING',
        position: 24,
        description: 'FixedWing alt/heading (MSP FC only)',
        type: SettingsElementsType.select,
        properties: {
            values: [
                'Use BARO altitude, MAG heading',
                'Use BARO altitude, GPS heading',
                'Use GPS altitude, GPS heading'
            ]
        },
        group: [SettingsElementsGroup.G_GPS]
    },
    {
        id: 'S_UNITSYSTEM',
        position: 25,
        description: 'Units Of Measure',
        type: SettingsElementsType.select,
        properties: {
            order: 3,
            values: [
                'Metric',
                'Imperial',
            ]
        },
        group: [SettingsElementsGroup.G_Other]
    },
    {
        id: 'S_VIDEOSIGNALTYPE',
        position: 26,
        description: 'Video Signal Type',
        type: SettingsElementsType.select,
        properties: {
            order: 2,
            values: [
                'NTSC',
                'PAL',
                'AUTO'
            ]
        },
        group: [SettingsElementsGroup.G_Other]
    },
    {
        id: 'S_SHOWBATLEVELEVOLUTION',
        position: 27,
        description: 'Main Battery Icon',
        type: SettingsElementsType.select,
        properties: {
            order: 13,
            values: [
                'Static battery icon',
                'Remaining capacity icon'
            ]
        },
        group: [SettingsElementsGroup.G_Other]
    },
    {
        id: 'S_RESETSTATISTICS',
        position: 28,
        description: 'Statistics',
        type: SettingsElementsType.select,
        properties: {
            order: 5,
            values: [
                'Show total flight',
                'Show since last armed'
            ]
        },
        group: [SettingsElementsGroup.G_Other]
    },
    {
        id: ' S_MAPMODE',
        position: 29,
        description: 'Map mode display type',
        type: SettingsElementsType.select,
        properties: {
            order: 14,
            values: [
                'Disabled',
                'Show home position',
                'Show aircraft position',
                'Show both positions',
                'Show aircraft position and direction'
            ]
        },
        group: [SettingsElementsGroup.G_Other]
    },
    {
        id: 'S_VREFERENCE',
        position: 30,
        description: 'Analog sensor reference',
        type: SettingsElementsType.select,
        properties: {
            order: 1,
            values: [
                '1.1v - 4s max',
                '5.0v - 6s or analog sensors'
            ]
        },
        group: [SettingsElementsGroup.G_Other]
    },
    {
        id: 'S_SIDEBARWIDTH,',
        position: 31,
        description: 'HUD sidebar width',
        type: SettingsElementsType.select,
        properties: {
            values: {
                3: "3",
                4: "4",
                5: "5",
                6: "6",
                7: "7",
                8: "8",
                9: "9",
                10: "10",
                11: "11",
                12: "12",
                13: "13",
                14: "14"
            }
        },
        group: [SettingsElementsGroup.G_HUD]
    },
   /* {
        id: 'S_GPSTIME',
        position: 32,
        description: 'GPS time',
        type: SettingsElementsType.checkbox,
        properties: {},
        group: [SettingsElementsGroup.G_GPS]
    },
    {
        id: 'S_GPSTZAHEAD',
        position: 33,
        description: 'GPS head',
        type: SettingsElementsType.checkbox,
        properties: {},
        group: [SettingsElementsGroup.G_GPS]
    },
    {
        id: 'S_GPSTZ',
        position: 34,
        description: 'GPS STZ',
        type: SettingsElementsType.checkbox,
        properties: {},
        group: [SettingsElementsGroup.G_GPS]
    },*/
    {
        id: 'S_VTX_POWER',
        position: 35,
        description: 'VTX Power',
        type: SettingsElementsType.select,
        properties: {
            values: [
                '50mW',
                '200mW',
                '600mW',
                '800mW'
            ]
        },
        group: [SettingsElementsGroup.G_VTX]
    },
    {
        id: 'S_VTX_BAND',
        position: 36,
        description: 'VTX Band',
        type: SettingsElementsType.select,
        properties: {
            values: [
                'A',
                'B',
                'E',
                'F',
                'C (Raceband)'
            ]
        },
        group: [SettingsElementsGroup.G_VTX]
    },
    {
        id: 'S_VTX_CHANNEL',
        position: 37,
        description: 'VTX Channel',
        type: SettingsElementsType.select,
        properties: {
            values: [
                'CH 1',
                'CH 2',
                'CH 3',
                'CH 4',
                'CH 5',
                'CH 6',
                'CH 7',
                'CH 8',
            ]},
        group: [SettingsElementsGroup.G_VTX]
    },
    {
        id: 'S_RCWSWITCH',
        position: 38,
        description: ['OSD Screen Switch'],
        type: SettingsElementsType.select,
        properties: {
            order: 1,
            values: [
                'Use Flight Controller OSD switch',
                'Use RC channel'
            ]
        },
        group: [SettingsElementsGroup.G_RCSWITCH]
    },
    {
        id: 'S_RCWSWITCH_CH',
        position: 39,
        description: 'Screen switch RC Channel',
        type: SettingsElementsType.select,
        properties: {
            values: {
                1: "1",
                2: "2",
                3: "3",
                4: "4",
                5: "5",
                6: "6",
                7: "7",
                8: "8",
                9: "9",
                10: "10",
                11: "11",
                12: "12",
                13: "13",
                15: "15",
                16: "16"
            }
        },
        group: [SettingsElementsGroup.G_RCSWITCH]
    },
    {
        id: 'S_DISTANCE_ALARM',
        position: 40,
        description: 'Distance Alarm',
        type: SettingsElementsType.range,
        properties: {
            max: 255,
            divider: 0.01,
            step: 100
        },
        group: [SettingsElementsGroup.G_Alarms]
    },
    {
        id: 'S_ALTITUDE_ALARM',
        position: 41,
        description: 'Altitude Alarm',
        type: SettingsElementsType.range,
        properties: {
            max: 255,
            divider: 0.01,
            step: 100
        },
        group: [SettingsElementsGroup.G_Alarms]
    },
    {
        id: 'S_SPEED_ALARM',
        position: 42,
        description: 'Speed Alarm',
        type: SettingsElementsType.range,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_Alarms]
    },
    {
        id: 'S_FLYTIME_ALARM',
        position: 43,
        description: 'Timer Alarm',
        type: SettingsElementsType.range,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_Alarms]
    },
    {
        id: 'S_AUDVARIO_DEADBAND',
        position: 44,
        description: 'Audio Vario deadband',
        type: SettingsElementsType.range,
        properties: {order: 11, max: 254},
        group: [SettingsElementsGroup.G_Other]
    }, {
        id: 'S_AUDVARIO_TH_CUT',
        position: 45,
        description: 'Audio Vario throttle switch',
        type: SettingsElementsType.range,
        properties: {
            order: 12,
            min: 10,
            max: 20,
            step: 100,
            divider: 0.01
        },
        group: [SettingsElementsGroup.G_Other]
    },
    {
        id: 'S_CS0',
        position: 46,
        description: 'S_CS0',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS1',
        position: 47,
        description: 'S_CS1',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS2',
        position: 48,
        description: 'S_CS2',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS3',
        position: 49,
        description: 'S_CS3',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS4',
        position: 50,
        description: 'S_CS4',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS5',
        position: 51,
        description: 'S_CS5',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS6',
        position: 52,
        description: 'S_CS6',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS7',
        position: 53,
        description: 'S_CS7',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS8',
        position: 54,
        description: 'S_CS8',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS9',
        position: 55,
        description: 'S_CS9',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    },{
        id: 'S_PWM_PPM',
        position: 56,
        description: 'AEROMAX OSD - RC source type',
        type: SettingsElementsType.select,
        properties: {
            order: 9,
            values: [
                'PWM',
                'PPM'
            ]
        },
        group: [SettingsElementsGroup.G_Other]
    },{
        id: 'S_ELEVATIONS',
        position: 57,
        description: 'AHI minor elevations',
        type: SettingsElementsType.select,
        properties: {
            values: [
                'Disabled',
                'Enabled'
            ]
        },
        group: [SettingsElementsGroup.G_HUD]
    },{
        id: 'S16_AMPZERO',
        position: 58,
        secondByte: 59,
        description: 'Amps Zero Adjust',
        type: SettingsElementsType.range,
        properties: {max: 1023},
        group: [SettingsElementsGroup.G_Amperage]
    },
    {
        id: ' S16_AMPDIVIDERRATIO',
        position: 60,
        secondByte: 61,
        description: 'Amps adjust',
        type: SettingsElementsType.range,
        properties: {max: 1023},
        group: [SettingsElementsGroup.G_Amperage]
    },
    {
        id: 'S16_RSSIMIN',
        position: 62,
        secondByte: 63,
        description: 'RSSI Minimum',
        type: SettingsElementsType.range,
        properties: {max: 1023},
        group: [SettingsElementsGroup.G_RSSI]
    },
    {
        id: 'S16_RSSIMAX',
        position: 64,
        secondByte: 65,
        description: 'RSSI Maximum',
        type: SettingsElementsType.range,
        properties: {max: 1023},
        group: [SettingsElementsGroup.G_RSSI]
    }
];

