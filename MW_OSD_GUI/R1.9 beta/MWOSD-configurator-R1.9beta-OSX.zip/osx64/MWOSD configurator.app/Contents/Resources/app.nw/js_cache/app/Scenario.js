Scenario = function(){
    this.scenario = this.IDDLE;

    this.handlers = [];
};

/**
 *
 * @type {{IDDLE: number, READ_EE: number, WRITE_EE: number, WRITE_FONT: number, DEFAULT: number, RESTART: number}}
 */
Scenario.prototype.scenarioList = {
    IDDLE: 0,
    READ_EE: 1,
    WRITE_EE: 2,
    WRITE_FONT: 3,
    DEFAULT: 4,
    RESTART: 5,
};

Scenario.prototype.registerChangeScenario = function(handler){
    this.handlers.push(handler);
};

/**
 *
 * @returns {number|*}
 */
Scenario.prototype.getScenario = function(){
    return this.scenario;
};

/**
 *
 * @param scenario
 */
Scenario.prototype.setScenario = function(scenario){
    this.scenario = scenario;

    for(var key in this.handlers){
        if(typeof this.handlers[key] == 'function'){
            this.handlers[key](scenario);
        }
    }
};
