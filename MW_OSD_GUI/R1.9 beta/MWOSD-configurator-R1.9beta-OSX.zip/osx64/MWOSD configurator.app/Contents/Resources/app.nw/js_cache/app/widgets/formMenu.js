FormMenu = function (targetNode) {
    var _this = this;

	this.targetNode = targetNode;

	this.handleReadFromOsd = function () {
	};
	this.handleWriteToOsd = function () {
	};
	this.handleOpenFontEditor = function () {
	};
    this.handleOpenLogoEditor = function () {
    };
	this.handleWriteFont = function () {
	};
	this.handleDefault = function () {
	};
	this.handleRestart = function () {
	};
    this.handleLoadFont = function () {
    };

	this.readFromOsd = $('<button>').html('Read').button().click(function () {
		_this.handleReadFromOsd()
	});
	this.writeToOsd = $('<button>').html('Write').button().click(function () {
		_this.handleWriteToOsd()
	});

  this.fontLoad = $('<button>').html('Change').button().click(function () {
    _this.handleLoadFont()
  });
	this.fontWrite = $('<button>').html('Upload').button().click(function () {
		_this.handleWriteFont()
	});
	this.fontEditor = $('<button>').html('Edit').button().click(function () {
		_this.handleOpenFontEditor()
	});

    this.logoEditor = $('<button>').html('Logo Editor').button().click(function () {
        _this.handleOpenLogoEditor()
    }).button( "disable" );
	
	this.default = $('<button>').html('Default').button().addClass('danger').click(function () {
		_this.handleDefault()
	});
	this.restart = $('<button>').html('Restart').button().click(function () {
		_this.handleRestart()
	});

	this.targetNode.append($('<span>').html('OSD settings: ')).append($('<br>')).append(this.readFromOsd).append(this.writeToOsd).append(this.default).append(this.restart);
	this.targetNode.append($('<br>')).append($('<br>'));
	this.targetNode.append($('<span>').html('FONT: ')).append($('<br>')).append(this.fontLoad).append(this.fontWrite).append(this.fontEditor).append(this.logoEditor);

    ProfileStorageGlobal.changeMainProfile(function(profile){
        if(profile && profile[0] && profile[0] < 16){
            _this.logoEditor.button( "disable" );
        }else{
            _this.logoEditor.button( "enable" );
        }
    });
};


