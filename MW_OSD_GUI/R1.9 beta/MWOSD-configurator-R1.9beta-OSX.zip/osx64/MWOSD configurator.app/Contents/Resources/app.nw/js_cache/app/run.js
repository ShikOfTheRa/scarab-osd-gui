TranslateNull = function(){

};

TranslateNull.prototype.frameValueToForm = function(value){
    return value;
};

TranslateNull.prototype.formValueToFrame = function(value){
    return value;
};

TranslateSignedInt = function(){

};

TranslateSignedInt.prototype.frameValueToForm = function(value){
    return value - 128;
};

TranslateSignedInt.prototype.formValueToFrame = function(value){
    return value + 128;
};



$(document).ready(function () {

    var service = analytics.getService('mwosd_app');
	tracker = service.getTracker('UA-54508077-3');

	mainApp = new MainApp();
	mainApp.run();
});
