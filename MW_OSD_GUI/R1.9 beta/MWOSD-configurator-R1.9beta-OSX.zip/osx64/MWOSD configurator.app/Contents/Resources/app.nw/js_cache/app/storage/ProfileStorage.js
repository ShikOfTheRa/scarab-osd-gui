var scrennSetting = {
    pal: [30, 14],
    ntsc: [30, 11]
};

var ProfileStorage = function(){
    this._mainProfile = [];
    this._profileLength = 42;

    this._sensorsProfile = null;
    this._infoProfile = null;


    this._state = this.state.START_TO_END;

    this.clear();

    //callback
    this.changeStateCallbacks = [];
    this.changeSensorsCallbacks = [];
    this.changeInfoCallbacks = [];
    this.changeProfileCallbacks = [];
};

ProfileStorage.prototype.state = {
    STATE_CLEAN: 0,
    STATE_FILLING: 1,
    STATE_DONE: 2,
};

/**
 *
 */
ProfileStorage.prototype.prepareToLoad = function(){
    this.clear();
};


/**
 *
 */
ProfileStorage.prototype.clear = function(){
    this._mainProfile = [];

    for(var i = 0; i < this._profileLength; i++){
        this._mainProfile.push(
            {
                index: i * 10,
                values: {values: {}}
            }
        );
    };

    this._sensorsProfile = null;
    this._infoProfile = null;

    this._changeState(this.state.STATE_CLEAN);
    this._changeMainProfile(this._getFlatProfile(), this.type.CHANGE_CLEAR);
};

/**
 *
 * @returns {*}
 */
ProfileStorage.prototype.getOneAdressWhatYouNeed = function () {
    for (var index in this._mainProfile) {

        if (this._mainProfile[index].values == null || this._mainProfile[index].values.values == null || $.isEmptyObject(this._mainProfile[index].values.values)) {
            if(index == 0){
                this._changeState(this.state.STATE_FILLING, 0);
            }else{
                this._changeState(this.state.STATE_FILLING, Math.round((this._profileLength / 100) * (index + 1)));
            }

            return this._mainProfile[index].index;
        }
    }

    this._changeState(this.state.STATE_DONE);
    return false;
};

/**
 *
 */
ProfileStorage.prototype._getFlatProfile = function () {

    var flatProfile = {};

    for (var key in this._mainProfile) {
        if (this._mainProfile[key].values) {
            for (var address in this._mainProfile[key].values.values) {
                flatProfile[address] = this._mainProfile[key].values.values[address];
            }
        }
    }
    return flatProfile;
};

/**
 *
 */
ProfileStorage.prototype.getMainProfile = function () {
    return this._mainProfile;
};

/**
 *
 */
ProfileStorage.prototype.setMainProfile = function (profile) {
    this._mainProfile = profile;
    this._changeMainProfile(this._getFlatProfile(), this.type.CHANGE_LOAD_FROM_FILE);
};

/**
 *
 */
ProfileStorage.prototype.setValuesForLayout = function (layoutId, values) {
    var oldProfile = this._getFlatProfile();

    if(values.length != layoutLength){
        console.log('bad values length for fill layout, excepted:' + layoutLength + ' , got:' + values.length);
        return;
    }

    if(!layoutAddress[layoutId]){
        console.log('layout ID doesnt EXITS : ' + layoutId);
        return;
    }

    var startAddress = layoutAddress[layoutId][0];

    for(var valuesKey in values)
    {
        this._setValue(startAddress + (valuesKey * 1), values[valuesKey]);
    }

    this._changeMainProfile(this._getFlatProfile(), this.type.CHANGE_LOAD_FROM_PRESET, oldProfile, {layoutId: layoutId});
};


/**
 *
 * @type {{OSD_READ_CMD_EE: number}}
 */
ProfileStorage.prototype.commandList = {
    OSD_SENSORS: 7,
    OSD_INFO: 10,
    OSD_READ_CMD_EE: 9
};

/**
 *
 * @param frame
 */
ProfileStorage.prototype.setReadWriteFrameValue = function (frame) {

    if (frame.command != this.commandList.OSD_READ_CMD_EE) { // set only read/write frame
        return;
    }

    for (var index in this._mainProfile) {
        if (this._mainProfile[index].index == Object.keys(frame.values)[0]) {
            this._changeMainProfile(this._getFlatProfile(), this.type.CHANGE_LOAD_FROM_DEVICE);
            return this._mainProfile[index].values = frame;
        }
    }
};

/**
 *
 * @param profile
 */
ProfileStorage.prototype._changeMainProfile = function(profile, type, oldProfile, data){
    for(var key in this.changeProfileCallbacks){
        if(typeof this.changeProfileCallbacks[key] == 'function'){
            this.changeProfileCallbacks[key](profile, type, oldProfile, data);
        }
    }
};

/**
 *
 * @param callBack
 */
ProfileStorage.prototype.changeMainProfile = function(callBack){
    this.changeProfileCallbacks.push(callBack);
};

/**
 *
 * @returns {number | *}
 */
ProfileStorage.prototype.getState = function(){
    return this._state;
};

/**
 *
 * @param callBack
 */
ProfileStorage.prototype._changeState = function(state, progress){
    this._state = state;
    for(var key in this.changeStateCallbacks){
        if(typeof this.changeStateCallbacks[key] == 'function'){
            this.changeStateCallbacks[key](state, progress);
        }
    }
};

/**
 *
 * @param callBack
 */
ProfileStorage.prototype.changeState = function(callBack){
    this.changeStateCallbacks.push(callBack);
};


/**
 *
 * @param frame
 */
ProfileStorage.prototype._changeSensorValues = function(frame){
    this._sensorsProfile = frame.values;

    for(var key in this.changeSensorsCallbacks ){
        if(typeof this.changeSensorsCallbacks[key] == 'function'){
            this.changeSensorsCallbacks[key](this._sensorsProfile);
        }
    }
};

/**
 *
 * @param callBack
 */
ProfileStorage.prototype.changeSensorValues = function(callBack){
    this.changeSensorsCallbacks.push(callBack);
};


/**
 *
 * @param frame
 */
ProfileStorage.prototype._changeInfoValues = function(frame){
    if(JSON.stringify(this._infoProfile)==JSON.stringify(frame.values)){
        return;
    }

    this._infoProfile = frame.values;
    for(var key in this.changeInfoCallbacks){
        if(typeof this.changeInfoCallbacks[key] == 'function'){
            this.changeInfoCallbacks[key](this._infoProfile);
        }
    }
};

/**
 *
 * @param callBack
 */
ProfileStorage.prototype.getInfoValues = function(){
    return this._infoProfile;
};

/**
 *
 * @param callBack
 */
ProfileStorage.prototype.changeInfoValues = function(callBack){
    this.changeInfoCallbacks.push(callBack);
};


/**
 *
 * @param frame
 */
ProfileStorage.prototype.setSenzorsFrameValue = function (frame) {
    if (frame.command != this.commandList.OSD_SENSORS) { // set only diag frame
        return;
    }
    this._changeSensorValues(frame);
};

/**
 *
 * @param frame
 */
ProfileStorage.prototype.setInfoFrameValue = function (frame) {

    if (frame.command != this.commandList.OSD_INFO) { // set only diag frame
        return;
    }
    this._changeInfoValues(frame);
};

/**
 *
 * @param position
 * @param value
 */
ProfileStorage.prototype.setValue = function(position, value){
    var oldProfile = this._getFlatProfile();
    this._setValue(position, value);
    this._changeMainProfile(this._getFlatProfile(), this.type.CHANGE_FORM_VALUE, oldProfile);
};

/**
 * DONT USE!!!!
 *
 * @param position
 * @param value
 */
ProfileStorage.prototype._setValue = function(position, value){
    var frame = this._mainProfile[Math.floor(position / 10)].values;
    if(!frame.values[position]){
        frame.values[position] = 0x00;
    }
    frame.values[position] = value;
};

/**
 *
 * @param position_L
 * @param position_H
 * @param positon
 */
ProfileStorage.prototype.setLayoutPosition = function(position, value){
    var frame = this._mainProfile[Math.floor(position / 10)].values;
    if(!frame.values[position]){
        frame.values[position] = 15;
    }

    if(!frame.values[position + 1]){
        frame.values[position + 1] = 0xCC;
    }

    var high_B   = frame.values[position + 1] & 0xC0;
    var low_B = value & 0xFF;
    high_B = high_B | ((value >> 8) & 0xFF);

    frame.values[position] = low_B;
    frame.values[position + 1] = high_B;

    this._changeMainProfile(this._getFlatProfile(), this.type.CHANGE_MOVE);

};

/**
 *
 * @param position
 * @param value
 */
ProfileStorage.prototype.setElementInLayoutVisible = function(position, isVisible){

    var frameLow = this._mainProfile[Math.floor(position / 10)].values;
    var frameHigh = this._mainProfile[Math.floor((position + 1) / 10)].values;
    if(!frameLow.values[position]){
        frameLow.values[position] = 15;
    }

    if(!frameHigh.values[position + 1]){
        frameHigh.values[position + 1] = 0;
    }

    var value = frameHigh.values[position + 1];

    value = value & ~(1 << 6);
    value = value & ~(1 << 7);

    value = value | (isVisible ? 1 : 0) << 6;
    value = value | (isVisible ? 1 : 0) << 7;

    frameHigh.values[position + 1] = value;
    this._changeMainProfile(this._getFlatProfile(), this.type.CHANGE_VISIBLE);
};

ProfileStorage.prototype.type = {
    CHANGE_LOAD_FROM_DEVICE  : 0,
    CHANGE_VISIBLE           : 1,
    CHANGE_MOVE              : 2,
    CHANGE_CLEAR             : 3,
    CHANGE_FORM_VALUE        : 4,
    CHANGE_LOAD_FROM_FILE    : 5,
    CHANGE_LOAD_FROM_PRESET  : 6,
};


var ProfileStorageGlobal = new ProfileStorage();

