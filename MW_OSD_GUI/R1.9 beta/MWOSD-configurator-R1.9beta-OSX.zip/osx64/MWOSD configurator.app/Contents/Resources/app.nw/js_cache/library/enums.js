connectionMode = {
    NORMAL: 0,
    PASSTHROUGH: 1,
};