var ProfileMigrate = function(){

};

/**
 *
 * @param from
 * @param to
 * @param profile
 * @returns {*}
 */
ProfileMigrate.prototype.migrate = function(from, to, profile){

    if(to > 1000){
        to = this.fwVersionToEepromVersion(to);
    }

    var changeToVersion = false;

    if(from == 15 && to == 16){
        profile = this._less15to16(profile);
        changeToVersion = 16;
    }

    return {profile: profile, changeToVersion: changeToVersion};
};

/**
 *
 * @param fwVersion
 * @returns {number}
 */
ProfileMigrate.prototype.fwVersionToEepromVersion = function(fwVersion){

    switch (fwVersion) {
        case 1800: return 15;
        case 1810: return 15;
        case 1811: return 15;
        case 1812: return 16;
    }
};

/**
 *
 * @param profile
 * @returns {*}
 * @private
 */
ProfileMigrate.prototype._less15to16 = function(profile){

    for(var i = 40; i > 4; i--)
    {
        for(var ii = (i * 10) + 9; ii >= i * 10 && ii < (i * 10) + 10 ; ii--) {
            if(ii > 57){

                var newPosition = ii + 7;
                profile[Math.floor(newPosition / 10)].values.values[newPosition] = profile[i].values.values[ii]

            }
        }
    }

    return profile;
};

var ProfileMigrateGlobal = new ProfileMigrate();