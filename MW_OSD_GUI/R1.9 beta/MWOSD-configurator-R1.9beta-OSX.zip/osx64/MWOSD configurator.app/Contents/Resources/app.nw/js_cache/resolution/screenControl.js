ScreenControl = function(target){
	this.target = target;
	this.settings = {};

    this.activeLayout = 0;
    this.changeVisible = function(){
    	console.log('changeVisible not registered');
	};

    this.elements = [
        {}, {}, {}
    ];

    ProfileStorageGlobal.changeInfoValues(function(values){
        //fixedwing
        if(values && values[3] == 2){
            $('.control_conditions_fixedwing').closest('tr').show();
        }else{
            $('.control_conditions_fixedwing').closest('tr').hide();
            $('.control_conditions_fixedwing').attr('checked', false).trigger('change');
        }
    });
};

/**
 *
 * @param name
 * @param layout
 * @returns {*|jQuery}
 */
ScreenControl.prototype.createCheckBox = function(name, layout, params){
	var input = $('<input>').data('layout', layout).attr('type', 'checkbox').addClass('custom-control-input').data('id', name);
	var _this = this;

	if(params && params.conditions)
    {
        for(var key in params.conditions){
            input.addClass('control_conditions_' + params.conditions[key]);
        }
    }

    input.change(function(event){
    	_this.changeVisible($(this).data('id'), $(this).is(':checked'), $(this).data('layout'));
	});

    this.elements[layout][name] = input;

	return $('<label>').append(input).append($('<span>').addClass('custom-control-indicator')).addClass('custom-control custom-checkbox')
};

/**
 *
 */
ScreenControl.prototype.render = function(){
	var table = $('<table>');
	for(var key in this.settings.elements){
	    if(!this.settings.elements[key]['class'] && !this.settings.elements[key]['modificatorFor']){
	        continue;
        }

        var tr = $('<tr>').attr('id', 'controll_' + this.settings.elements[key]['code'].replace(' ', '')).addClass('control-row-hover');
        tr.append($('<th>').html(this.settings.elements[key]['label']));

        for(var i = 0; i < 3; i++){
            tr.append($('<td>').html(this.createCheckBox(this.settings.elements[key]['code'], i, this.settings.elements[key].params)));
		}

        table.append(tr);
	}

	this.target.append(table);
    this.redrawActiveLayout();
    $('#main_screen_control  table tr  td:nth-child(4)').hide();
};

/**
 *
 * @param layoutId
 */
ScreenControl.prototype.setActiveLayout = function(layoutId){
    this.activeLayout = layoutId;
	this.redrawActiveLayout();
};

/**
 *
 */
ScreenControl.prototype.redrawActiveLayout = function(){

    this.target.find('td').removeClass('activeRow');
    this.target.find('td:nth-child('+ (this.activeLayout + 2) + ')').addClass('activeRow');
};

ScreenControl.prototype.hightlightElement = function(name){
    if(!name){
        $('.control-row-hover').removeClass('control-row-hover-active');
        return;
    }

    $('.control-row-hover').removeClass('control-row-hover-active');
    name = name.replace(' ', '');
    if($('#controll_' + name)){
        $('#controll_' + name).addClass('control-row-hover-active');
    }

};

ScreenControl.prototype.scrollTo = function(name){
    if(!name){
        return;
    }

    name = name.replace(' ', '');
    if($('#controll_' + name)){
        $('#main_screen_control').stop();
        $('#main_screen_control').scrollTo($('#controll_' + name), 100);
    }

};



/**
 *
 */
ScreenControl.prototype.setValue = function(layoutId, elementId, value){
    this.elements[layoutId][elementId].prop('checked', !!value);
};

/**
 *
 */
ScreenControl.prototype.reDraw = function(){
    this.target.html('');
    this.elements = [
        {}, {}, {}
    ];
	this.render();
};

/**
 *
 * @param settings
 */
ScreenControl.prototype.setSettings = function(settings){
    this.settings = settings
};




