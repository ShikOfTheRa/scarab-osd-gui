McmList = function (target, fileList) {
    this.fileList = fileList;

    this.table = $('<table>').addClass('table');

    this.loadFont = function(url){
        console.log(url);
    };

    this.loadFontString = function(fontData){
        console.log(fontData);
    };

    this.target = target;
};

McmList.prototype.buildTable = function () {
    var _this = this;
    this.table.html('');
    for(var fileKey in this.fileList){
        var tr = $('<tr>');
        var name = $('<td>').html(this.fileList[fileKey].name).data('url', this.fileList[fileKey].url).click(function () {
            _this.loadFont($(this).data('url'));
        });

        tr.append(name);
        this.table.append(tr);
    }

    chrome.storage.local.get('user_mcm', function (data) {
        if(data && data.user_mcm) {
            var tr = $('<tr>');
            var name = $('<td>').html('User\'s font').click(function () {
                chrome.storage.local.set({defaultMCMFile: 'userFont'});
                _this.loadFontString(data.user_mcm);
            });

            tr.append(name);
            _this.table.append(tr);
        }
    });


    this.target.append(this.table);

};