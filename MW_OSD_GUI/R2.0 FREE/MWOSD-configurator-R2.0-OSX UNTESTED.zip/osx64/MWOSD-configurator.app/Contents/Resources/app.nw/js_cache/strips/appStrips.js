/**console.timeEnd();
 * main app class for edit max7456 file, connect module by handler
 * @constructor
 */
var AppStrips = function () {
	this.screen = new ScreenStripsEditor($('#editorTable'), true);
	this.screen.disabled = true;
	this.preview = new FontMap($('#fontMap'));
	this.bigPreview = new FontWrite([], $('#preview'), 10);
    this.defaultMCMFile = 'data/mcm/default.mcm';

	this.fontDataClipboard = null;

	var _this = this;

	//scale UI
	$("#scale").slider({
		value: _this.bigPreview.scale,
		min: 1,
		max: 19,
		step: 1,
		slide: function (event, ui) {
			_this.bigPreview.setScale(ui.value);
		}
	});

	//change color
	$("#select_color").buttonset();
	$("#select_color").find('input').change(function () {
		_this.screen.fillType = $(this).attr('id');
	});

    $("#select_color").find('#black').attr('checked','checked').button("refresh");

	//connect screen to bigpreview and preview
	this.screen.onChangeOnPosition = function (x, y, color) {
		_this.bigPreview.drawToPosition(x, y, color);
		_this.preview.drawToPosition(x, y, color);
	};

	this.screen.onChangeFontData = function (fontData) {
		_this.bigPreview.setNewImageData(fontData);
		_this.preview.setNewImageData(fontData);
	};

	//inicialize clear button
	$("#clear")
		.button()
		.click(function (event) {
			event.preventDefault();
			_this.screen.deepClearScreen();
		});

    $("#copyChar")
        .button()
        .click(function (event) {
            event.preventDefault();
            _this.fontDataClipboard = _this.preview.getActiveFontData();
            if(_this.fontDataClipboard){
                $.toast({
                    text: 'Char was copied to clipboard',
                    position: 'top-right',
                    icon: 'success'
                });
			}else{
                $.toast({
                    text: 'No char for copy to clipboard',
                    position: 'top-right',
                    icon: 'warning'
                });
			}
        });

    $("#pasteChar")
        .button()
        .click(function (event) {
            event.preventDefault();
            /*_this.screen.setNewImageData(_this.fontDataClipboard);
            _this.bigPreview.setNewImageData(_this.fontDataClipboard);*/
            if(_this.fontDataClipboard){
                _this.preview.setNewImageDataToActiveIndex(_this.fontDataClipboard);
			}else{
                $.toast({
                    text: 'No char for paste from clipboard',
                    position: 'top-right',
                    icon: 'warning'
                });
			}

        });

	$("#moveUpChar")
		.button()
		.click(function (event) {
			event.preventDefault();
			var fontData = _this.preview.getActiveFontData();
			if(!fontData){
				return;
			}

			var originalLength = fontData.length;
			if(fontData){
				for(var i = 0; i < 24; i++){
					fontData.shift();
				}
				fontData = _this.fixLengthFonData(fontData, originalLength);
				_this.preview.setNewImageDataToActiveIndex(fontData);
			}else{
				$.toast({
					text: 'No char',
					position: 'top-right',
					icon: 'warning'
				});
			}

		});

	$("#moveDownChar")
		.button()
		.click(function (event) {
			event.preventDefault();
			var fontData = _this.preview.getActiveFontData();
			if(!fontData){
				return;
			}

			var originalLength = fontData.length;
			if(fontData){
				for(var i = 0; i < 12; i++){
					fontData.unshift("0", "1");
				}

				fontData = _this.fixLengthFonData(fontData, _this.bigPreview.baseSize[0] * _this.bigPreview.baseSize[1] * 2);
				fontData = _this.fixLengthFonData(fontData, originalLength);
				_this.preview.setNewImageDataToActiveIndex(fontData);
			}else{
				$.toast({
					text: 'No char',
					position: 'top-right',
					icon: 'warning'
				});
			}

		});

	$("#moveLeftChar")
		.button()
		.click(function (event) {
			event.preventDefault();
			var fontData = _this.preview.getActiveFontData();
			if(!fontData){
				return;
			}

			var originalLength = fontData.length;
			if(fontData){
				var fontDataChunks = fontData.chunk(24);
				var newFontData = [];
				for(var i in fontDataChunks){
					fontDataChunks[i].shift();
					fontDataChunks[i].shift();

					fontDataChunks[i].push("0");
					fontDataChunks[i].push("1");

					newFontData = newFontData.concat(fontDataChunks[i]);
				}
				newFontData = _this.fixLengthFonData(newFontData, originalLength);
				_this.preview.setNewImageDataToActiveIndex(newFontData);
			}else{
				$.toast({
					text: 'No char',
					position: 'top-right',
					icon: 'warning'
				});
			}

		});

	$("#moveRightChar")
		.button()
		.click(function (event) {
			event.preventDefault();
			var fontData = _this.preview.getActiveFontData();
			if(!fontData){
				return;
			}

			var originalLength = fontData.length;
			if(fontData){
				var fontDataChunks = fontData.chunk(24);
				var newFontData = [];
				for(var i in fontDataChunks){
					fontDataChunks[i].unshift("0", "1");
					fontDataChunks[i] = _this.fixLengthFonData(fontDataChunks[i], 24);
					newFontData = newFontData.concat(fontDataChunks[i]);
				}

				newFontData = _this.fixLengthFonData(newFontData, originalLength);
				_this.preview.setNewImageDataToActiveIndex(newFontData);
			}else{
				$.toast({
					text: 'No char',
					position: 'top-right',
					icon: 'warning'
				});
			}

		});

	//connect preview to screen and bigpreview
	this.preview.onChangeFontData = function (fontData) {
		_this.screen.setNewImageData(fontData);
		_this.bigPreview.setNewImageData(fontData);
		_this.screen.disabled = false;
	};
};

/**
 * render all component
 */
AppStrips.prototype.fixLengthFonData = function (fontData, length) {
	if(fontData.length > length){
		return fontData.slice(0, length);
	}else if(fontData.length < length){
		var fontDataLength = fontData.length
		for (var i = 0; i < (length - fontDataLength) + 5; i++){
			fontData.push("0");
			fontData.push("1");
		}
		return fontData.slice(0, length);
	}

	return fontData;
};

/**
 * render all component
 */
AppStrips.prototype.run = function () {
	this.screen.render();
	this.preview.render();
};

/**
 *
 * @param data
 */
AppStrips.prototype.loadDataFromString = function (data, doneCallBack) {
	this.preview.setFontsData(data);
	this.bigPreview.setNewImageData([]);
	this.screen.setNewImageData([]);
	this.screen.disabled = true;

	if (doneCallBack) {
        doneCallBack();
    }
};

/**
 * this is test function, in future we will use load from file, or something like it
 *
 * @param urlTarget
 */
AppStrips.prototype.loadDataByAjax = function (urlTarget, doneCallBack) {
	var _this = this;
	$.ajax({
		url: urlTarget,
		context: document.body
	}).done(function (data) {

		_this._saveLastUsedFont(urlTarget);
		_this.preview.setFontsData(data);
		_this.bigPreview.setNewImageData([]);
		_this.screen.setNewImageData([]);
		_this.screen.disabled = true;

		if (doneCallBack) {
			doneCallBack();
		}
	});
};

/**
 *
 * @param doneCallBack
 */
AppStrips.prototype.loadDataByAjaxDefault = function(doneCallBack){
	var _this = this;
    chrome.storage.local.get(['defaultMCMFile'], function(result) {

    	if(!result.defaultMCMFile){
            _this.loadDataByAjax(_this.defaultMCMFile, doneCallBack);
    		return;
		}else if(result.defaultMCMFile != 'userFont'){
            _this.loadDataByAjax(result.defaultMCMFile, doneCallBack);
            return;
		}else if(result.defaultMCMFile == 'userFont'){
            chrome.storage.local.get('user_mcm', function (data) {
                if(data && data.user_mcm) {
					_this.loadDataFromString(data.user_mcm, doneCallBack);
                }
            });
        }
    });
};

/**
 *
 * @param url
 * @private
 */
AppStrips.prototype._saveLastUsedFont = function(url){
	for(var mcmKey in McmEnum){
		if(McmEnum[mcmKey].url == url){
            chrome.storage.local.set({defaultMCMFile: url});
            break;
		}
	}
};


AppStrips.prototype.setNewFontData = function (fontData) {
	this.preview.setFontsData(fontData);
	this.bigPreview.setNewImageData([]);
	this.screen.setNewImageData([]);
	this.screen.disabled = true;
};

/**
 * show raw data for file
 *
 * #MTODO, need wrap after X chars
 */
AppStrips.prototype.fontsData = function () {
	var buffer = "";
	for (var i = 0; i < this.preview.canvaseElements.length; i++) {
		buffer += this.preview.canvaseElements[i].fontData.join('');
	}

	var formatedBuffer = 'MAX7456\n';
	for (var i = 1; i <= buffer.length; i++) {
		formatedBuffer += buffer[i - 1];
		formatedBuffer += i % 8 == 0 ? '\n' : '';
	}
	return formatedBuffer;
};

