CopyLayoutControl = function(target, previewTarget){
	this.target = target;
	this.settings = {};

	this.copy = target.find(".copy").button();
	this.paste = target.find(".paste").button().attr('disabled', 'disabled').attr("title", "no preview");

	this.clipBoardLayoutData = [];

	this.eventCopy = function(){}
	this.eventPaste = function(){}

	var _this = this;
	this.copy.click(function(){
		_this.eventCopy();

		html2canvas(previewTarget[0]).then(function(canvas) {
			_this.paste.tooltip({ content: canvas, tooltipClass: "tooltip_preview" })/*.tooltip("open")*/;
		});
	})

	this.paste.click(function(){
		_this.eventPaste(_this.clipBoardLayoutData);
	})
};

/**
 *
 * @param layoutData
 */
CopyLayoutControl.prototype.setLayoutData = function(layoutData){
	// reset keys
	var counterKey = 0;
	this.clipBoardLayoutData = [];
	for(var key in layoutData){
		this.clipBoardLayoutData[counterKey++] = layoutData[key];
	}

	this.paste.removeAttr('disabled');
}