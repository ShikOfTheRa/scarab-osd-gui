var ProfileMigrate = function(){

};

/**
 *
 * @param from
 * @param to
 * @param profile
 * @returns {*}
 */
ProfileMigrate.prototype.migrate = function(from, to, profile){

    if(to > 1000){
        to = this.fwVersionToEepromVersion(to);
    }

    var changeToVersion = false;

    if(from == 15 && to == 16){
        profile = this._less15to16(profile);
        changeToVersion = 16;
    }

    if(from == 15 && to == 18){
        profile = this._less15to16(profile);
        profile = this._16to18(profile);
        changeToVersion = 18;
    }

    if((from == 16 || from == 17) && to == 18){
        profile = this._16to18(profile);
        changeToVersion = 18;
    }

    return {profile: profile, changeToVersion: changeToVersion};
};

/**
 *
 * @param fwVersion
 * @returns {number}
 */
ProfileMigrate.prototype.fwVersionToEepromVersion = function(fwVersion){

    if(fwVersion >= 1800 && fwVersion < 1812){
        return 15
    }

    if(fwVersion >= 1812 && fwVersion < 2000){
        return 16
    }

    if(fwVersion >= 2000){
        return 18
    }
};

/**
 *
 * @param profile
 * @returns {*}
 * @private
 */
ProfileMigrate.prototype._less15to16 = function(profile){

    for(var i = 40; i > 4; i--)
    {
        for(var ii = (i * 10) + 9; ii >= i * 10 && ii < (i * 10) + 10 ; ii--) {
            if(ii > 57){

                var newPosition = ii + 7;
                profile[Math.floor(newPosition / 10)].values.values[newPosition] = profile[i].values.values[ii]

            }
        }
    }

    return profile;
};

/**
 *
 * @param profile
 * @returns {*}
 * @private
 */
ProfileMigrate.prototype._16to18 = function(profile){
    var newProfile = JSON.parse(DefaultV18);
    for(var i = 0; i < 405; i++){
        if(i <= 71){
            this._writeValueToposition(this._getValueFromPosition(i, profile), i, newProfile);
        }else if(i >= 77 && i <= 176){
            this._writeValueToposition(this._getValueFromPosition(i, profile), i + 4, newProfile);
        }else if(i >= 177 && i <= 276){
            this._writeValueToposition(this._getValueFromPosition(i, profile), i + 14, newProfile);
        }else if(i >= 277 && i <= 376){
            this._writeValueToposition(this._getValueFromPosition(i, profile), i + 24, newProfile);
        }
    }

    return newProfile;
};


/**
 *
 * @param profile
 * @returns {*}
 * @private
 */
ProfileMigrate.prototype._writeValueToposition = function(value, position, profile){
    profile[Math.floor(position / 10)].values.values[position] = value;
};

/**
 *
 * @param position
 * @param profile
 * @returns {*}
 * @private
 */
ProfileMigrate.prototype._getValueFromPosition = function(position, profile){
    return profile[Math.floor(position / 10)].values.values[position];
};

var ProfileMigrateGlobal = new ProfileMigrate();