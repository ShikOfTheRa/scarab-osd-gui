/* ##################################################### */
/* BASE
 /* ##################################################### */

var BaseSettings = function (fontMap) {
	this.fontMap = fontMap;
    this.modificator = [];
	this.canMove = true;
	this.canMoveX = true;
	this.canMoveY = true;
};

BaseSettings.prototype.infoData = [];

/**
 *
 * @param digit
 * @returns {*}
 */
BaseSettings.prototype.parseDigit = function (digit) {
	return this.fontMap.canvaseElements[BaseSettings.prototype.startDigi + parseInt(digit)];
};

/**
 *
 * @type {number}
 */
BaseSettings.prototype.offsetX = 0;


/**
 * which elements are hidden if master elements is active
 * @type {Array}
 */
BaseSettings.prototype.dependElementsInverted = [];

/**
 *
 * @type {boolean}
 */
BaseSettings.prototype.inverted = false;

/**
 *
 * @type {number}
 */
BaseSettings.prototype.offsetY = 0;

/**
 *
 * @type {{}}
 */
BaseSettings.profile = {};

/**
 *
 * @type {int}
 */
BaseSettings.connectionState = 0;

/**
 *
 * @type {{}}
 */
BaseSettings.emulatorValues = {};
/**
 *
 * @type {boolean}
 */
BaseSettings.prototype.dependElements = [];


/**
 *
 * @type {boolean}
 */
BaseSettings.prototype.canMove = true;


/**
 *
 * @param digit
 * @returns {*}
 */
BaseSettings.prototype.parseAlpha = function (alpha) {
	return this.fontMap.canvaseElements[BaseSettings.prototype.startAlpha + alpha.toLowerCase().charCodeAt(0) - 97];
};


BaseSettings.prototype.startDigi = 48;
BaseSettings.prototype.colon = 58;
BaseSettings.prototype.startAlpha = 65;
BaseSettings.prototype.point = 46;
BaseSettings.prototype.exponent = 94;
BaseSettings.prototype.space = 255;
BaseSettings.prototype.percent = 37;
/* ##################################################### */


/* ##################################################### */
/* Vbat MODULE
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var vBatSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
vBatSettings.prototype = new BaseSettings();
vBatSettings.prototype.constructor = vBatSettings;
/**
 *
 * @type {number}
 */
vBatSettings.prototype.offsetX = 0;

/**
 *
 * @param value
 * @returns {Array}
 */
vBatSettings.prototype.get = function (value) {

	var buffer = [];

	value = value || this.defaultValue;

	if(BaseSettings.profile[27] == 1){
		buffer[buffer.length] = {
			position: [0, 0],
			element: this.fontMap.canvaseElements[146]
		};
	}else{
		buffer[buffer.length] = {
			position: [0, 0],
			element: this.fontMap.canvaseElements[151]
		};
	}

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}

		//alpha
		if (value[i].match(/[a-zA-Z]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseAlpha(value[i])
			};
		}

		if (value[i].match(/\./)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.fontMap.canvaseElements[this.point]
			};

		}
	}

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[169]
	};

	return buffer;
};

vBatSettings.prototype.defaultValue = '15.3';


/* ##################################################### */
/* Vbat VID MODULE
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var vBatVidSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
vBatVidSettings.prototype = new BaseSettings();
vBatVidSettings.prototype.constructor = vBatVidSettings;
/**
 *
 * @type {number}
 */
vBatVidSettings.prototype.offsetX = 0;

/**
 *
 * @param value
 * @returns {Array}
 */
vBatVidSettings.prototype.get = function (value) {

	var buffer = [];

	value = value || this.defaultValue;

	buffer[buffer.length] = {
		position: [0, 0],
		element: this.fontMap.canvaseElements[191]
	};

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}

		//alpha
		if (value[i].match(/[a-zA-Z]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseAlpha(value[i])
			};
		}

		if (value[i].match(/\./)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.fontMap.canvaseElements[this.point]
			};

		}
	}

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[169]
	};

	return buffer;
};

vBatVidSettings.prototype.defaultValue = '12.1';


/* ##################################################### */
/* AMP MODULE
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var ampSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
ampSettings.prototype = new BaseSettings();
ampSettings.prototype.constructor = ampSettings;
ampSettings.prototype.offsetX = 0;

/**
 *
 * @param value
 * @returns {Array}
 */
ampSettings.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}

		//alpha
		if (value[i].match(/[a-zA-Z]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseAlpha(value[i])
			};
		}

		if (value[i].match(/\./)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.fontMap.canvaseElements[this.point]
			};

		}
	}

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[154]
	};

	return buffer;
};

ampSettings.prototype.defaultValue = '21.1';


/* ##################################################### */
/* GPS num SAT
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var gpsNumSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
gpsNumSettings.prototype = new BaseSettings();
gpsNumSettings.prototype.constructor = gpsNumSettings;

/**
 *
 * @type {number}
 */
gpsNumSettings.prototype.offsetX = 0;

/**
 *
 * @param value
 * @returns {Array}
 */
gpsNumSettings.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[30]
	};

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[31]
	};

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}
	}

	return buffer;
};

gpsNumSettings.prototype.defaultValue = '10';

/* ##################################################### */
/* GPS direction to home
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var gpsDirectionSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
gpsDirectionSettings.prototype = new BaseSettings();
gpsDirectionSettings.prototype.constructor = gpsDirectionSettings;
/**
 *
 * @type {number}
 */
gpsDirectionSettings.prototype.offsetX = 0;

/**
 *
 * @param value
 * @returns {Array}
 */
gpsDirectionSettings.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[96 + Number.parseInt(value)]
	};


	return buffer;
};

gpsDirectionSettings.prototype.defaultValue = 4;

/* ##################################################### */
/* GPS distance to home
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var gpsDistanceSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
gpsDistanceSettings.prototype = new BaseSettings();
gpsDistanceSettings.prototype.constructor = gpsDistanceSettings;
/**
 *
 * @type {number}
 */
gpsDistanceSettings.prototype.offsetX = 0;

/**
 *
 * @param value
 * @returns {Array}
 */
gpsDistanceSettings.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

    buffer[buffer.length] = {
        position: [buffer.length, 0],
        element: this.fontMap.canvaseElements[122]
    };

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}
	}

    var unit = BaseSettings.profile[25] == 1 ? 13 : 12;


    buffer[buffer.length] = {
        position: [buffer.length, 0],
        element: this.fontMap.canvaseElements[unit]
    };

	return buffer;
};

gpsDistanceSettings.prototype.defaultValue = '350';

/* ##################################################### */
/* SPEDD
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var speedSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
speedSettings.prototype = new BaseSettings();
speedSettings.prototype.constructor = speedSettings;
/**
 *
 * @type {number}
 */
speedSettings.prototype.offsetX = 0;

/**
 *
 * @param value
 * @returns {Array}
 */
speedSettings.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

    buffer[buffer.length] = {
        position: [buffer.length, 0],
        element: this.fontMap.canvaseElements[245]
    };

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}
	}

    var unit = BaseSettings.profile[25] == 1 ? 166 : 165;
    buffer[buffer.length] = {
        position: [buffer.length, 0],
        element: this.fontMap.canvaseElements[unit]
    };

	return buffer;
};

speedSettings.prototype.defaultValue = '0';

/* ##################################################### */
/*  EAGLE TO HOME POSITION
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var eagleToHomePositionSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
eagleToHomePositionSettings.prototype = new BaseSettings();
eagleToHomePositionSettings.prototype.constructor = eagleToHomePositionSettings;

/**
 *
 * @param value
 * @returns {Array}
 */
eagleToHomePositionSettings.prototype.get = function (value) {

	var buffer = [];

	value = value || this.defaultValue;

    buffer[buffer.length] = {
        position: [buffer.length, 0],
        element: this.fontMap.canvaseElements[242]
    };

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}
	}

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[189]
	};

	return buffer;
};

eagleToHomePositionSettings.prototype.defaultValue = '0';

/**
 *
 * @type {number}
 */
eagleToHomePositionSettings.prototype.offsetX = 0;

/* ##################################################### */
/*  GPS ALTITUDE
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var gpsAltitudeSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
gpsAltitudeSettings.prototype = new BaseSettings();
gpsAltitudeSettings.prototype.constructor = gpsAltitudeSettings;
/**
 *
 * @param value
 * @returns {Array}
 */
gpsAltitudeSettings.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

    buffer[buffer.length] = {
        position: [buffer.length, 0],
        element: this.fontMap.canvaseElements[190]
    };

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}
	}

    var unit = BaseSettings.profile[25] == 1 ? 13 : 12;
    buffer[buffer.length] = {
        position: [buffer.length, 0],
        element: this.fontMap.canvaseElements[unit]
    };

	return buffer;
};

gpsAltitudeSettings.prototype.defaultValue = '5';

/**
 *
 * @type {number}
 */
gpsAltitudeSettings.prototype.offsetX = 0;


/* ##################################################### */
/*  SENZORS
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var senzorsSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
senzorsSettings.prototype = new BaseSettings();
senzorsSettings.prototype.constructor = senzorsSettings;

/**
 *
 * @param value
 * @returns {Array}
 */
senzorsSettings.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

	for (var i = 0; i < 3; i++) {
		buffer[buffer.length] = {
			position: [buffer.length, 0],
			element: this.fontMap.canvaseElements[160 + i]
		};
	}

	for (var i = 0; i < 3; i++) {
		buffer[buffer.length] = {
			position: [buffer.length - 3, 1],
			element: this.fontMap.canvaseElements[0]
		};
	}

	return buffer;
};

senzorsSettings.prototype.defaultValue = '';

/**
 *
 * @type {number}
 */
senzorsSettings.prototype.offsetX = 0;

/* ##################################################### */
/*  HEADING
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var headingSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
headingSettings.prototype = new BaseSettings();
headingSettings.prototype.constructor = headingSettings;
/**
 *
 * @type {number}
 */
headingSettings.prototype.offsetX = 0;
/**
 *
 * @param value
 * @returns {Array}
 */
headingSettings.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

    buffer[buffer.length] = {
        position: [buffer.length, 0],
        element: this.fontMap.canvaseElements[243]
    };

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}
	}

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[189]
	};

	return buffer;
};

headingSettings.prototype.defaultValue = '0';

/* ##################################################### */
/*  COMPASS
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var compassSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
compassSettings.prototype = new BaseSettings();
compassSettings.prototype.constructor = compassSettings;

/**
 *
 * @param value
 * @returns {Array}
 */
compassSettings.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[27]
	};

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[29]
	};

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[28]
	};

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[29]
	};

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[24]
	};

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[29]
	};

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[28]
	};

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[29]
	};

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[26]
	};


	return buffer;
};

compassSettings.prototype.defaultValue = '';

/**
 *
 * @type {number}
 */
compassSettings.prototype.offsetX = 0;

/* ##################################################### */
/*  ALTITUDE
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var altitudeSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
altitudeSettings.prototype = new BaseSettings();
altitudeSettings.prototype.constructor = altitudeSettings;
/**
 *
 * @param value
 * @returns {Array}
 */
altitudeSettings.prototype.get = function (value) {

	var buffer = [];

    value = value || this.defaultValue;

    buffer[buffer.length] = {
        position: [buffer.length, 0],
        element: this.fontMap.canvaseElements[63]
    };

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}
	}

    var unit = BaseSettings.profile[25] == 1 ? 13 : 12;
    buffer[buffer.length] = {
        position: [buffer.length, 0],
        element: this.fontMap.canvaseElements[unit]
    };

	return buffer;
};

altitudeSettings.prototype.defaultValue = '40';

/**
 *
 * @type {number}
 */
altitudeSettings.prototype.offsetX = 0;

/* ##################################################### */
/*  CLIMB RATE
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var climbRateSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
climbRateSettings.prototype = new BaseSettings();
climbRateSettings.prototype.constructor = climbRateSettings;
/**
 *
 * @param value
 * @returns {Array}
 */
climbRateSettings.prototype.get = function (value) {

	var buffer = [];
    value = value || this.defaultValue;
	buffer[buffer.length] = {
		position: [0, buffer.length],
		element: this.fontMap.canvaseElements[143]
	};

	buffer[buffer.length] = {
		position: [0, buffer.length],
		element: this.fontMap.canvaseElements[143]
	};


	return buffer;
};

climbRateSettings.prototype.defaultValue = '0';

/**
 *
 * @type {number}
 */
climbRateSettings.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
climbRateSettings.prototype.offsetY = -1;
/* ##################################################### */
/*  TIMER
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var timerSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
timerSettings.prototype = new BaseSettings();
timerSettings.prototype.constructor = timerSettings;
/**
 *
 * @param value
 * @returns {Array}
 */
timerSettings.prototype.get = function (value) {

	var buffer = [];

	value = value || this.defaultValue;
	buffer[buffer.length] = {
		position: [0, buffer.length],
		element: this.fontMap.canvaseElements[155]
	};

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}

		if (value[i].match(/:/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.fontMap.canvaseElements[58]
			};

		}
	}


	return buffer;
};

timerSettings.prototype.defaultValue = '04:50';

/**
 *
 * @type {number}
 */
timerSettings.prototype.offsetX = 0;

/* ##################################################### */
/*  ARMED STATUS
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var armedStatusSettings = function (fontMap) {
	this.fontMap = fontMap;
};

armedStatusSettings.prototype.valueType = [
	'NONE',
	'CONNECTED_DISARMED',
    'CONNECTED_ARMED',
];

//extends class
armedStatusSettings.prototype = new BaseSettings();
armedStatusSettings.prototype.constructor = armedStatusSettings;
/**
 *
 * @param value
 * @returns {Array}
 */
armedStatusSettings.prototype.get = function (value) {

	var buffer = [];

	value = value || this.defaultValue;
	var string = 'DISCONNECTED';
	switch (value){
		case 311:
            string = 'DISCONNECTED';
			break;
		case 312:
            string = '  DISARMED  ';
            break;
        case 313:
            string = '   ARMED    ';
            break;
	}


	for (var i = 0; i < string.length; i++) {
		//digit
		if (string[i].match(/[A-Z]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseAlpha(string[i])
			};
		}

        if (string[i] == ' ') {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.fontMap.canvaseElements[0]
            };
        }
	}

	return buffer;
};

armedStatusSettings.prototype.defaultValue = 311;

/**
 *
 * @type {number}
 */
armedStatusSettings.prototype.offsetX = -3;


/* ##################################################### */
/*  PITCH ANGLE
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var pichAngleSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
pichAngleSettings.prototype = new BaseSettings();
pichAngleSettings.prototype.constructor = pichAngleSettings;
/**
 *
 * @param value
 * @returns {Array}
 */
pichAngleSettings.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

	buffer[buffer.length] = {
		position: [0, buffer.length],
		element: this.fontMap.canvaseElements[250]
	};

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}
	}

	return buffer;
};

pichAngleSettings.prototype.defaultValue = '0';

/**
 *
 * @type {number}
 */
pichAngleSettings.prototype.offsetX = 0;

/* ##################################################### */
/*  ROLL ANGLE
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var rollAngleSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
rollAngleSettings.prototype = new BaseSettings();
rollAngleSettings.prototype.constructor = rollAngleSettings;
/**
 *
 * @param value
 * @returns {Array}
 */
rollAngleSettings.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

	buffer[buffer.length] = {
		position: [0, buffer.length],
		element: this.fontMap.canvaseElements[251]
	};

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}
	}

	return buffer;
};

rollAngleSettings.prototype.defaultValue = '0';

/**
 *
 * @type {number}
 */
rollAngleSettings.prototype.offsetX = 0;

/* ##################################################### */
/*  LONGTITUDE
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var longtitudeSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
longtitudeSettings.prototype = new BaseSettings();
longtitudeSettings.prototype.constructor = longtitudeSettings;
/**
 *
 * @param value
 * @returns {Array}
 */
longtitudeSettings.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[203]
	};

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[0]
	};

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}

		if (value[i].match(/\./)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.fontMap.canvaseElements[46]
			};
		}
	}

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[87]
	};

	return buffer;
};

longtitudeSettings.prototype.defaultValue = '71.88970';

/**
 *
 * @type {number}
 */
longtitudeSettings.prototype.offsetX = 0;


/* ##################################################### */
/*  RSSI
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var rssiSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
rssiSettings.prototype = new BaseSettings();
rssiSettings.prototype.constructor = rssiSettings;
/**
 *
 * @param value
 * @returns {Array}
 */
rssiSettings.prototype.get = function (value) {

    value = value || this.defaultValue;

	var buffer = [];
	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[186]
	};

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}
	}

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[37]
	};


	return buffer;
};

rssiSettings.prototype.defaultValue = '70';

/**
 *
 * @type {number}
 */
rssiSettings.prototype.offsetX = 0;


/* ##################################################### */
/*  TEMPEATURE
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var tempeatureSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
tempeatureSettings.prototype = new BaseSettings();
tempeatureSettings.prototype.constructor = tempeatureSettings;

/**
 *
 * @param value
 * @returns {Array}
 */
tempeatureSettings.prototype.get = function (value) {

    value = value || this.defaultValue;

    var buffer = [];
	var unit = BaseSettings.profile[25] == 1 ? 15 : 14;

    buffer[buffer.length] = {
        position: [buffer.length, 0],
        element: this.fontMap.canvaseElements[198]
    };

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}
	}

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[unit]
	};


	return buffer;
};

tempeatureSettings.prototype.defaultValue = '30';

/**
 *
 * @type {number}
 */
tempeatureSettings.prototype.offsetX = 0;

/* ##################################################### */
/*  LATITUDE
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var latitudeSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
latitudeSettings.prototype = new BaseSettings();
latitudeSettings.prototype.constructor = latitudeSettings;
/**
 *
 * @param value
 * @returns {Array}
 */
latitudeSettings.prototype.get = function (value) {

	var buffer = [];

	value = value || this.defaultValue;

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[202]
	};

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[0]
	};

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}

		if (value[i].match(/\./)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.fontMap.canvaseElements[46]
			};
		}
	}

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[78]
	};

	return buffer;
};

latitudeSettings.prototype.defaultValue = '43.09846';

/**
 *
 * @type {number}
 */
latitudeSettings.prototype.offsetX = 0;


/* ##################################################### */
/*  MAH
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var mahSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
mahSettings.prototype = new BaseSettings();
mahSettings.prototype.constructor = mahSettings;
/**
 *
 * @param value
 * @returns {Array}
 */
mahSettings.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;


	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}

	}
  
  buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[164]
	};

	return buffer;
};

mahSettings.prototype.defaultValue = '1221';

/**
 *
 * @type {number}
 */
mahSettings.prototype.offsetX = 0;

/* ##################################################### */
/*  throttle
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var throttleSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
throttleSettings.prototype = new BaseSettings();
throttleSettings.prototype.constructor = throttleSettings;
/**
 *
 * @param value
 * @returns {Array}
 */
throttleSettings.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[200]
	};

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[49]
	};

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[48]
	};

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[48]
	};
  
	return buffer;
};

throttleSettings.prototype.defaultValue = '1221';

/**
 *
 * @type {number}initControl
 */
throttleSettings.prototype.offsetX = 0;


/* ##################################################### */
/*  throttle
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var timeRemining = function (fontMap) {
    this.fontMap = fontMap;
};

//extends class
timeRemining.prototype = new BaseSettings();
timeRemining.prototype.constructor = timeRemining;
/**
 *
 * @param value
 * @returns {Array}
 */
timeRemining.prototype.get = function (value) {

    var buffer = [];
    value = value || this.defaultValue;

    var x = 0;

	buffer[buffer.length] = {
		position: [x++, 0],
		element: this.fontMap.canvaseElements[42],
	};

    for (var i = 0; i < value.length; i++) {
        //digit
        if (value[i].match(/[0-9]/)) {
            buffer[buffer.length] = {
                position: [x++, 0],
                element: this.parseDigit(value[i])
            };
        }

        //alpha
        if (value[i].match(/[a-zA-Z]/)) {
            buffer[buffer.length] = {
                position: [x++, 0],
                element: this.parseAlpha(value[i])
            };
        }

        if (value[i].match(/\./)) {
            buffer[buffer.length] = {
                position: [x++, 0],
                element: this.fontMap.canvaseElements[this.point]
            };

        }

        if (value[i].match(/:/)) {
            buffer[buffer.length] = {
                position: [x++, 0],
                element: this.fontMap.canvaseElements[58]
            };
        }

        if (value[i].match(/\//)) {
            buffer[buffer.length] = {
                position: [x++, 0],
                element: this.fontMap.canvaseElements[47]
            };
        }
    }

    return buffer;
};

timeRemining.prototype.defaultValue = '00:15';

/**
 *
 * @type {number}
 */
timeRemining.prototype.offsetX = 0;


/* ##################################################### */
/*  mAh
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var mAhSettings = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
mAhSettings.prototype = new BaseSettings();
mAhSettings.prototype.constructor = mAhSettings;
/**
 *
 * @param value
 * @returns {Array}
 */
mAhSettings.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[164]
	};

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}
	}

	return buffer;
};

mAhSettings.prototype.defaultValue = '1221';

/**
 *
 * @type {number}
 */
mAhSettings.prototype.offsetX = 0;

/* ##################################################### */
/*  Horizon
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var ahiHorizon = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
ahiHorizon.prototype = new BaseSettings();
ahiHorizon.prototype.constructor = ahiHorizon;

/**
 *
 * @type {boolean}
 */
ahiHorizon.prototype.canMove = true;
ahiHorizon.prototype.canMoveX = false;
ahiHorizon.prototype.canMoveY = [6,7];

/**
 *
 * @type {boolean}
 */
ahiHorizon.prototype.dependElements = ['AHI-sidebars', 'AHI-changeicon'];

/**
 *
 * @param value
 * @returns {Array}
 */
ahiHorizon.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[132]
	};

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[132]
	};

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[132]
	};

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[38]
	};

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[126]
	};

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[188]
	};

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[132]
	};

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[132]
	};

	buffer[buffer.length] = {
		position: [buffer.length, 0],
		element: this.fontMap.canvaseElements[132]
	};

	if(BaseSettings.profile[57] == 1){
        buffer[buffer.length] = {
            position: [2, -3],
            element: this.fontMap.canvaseElements[132]
        };

        buffer[buffer.length] = {
            position: [3, -3],
            element: this.fontMap.canvaseElements[132]
        };

        buffer[buffer.length] = {
            position: [5, -3],
            element: this.fontMap.canvaseElements[132]
        };

        buffer[buffer.length] = {
            position: [6, -3],
            element: this.fontMap.canvaseElements[132]
        };

        buffer[buffer.length] = {
            position: [2, 3],
            element: this.fontMap.canvaseElements[132]
        };

        buffer[buffer.length] = {
            position: [3, 3],
            element: this.fontMap.canvaseElements[132]
        };

        buffer[buffer.length] = {
            position: [5, 3],
            element: this.fontMap.canvaseElements[132]
        };

        buffer[buffer.length] = {
            position: [6, 3],
            element: this.fontMap.canvaseElements[132]
        };
	}

	return buffer;
};

ahiHorizon.prototype.defaultValue = '0';

/**
 *
 * @type {number}
 */
ahiHorizon.prototype.offsetX = -4;

/* ##################################################### */
/*  SIDEBARS
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var ahiSidebars = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
ahiSidebars.prototype = new BaseSettings();
ahiSidebars.prototype.constructor = ahiSidebars;

/**
 *
 * @type {boolean}
 */
ahiSidebars.prototype.canMove = true;
ahiSidebars.prototype.canMoveX = false;
ahiSidebars.prototype.canMoveY = [4,5];

/**
 *
 * @param value
 * @returns {Array}
 */
ahiSidebars.prototype.get = function (value) {

	var buffer = [];

	value = value || this.defaultValue;

	var width = BaseSettings.profile[31] * 1  || 3;
    var height = BaseSettings.profile[12] * 1 || 3;

	var xMiddle = 7;
    var yMiddle = 2;

    var xLeft = xMiddle - width;
    var xRight = xMiddle + width;
    var yStart = yMiddle - height;

    for(var i = 0; i < (height * 2) + 1; i++)
    {
        buffer[buffer.length] = {
            position: [xLeft, yStart + i],
            element: this.fontMap.canvaseElements[18]
        };
    }

    if(this.modificator['AHI-changeicon'] && this.modificator['AHI-changeicon'].isEnable) {
        buffer[buffer.length] = {
            position: [xLeft, yStart + i],
            element: this.fontMap.canvaseElements[207]
        };
    }


    for(var i = 0; i < (height * 2) + 1; i++)
    {
        buffer[buffer.length] = {
            position: [xRight, yStart + i],
            element: this.fontMap.canvaseElements[18]
        };
    }


    if(this.modificator['AHI-changeicon'] && this.modificator['AHI-changeicon'].isEnable) {
        buffer[buffer.length] = {
            position: [xRight, yStart + i],
            element: this.fontMap.canvaseElements[207]
        };
    }

	buffer[buffer.length] = {
		position: [xLeft + 1, yMiddle],
		element: this.fontMap.canvaseElements[62]
	};

	buffer[buffer.length] = {
		position: [xRight - 1, yMiddle],
		element: this.fontMap.canvaseElements[60]
	};

	return buffer;
};

ahiSidebars.prototype.defaultValue = '0';

/**
 *
 * @type {number}
 */
ahiSidebars.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
ahiSidebars.prototype.offsetY = -2;

/* ##################################################### */
/*  CALLSIGN
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var callsign = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
callsign.prototype = new BaseSettings();
callsign.prototype.constructor = callsign;

/**
 *
 * @param value
 * @returns {Array}
 */
callsign.prototype.get = function (value) {

    var buffer = [];

    if(BaseSettings.profile && BaseSettings.profile[17] == 0){
    	return buffer;
    }

	if(BaseSettings.profile && BaseSettings.profile[17] == 3){
        buffer[buffer.length] = {
            position: [0, 0],
            element: this.fontMap.canvaseElements[6]
        };

        buffer[buffer.length] = {
            position: [1, 0],
            element: this.fontMap.canvaseElements[7]
        };

        buffer[buffer.length] = {
            position: [2, 0],
            element: this.fontMap.canvaseElements[8]
        };

        buffer[buffer.length] = {
            position: [0, 1],
            element: this.fontMap.canvaseElements[9]
        };

        buffer[buffer.length] = {
            position: [1, 1],
            element: this.fontMap.canvaseElements[10]
        };

        buffer[buffer.length] = {
            position: [2, 1],
            element: this.fontMap.canvaseElements[11]
        };

        return buffer;
	}


    if(BaseSettings.profile &&  BaseSettings.profile[46] > 0){
        this.defaultValue = '';
    	for(var i = 0; i < 10; i++){
            this.defaultValue += String.fromCharCode(BaseSettings.profile[46 + i]);
		}
    }else{
        this.defaultValue = "CALL SIGN";
	}

	value = value || this.defaultValue;

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}

		//alpha
		if (value[i].match(/[a-zA-Z]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseAlpha(value[i])
			};
		}

		if (value[i].match(/\./)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.fontMap.canvaseElements[this.point]
			};

		}

        if (value[i].match(/ /)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.fontMap.canvaseElements[0]
            };

        }
	}

	return buffer;
};

callsign.prototype.defaultValue = "CALL SIGN";

/**
 *
 * @type {number}
 */
callsign.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
callsign.prototype.offsetY = 0;

/* ##################################################### */
/*  GYMBAL
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var batteryStatus = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
batteryStatus.prototype = new BaseSettings();
batteryStatus.prototype.constructor = batteryStatus;

/**
 *
 * @param value
 * @returns {Array}
 */
batteryStatus.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

	var x = 0;

	buffer[buffer.length] = {
		position: [x++, 0],
		element: this.fontMap.canvaseElements[151]
	};

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [x++, 0],
				element: this.parseDigit(value[i])
			};
		}
	}

	buffer[buffer.length] = {
		position: [x, 0],
		element: this.fontMap.canvaseElements[BaseSettings.prototype.percent]
	};




	return buffer;
};

batteryStatus.prototype.defaultValue = true;

/**
 *
 * @type {number}
 */
batteryStatus.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
batteryStatus.prototype.offsetY = 0;

batteryStatus.prototype.defaultValue = "67%";

/* ##################################################### */
/*  MODE
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var mode = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
mode.prototype = new BaseSettings();
mode.prototype.constructor = mode;

/**
 *
 * @param value
 * @returns {Array}
 */
mode.prototype.get = function (value) {

	var buffer = [];

	value = value || this.defaultValue;

	if(this.infoData && this.infoData[0] && (this.infoData[0] == 14 || this.infoData[0] == 15)){
        for (var i = 0; i < value.length; i++) {
            //alpha
            if (value[i].match(/[a-zA-Z]/)) {
                buffer[buffer.length] = {
                    position: [buffer.length, 0],
                    element: this.parseAlpha(value[i])
                };
            }
        }
	}else{
  /*
        buffer[buffer.length] = {
            position: [0, 0],
            element: this.fontMap.canvaseElements[174]
        };

        buffer[buffer.length] = {
            position: [1, 0],
            element: this.fontMap.canvaseElements[175]
        };
    */ 
        buffer[buffer.length] = {
            position: [0, 0],
            element: this.fontMap.canvaseElements[83]
        };

        buffer[buffer.length] = {
            position: [1, 0],
            element: this.fontMap.canvaseElements[84]
        };
     
        buffer[buffer.length] = {
            position: [2, 0],
            element: this.fontMap.canvaseElements[65]
        };

        buffer[buffer.length] = {
            position: [3, 0],
            element: this.fontMap.canvaseElements[66]
        };
	}




	return buffer;
};

mode.prototype.defaultValue = 'ACRO';

/**
 *
 * @type {number}
 */
mode.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
mode.prototype.offsetY = 0;


/* ##################################################### */
/*  GPS TIME
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var gpsTime = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
gpsTime.prototype = new BaseSettings();
gpsTime.prototype.constructor = gpsTime;

/**
 *
 * @param value
 * @returns {Array}
 */
gpsTime.prototype.get = function (value) {


	var buffer = [];
	value = value || this.defaultValue;

	var x = 0;
	var y = 0;
	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [x++, y],
				element: this.parseDigit(value[i])
			};
		}

		//alpha
		if (value[i].match(/[a-zA-Z]/)) {
			buffer[buffer.length] = {
				position: [x++, y],
				element: this.parseAlpha(value[i])
			};
		}

		if (value[i].match(/\./)) {
			buffer[buffer.length] = {
				position: [x++, y],
				element: this.fontMap.canvaseElements[this.point]
			};

		}

		if (value[i].match(/:/)) {
			buffer[buffer.length] = {
				position: [x++, y],
				element: this.fontMap.canvaseElements[58]
			};
		}

        if (value[i].match(/\//)) {
            buffer[buffer.length] = {
                position: [x++, y],
                element: this.fontMap.canvaseElements[47]
            };
        }

        if (value[i].match(/\*/)) {
            x = 0;
            y++;
        }
	}


    for (; y < 3; y++) {
        for (var i = 0; i < x; i++) {
			buffer[buffer.length] = {
				position: [i, y],
				element: this.fontMap.canvaseElements[0]
			};
        }
    }

	return buffer;
};

gpsTime.prototype.defaultValue = "21:27:35*01/01/01";

/**
 *
 * @type {number}
 */
gpsTime.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
gpsTime.prototype.offsetY = 0;

/* ##################################################### */
/*  MAP MODE
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var mapMode = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
mapMode.prototype = new BaseSettings();
mapMode.prototype.constructor = mapMode;

/**
 *
 * @param value
 * @returns {Array}
 */
mapMode.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

	buffer[buffer.length] = {
		position: [0, 0],
		element: this.fontMap.canvaseElements[34]
	};

	return buffer;
};

mapMode.prototype.defaultValue = true;

/**
 *
 * @type {number}
 */
mapMode.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
mapMode.prototype.offsetY = 0;

/* ##################################################### */
/*  MAP CENTER
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var mapCenter = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
mapCenter.prototype = new BaseSettings();
mapCenter.prototype.constructor = mapCenter;

/**
 *
 * @param value
 * @returns {Array}
 */
mapCenter.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

	buffer[buffer.length] = {
		position: [0, 0],
		element: this.fontMap.canvaseElements[5]
	};

	buffer[buffer.length] = {
		position: [0, -3],
		element: this.fontMap.canvaseElements[215]
	};

	return buffer;
};

mapCenter.prototype.defaultValue = true;

/**
 *
 * @type {number}
 */
mapCenter.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
mapCenter.prototype.offsetY = 0;

/* ##################################################### */
/*  AP STATUS
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var apStAtus = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
apStAtus.prototype = new BaseSettings();
apStAtus.prototype.constructor = apStAtus;

/**
 *
 * @param value
 * @returns {Array}
 */
apStAtus.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}

		//alpha
		if (value[i].match(/[a-zA-Z]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseAlpha(value[i])
			};
		}

		if (value[i].match(/\./)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.fontMap.canvaseElements[this.point]
			};

		}

		if (value[i].match(/ /)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.fontMap.canvaseElements[0]
			};

		}

		if (value[i].match(/:/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.fontMap.canvaseElements[58]
			};

		}
	}

	return buffer;
};

apStAtus.prototype.defaultValue = "AUTO RTH";

/**
 *
 * @type {number}
 */
apStAtus.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
apStAtus.prototype.offsetY = 0;

/* ##################################################### */
/*  WATS
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var wats = function (fontMap) {
    this.fontMap = fontMap;
};

//extends class
wats.prototype = new BaseSettings();
wats.prototype.constructor = wats;

/**
 *
 * @param value
 * @returns {Array}
 */
wats.prototype.get = function (value) {

    var buffer = [];
    value = value || this.defaultValue;

    buffer[buffer.length] = {
        position: [buffer.length, 0],
        element: this.fontMap.canvaseElements[252]
    };

    for (var i = 0; i < value.length; i++) {
        //digit
        if (value[i].match(/[0-9]/)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.parseDigit(value[i])
            };
        }

        //alpha
        if (value[i].match(/[a-zA-Z]/)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.parseAlpha(value[i])
            };
        }

        if (value[i].match(/\./)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.fontMap.canvaseElements[this.point]
            };

        }

        if (value[i].match(/ /)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.fontMap.canvaseElements[0]
            };

        }

        if (value[i].match(/:/)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.fontMap.canvaseElements[58]
            };

        }
    }

    buffer[buffer.length] = {
        position: [buffer.length, 0],
        element: this.fontMap.canvaseElements[123]
    };

    return buffer;
};

wats.prototype.defaultValue = "125";

/**
 *
 * @type {number}
 */
wats.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
wats.prototype.offsetY = 0;




/* ##################################################### */
/*  Climbrate
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var Climbrate = function (fontMap) {
    this.fontMap = fontMap;
};

//extends class
Climbrate.prototype = new BaseSettings();
Climbrate.prototype.constructor = Climbrate;

/**
 *
 * @param value
 * @returns {Array}
 */
Climbrate.prototype.get = function (value) {

    var buffer = [];
    value = value || this.defaultValue;

    buffer[buffer.length] = {
        position: [0, 0],
        element: this.fontMap.canvaseElements[248]
    };

    for (var i = 0; i < value.length; i++) {
        //digit
        if (value[i].match(/[0-9]/)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.parseDigit(value[i])
            };
        }

        //alpha
        if (value[i].match(/[a-zA-Z]/)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.parseAlpha(value[i])
            };
        }

        if (value[i].match(/\./)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.fontMap.canvaseElements[this.point]
            };

        }

        if (value[i].match(/ /)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.fontMap.canvaseElements[0]
            };

        }

        if (value[i].match(/:/)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.fontMap.canvaseElements[58]
            };

        }
    }

    var unit = BaseSettings.profile[25] == 1 ? 153 : 159;
    buffer[buffer.length] = {
        position: [buffer.length, 0],
        element: this.fontMap.canvaseElements[unit]
    };

    return buffer;
};

Climbrate.prototype.defaultValue = '0';

/**
 *
 * @type {number}
 */
Climbrate.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
Climbrate.prototype.offsetY = 0;




/* ##################################################### */
/*  Efficiency
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var Efficiency = function (fontMap) {
    this.fontMap = fontMap;
};

//extends class
Efficiency.prototype = new BaseSettings();
Efficiency.prototype.constructor = Efficiency;

/**
 *
 * @param value
 * @returns {Array}
 */
Efficiency.prototype.get = function (value) {

    var buffer = [];
    value = value || this.defaultValue;

    buffer[buffer.length] = {
        position: [0, 0],
        element: this.fontMap.canvaseElements[249]
    };

    for (var i = 0; i < value.length; i++) {
        //digit
        if (value[i].match(/[0-9]/)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.parseDigit(value[i])
            };
        }

        //alpha
        if (value[i].match(/[a-zA-Z]/)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.parseAlpha(value[i])
            };
        }

        if (value[i].match(/\./)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.fontMap.canvaseElements[this.point]
            };

        }

        if (value[i].match(/ /)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.fontMap.canvaseElements[0]
            };

        }

        if (value[i].match(/:/)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.fontMap.canvaseElements[58]
            };

        }
    }
    return buffer;
};

Efficiency.prototype.defaultValue = "20";

/**
 *
 * @type {number}
 */
Efficiency.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
Efficiency.prototype.offsetY = 0;


/* ##################################################### */
/*  Avgefficiency
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var Avgefficiency = function (fontMap) {
    this.fontMap = fontMap;
};

//extends class
Avgefficiency.prototype = new BaseSettings();
Avgefficiency.prototype.constructor = Avgefficiency;

/**
 *
 * @param value
 * @returns {Array}
 */
Avgefficiency.prototype.get = function (value) {

    var buffer = [];
    value = value || this.defaultValue;

    buffer[buffer.length] = {
        position: [0, 0],
        element: this.fontMap.canvaseElements[253]
    };

    for (var i = 0; i < value.length; i++) {
        //digit
        if (value[i].match(/[0-9]/)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.parseDigit(value[i])
            };
        }

        //alpha
        if (value[i].match(/[a-zA-Z]/)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.parseAlpha(value[i])
            };
        }

        if (value[i].match(/\./)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.fontMap.canvaseElements[this.point]
            };

        }

        if (value[i].match(/ /)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.fontMap.canvaseElements[0]
            };

        }

        if (value[i].match(/:/)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.fontMap.canvaseElements[58]
            };

        }
    }

    return buffer;
};

Avgefficiency.prototype.defaultValue = "575";

/**
 *
 * @type {number}
 */
Avgefficiency.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
Avgefficiency.prototype.offsetY = 0;



/* ##################################################### */
/*  AIR_speed
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var AIR_speed = function (fontMap) {
    this.fontMap = fontMap;
};

//extends class
AIR_speed.prototype = new BaseSettings();
AIR_speed.prototype.constructor = AIR_speed;

/**
 *
 * @param value
 * @returns {Array}
 */
AIR_speed.prototype.get = function (value) {

    var buffer = [];
    value = value || this.defaultValue;

    buffer[buffer.length] = {
        position: [0, 0],
        element: this.fontMap.canvaseElements[246]
    };

    for (var i = 0; i < value.length; i++) {
        //digit
        if (value[i].match(/[0-9]/)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.parseDigit(value[i])
            };
        }

        //alpha
        if (value[i].match(/[a-zA-Z]/)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.parseAlpha(value[i])
            };
        }

        if (value[i].match(/\./)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.fontMap.canvaseElements[this.point]
            };

        }

        if (value[i].match(/ /)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.fontMap.canvaseElements[0]
            };

        }

        if (value[i].match(/:/)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.fontMap.canvaseElements[58]
            };

        }
    }

    var unit = BaseSettings.profile[25] == 1 ? 166 : 165;
    buffer[buffer.length] = {
        position: [buffer.length, 0],
        element: this.fontMap.canvaseElements[unit]
    };

    return buffer;
};

AIR_speed.prototype.defaultValue = "0";

/**
 *
 * @type {number}
 */
AIR_speed.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
AIR_speed.prototype.offsetY = 0;



/* ##################################################### */
/*  MAX_speed
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var MAX_speed = function (fontMap) {
    this.fontMap = fontMap;
};

//extends class
MAX_speed.prototype = new BaseSettings();
MAX_speed.prototype.constructor = MAX_speed;

/**
 *
 * @param value
 * @returns {Array}
 */
MAX_speed.prototype.get = function (value) {

    var buffer = [];
    value = value || this.defaultValue;

    buffer[buffer.length] = {
        position: [0, 0],
        element: this.fontMap.canvaseElements[247]
    };

    for (var i = 0; i < value.length; i++) {
        //digit
        if (value[i].match(/[0-9]/)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.parseDigit(value[i])
            };
        }
    }

    var unit = BaseSettings.profile[25] == 1 ? 166 : 165;
    buffer[buffer.length] = {
        position: [buffer.length, 0],
        element: this.fontMap.canvaseElements[unit]
    };

    return buffer;
};

MAX_speed.prototype.defaultValue = "0";

/**
 *
 * @type {number}
 */
MAX_speed.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
MAX_speed.prototype.offsetY = 0;


/* ##################################################### */
/*  TotalDistance
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var TotalDistance = function (fontMap) {
    this.fontMap = fontMap;
};

//extends class
TotalDistance.prototype = new BaseSettings();
TotalDistance.prototype.constructor = TotalDistance;

/**
 *
 * @param value
 * @returns {Array}
 */
TotalDistance.prototype.get = function (value) {

    var buffer = [];
    value = value || this.defaultValue;

    buffer[buffer.length] = {
        position: [0, 0],
        element: this.fontMap.canvaseElements[254]
    };

    for (var i = 0; i < value.length; i++) {
        //digit
        if (value[i].match(/[0-9]/)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.parseDigit(value[i])
            };
        }
    }

    var unit = BaseSettings.profile[25] == 1 ? 13 : 12;
    buffer[buffer.length] = {
        position: [buffer.length, 0],
        element: this.fontMap.canvaseElements[unit]
    };

    return buffer;
};

TotalDistance.prototype.defaultValue = "0";

/**
 *
 * @type {number}
 */
TotalDistance.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
TotalDistance.prototype.offsetY = 0;


/* ##################################################### */
/*  WIND_speed
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var WIND_speed = function (fontMap) {
    this.fontMap = fontMap;
};

//extends class
WIND_speed.prototype = new BaseSettings();
WIND_speed.prototype.constructor = WIND_speed;

/**
 *
 * @param value
 * @returns {Array}
 */
WIND_speed.prototype.get = function (value) {

    var buffer = [];
    value = value || this.defaultValue;

    buffer[buffer.length] = {
        position: [0, 0],
        element: this.fontMap.canvaseElements[232]
    };
    buffer[buffer.length] = {
        position: [1, 0],
        element: this.fontMap.canvaseElements[48]
    };
    buffer[buffer.length] = {
        position: [2, 0],
        element: this.fontMap.canvaseElements[165]
    };

    /*for (var i = 0; i < value.length; i++) {
        //digit
        if (value[i].match(/[0-9]/)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.parseDigit(value[i])
            };
        }
    }*/

   /* buffer[buffer.length] = {
        position: [buffer.length, 0],
        element: this.fontMap.canvaseElements[12]
    };*/

    return buffer;
};

WIND_speed.prototype.defaultValue = "";

/**
 *
 * @type {number}
 */
WIND_speed.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
WIND_speed.prototype.offsetY = 0;




/* ##################################################### */
/*  MaxDistance
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var MaxDistance = function (fontMap) {
    this.fontMap = fontMap;
};

//extends class
MaxDistance.prototype = new BaseSettings();
MaxDistance.prototype.constructor = MaxDistance;

/**
 *
 * @param value
 * @returns {Array}
 */
MaxDistance.prototype.get = function (value) {

    var buffer = [];
    value = value || this.defaultValue;

    buffer[buffer.length] = {
        position: [0, 0],
        element: this.fontMap.canvaseElements[247]
    };

    for (var i = 0; i < value.length; i++) {
        //digit
        if (value[i].match(/[0-9]/)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.parseDigit(value[i])
            };
        }
    }

    var unit = BaseSettings.profile[25] == 1 ? 13 : 12;
    buffer[buffer.length] = {
        position: [buffer.length, 0],
        element: this.fontMap.canvaseElements[unit]
    };

    return buffer;
};

MaxDistance.prototype.defaultValue = "350";

/**
 *
 * @type {number}
 */
MaxDistance.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
MaxDistance.prototype.offsetY = 0;



/* ##################################################### */
/*  DOP
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var DOP = function (fontMap) {
    this.fontMap = fontMap;
};

//extends class
DOP.prototype = new BaseSettings();
DOP.prototype.constructor = DOP;

/**
 *
 * @param value
 * @returns {Array}
 */
DOP.prototype.get = function (value) {

    var buffer = [];
    value = value || this.defaultValue;

    buffer[buffer.length] = {
        position: [0, 0],
        element: this.fontMap.canvaseElements[244]
    };

    for (var i = 0; i < value.length; i++) {
        //digit
        if (value[i].match(/[0-9]/)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.parseDigit(value[i])
            };
        }

        if (value[i].match(/\./)) {
            buffer[buffer.length] = {
                position: [buffer.length, 0],
                element: this.fontMap.canvaseElements[this.point]
            };

        }
    }

    return buffer;
};

DOP.prototype.defaultValue = "9.9";

/**
 *
 * @type {number}
 */
DOP.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
DOP.prototype.offsetY = 0;


/* ##################################################### */
/*  Gliderscope
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var gliderscope = function (fontMap) {
    this.fontMap = fontMap;
};

//extends class
gliderscope.prototype = new BaseSettings();
gliderscope.prototype.constructor = MaxDistance;

/**
 *
 * @param value
 * @returns {Array}
 */
gliderscope.prototype.get = function (value) {

    var buffer = [];
    value = value || this.defaultValue;

	buffer[buffer.length] = {
		position: [0, buffer.length],
		element: this.fontMap.canvaseElements[222]
	};

	buffer[buffer.length] = {
		position: [0, buffer.length],
		element: this.fontMap.canvaseElements[220]
	};

	buffer[buffer.length] = {
		position: [0, buffer.length],
		element: this.fontMap.canvaseElements[220]
	};

    return buffer;
};

gliderscope.prototype.defaultValue = "";

/**
 *
 * @type {number}
 */
gliderscope.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
gliderscope.prototype.offsetY = -1;

/* ##################################################### */
/*  ADSB
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var ADSB = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
ADSB.prototype = new BaseSettings();
ADSB.prototype.constructor = ADSB;

/**
 *
 * @param value
 * @returns {Array}
 */
ADSB.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

	buffer[buffer.length] = {
		position: [0, 0],
		element: this.fontMap.canvaseElements[127]
	};

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}

		if (value[i].match(/\./)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.fontMap.canvaseElements[this.point]
			};
		}

		if (value[i].match(/\^/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.fontMap.canvaseElements[this.exponent]
			};
		}
	}

	return buffer;
};

ADSB.prototype.defaultValue = "6.3^1.1";

/**
 *
 * @type {number}
 */
ADSB.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
ADSB.prototype.offsetY = 0;


/* ##################################################### */
/*  VTX
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var VTX = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
VTX.prototype = new BaseSettings();
VTX.prototype.constructor = VTX;

/**
 *
 * @param value
 * @returns {Array}
 */
VTX.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}

		if (value[i].match(/\./)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.fontMap.canvaseElements[this.point]
			};
		}

		if (value[i].match(/\:/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.fontMap.canvaseElements[this.colon]
			};
		}

		//alpha
		if (value[i].match(/[a-zA-Z]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseAlpha(value[i])
			};
		}
	}

	return buffer;
};

VTX.prototype.defaultValue = "CH:1P:1";

/**
 *
 * @type {number}
 */
VTX.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
VTX.prototype.offsetY = 0;


/* ##################################################### */
/*  CELL
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var CELL = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
CELL.prototype = new BaseSettings();
CELL.prototype.constructor = CELL;

/**
 *
 * @param value
 * @returns {Array}
 */
CELL.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

	if(BaseSettings.profile[27] == 1){
		buffer[buffer.length] = {
			position: [0, 0],
			element: this.fontMap.canvaseElements[146]
		};
	}else{
		buffer[buffer.length] = {
			position: [0, 0],
			element: this.fontMap.canvaseElements[151]
		};
	}

	for (var i = 0; i < value.length; i++) {
		//digit
		if (value[i].match(/[0-9]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseDigit(value[i])
			};
		}

		if (value[i].match(/\./)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.fontMap.canvaseElements[this.point]
			};
		}
	}

	return buffer;
};

CELL.prototype.defaultValue = "3.7";

/**
 *
 * @type {number}
 */
CELL.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
CELL.prototype.offsetY = 0;


/* ##################################################### */
/*  PID
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var PID = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
PID.prototype = new BaseSettings();
PID.prototype.constructor = PID;

/**
 *
 * @param value
 * @returns {Array}
 */
PID.prototype.get = function (value) {

	var buffer = [];
	value = this.defaultValue;

	var line = 0;
	var row = 0;
	for (var i = 0; i < value.length; i++) {
		for (var ii = 0; ii < value[i].length; ii++) {
			if (value[i][ii].match(/[a-zA-Z]/)) {
				buffer[buffer.length] = {
					position: [row++, line],
					element: this.parseAlpha(value[i][ii])
				};
			}

			if (value[i][ii].match(/ /)) {
				buffer[buffer.length] = {
					position: [row++, line],
					element: this.fontMap.canvaseElements[this.space]
				};
			}

			if (value[i][ii].match(/[0-9]/)) {
				buffer[buffer.length] = {
					position: [row++, line],
					element: this.parseDigit(value[i][ii])
				};
			}

		}
		line++;
		row = 0
	}

	return buffer;
}

PID.prototype.defaultValue = ["R 100 101 102", "P 110 111 112", "Y 120 121 122"];

/**
 *
 * @type {number}
 */
PID.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
PID.prototype.offsetY = 0;

/* ##################################################### */
/*  CUSTOM
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var CUSTOM = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
CUSTOM.prototype = new BaseSettings();
CUSTOM.prototype.constructor = CUSTOM;

/**
 *
 * @param value
 * @returns {Array}
 */
CUSTOM.prototype.get = function (value) {

	var buffer = [];
	value = value || this.defaultValue;

	for (var i = 0; i < value.length; i++) {
		if (value[i].match(/[a-zA-Z]/)) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.parseAlpha(value[i])
			};
		}
	}

	return buffer;
};

CUSTOM.prototype.defaultValue = "CUST";

/**
 *
 * @type {number}
 */
CUSTOM.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
CUSTOM.prototype.offsetY = 0;

/* ##################################################### */
/*  ATT
 /* ##################################################### */
/**
 *
 * @param fontMap
 */
var AAT = function (fontMap) {
	this.fontMap = fontMap;
};

//extends class
AAT.prototype = new BaseSettings();
AAT.prototype.constructor = AAT;
AAT.prototype.canMove = false;

/**
 *
 * @param value
 * @returns {Array}
 */
AAT.prototype.get = function (value) {
	var buffer = [];
	if(BaseSettings.profile[65] == 1){
		for (var i = 0; i < 32; i++) {
			buffer[buffer.length] = {
				position: [buffer.length, 0],
				element: this.fontMap.canvaseElements[194 + (i % 2)]
			};
		}
	}

	return buffer;
};

AAT.prototype.defaultValue = "";

/**
 *
 * @type {number}
 */
AAT.prototype.offsetX = 0;

/**
 *
 * @type {number}
 */
AAT.prototype.offsetY = 0;









