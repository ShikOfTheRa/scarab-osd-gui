TranslateNull = function(){

};

TranslateNull.prototype.frameValueToForm = function(value){
    return value;
};

TranslateNull.prototype.formValueToFrame = function(value){
    return value;
};

TranslateSignedInt = function(){

};

TranslateSignedInt.prototype.frameValueToForm = function(value){
    return value - 128;
};

TranslateSignedInt.prototype.formValueToFrame = function(value){
    return value + 128;
};


Array.range = function(n) {
	return Array.apply(null,Array(n)).map(function(x,i) { return i})
};

Object.defineProperty(Array.prototype, 'chunk', {
	value: function(n) {
		var _this = this;
		return Array.range(Math.ceil(_this.length/n)).map(function(x,i){ return _this.slice(i*n,i*n+n)});
	}
});


$(document).ready(function () {

    var service = analytics.getService('mwosd_app');
	tracker = service.getTracker('UA-54508077-3');

	mainApp = new MainApp();
	mainApp.run();
});
