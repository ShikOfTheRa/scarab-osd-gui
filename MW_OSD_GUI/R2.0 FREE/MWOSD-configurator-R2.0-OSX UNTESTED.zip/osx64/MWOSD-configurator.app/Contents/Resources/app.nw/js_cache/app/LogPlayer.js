LogPlayer = function(protocol) {
    var _this = this;

    this.log = {
        length:         false,
        data:           false,
        actualIndex:    false,
        frameLength:    50,
        repatSpeed:     100 - 50,
        lastSend:       0,
    };

    this.protocol = protocol;
    this.playerTimeout = null;


    this.loadFileFromDiskButton = $('#loadLogFile').button().click(function () {
        _this.openFile()
    });

    this.playLogFile = $('#playLogFile').button().click(function () {
        _this.play()
    });

    this.handleChangeRunStatus = function(isRunning){

    };

    this.pauseLogFile = $('#pauseLogFile').button().click(function () {
        _this.pause()
    });

    this.stopLogFile = $('#stopLogFile').button().click(function () {
        _this.stop()
    });

    this.slider = $( "#logSlider" ).slider({
            change: function( event, ui ) {
                _this.log.frameLength   = ui.value;
                _this.log.repatSpeed    = 100 - ui.value;

                _this.drawSpeedState();
            },
            value: 50,
            min: 1,
        }
    );

    this.log_info           =  $('#log_info');
    this.log_info_speed     = $('#log_info_speed');
    this.mode = 'stop';

    this.drawSpeedState();

    this.log_progressbar =  $('#log_progressbar').progressbar({
        value: 0
    }).addClass('progress progress_play');

    /**
     *
     * @param index
     * @returns {*}
     */
    this.getFrameByIndex = function(){
        if(_this.log.length <= _this.log.actualIndex){
            return false;
        }

        var frame =  _this.log.data.slice(_this.log.actualIndex, (_this.log.actualIndex + _this.log.frameLength));
        _this.log.actualIndex = _this.log.actualIndex + _this.log.frameLength;
        return frame;
    };

    /**
     *
     */
    this.handleDataWasSent = function(){
        if(_this.mode == 'play'){
            if(_this.microtime() > _this.log.lastSend + _this.log.repatSpeed){
                _this.drawSpeedState();
                _this._oneTick();
            }else{
                clearTimeout(_this.playerTimeout);
                _this.playerTimeout = setTimeout(function(){
                    _this.drawSpeedState();
                    _this._oneTick();
                }, Math.round(_this.log.lastSend + _this.log.repatSpeed) - _this.microtime())
            }


        }
    };

    this.playLogFile.button( {disabled : true });
    this.pauseLogFile.button( {disabled: true });
    this.stopLogFile.button( {disabled: true });
};

LogPlayer.prototype.openFile = function(){
    var _this = this;
    chrome.fileSystem.chooseEntry(
        {
            type: 'openFile', accepts: [{
                extensions: ['tlog', 'ubx', 'txt']
            }]
        },
        function (fileEntry) {
            if (chrome.runtime.lastError || !fileEntry) {
                console.log("User did not choose a file");
                return;
            }

            fileEntry.file(function (file) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    _this.log.length        = e.target.result.byteLength;
                    _this.log.data          = e.target.result;
                    _this.log.actualIndex   = 0;

                    _this.drawFrameState();

                    _this.playLogFile.button( {disabled: false });
                    _this.pauseLogFile.button( {disabled: true });
                    _this.stopLogFile.button( {disabled: true });
                };

                reader.readAsArrayBuffer(file);
            });
        }
    );
};

/**
 *
 */
LogPlayer.prototype.play = function(){
    if(!this.log.data)
    {
        return;
    }

    this.playLogFile.button( {disabled: true });
    this.pauseLogFile.button( {disabled: false });
    this.stopLogFile.button( {disabled: false });

    this.handleChangeRunStatus(true);
    this.mode = "play";

    this._oneTick();
};

/**
 *
 * @private
 */
LogPlayer.prototype._oneTick = function(){
    clearTimeout(this.playerTimeout);
    var frame = this.getFrameByIndex();
    if(frame) {
        this.drawFrameState();
        this.log.lastSend = this.microtime();
        this.protocol.sendDirect(frame, this.handleDataWasSent);
    }else{
        this.stop();
    }
};

/**
 *
 */
LogPlayer.prototype.pause = function(){
    this.playLogFile.button( {disabled: false });
    this.pauseLogFile.button( {disabled: true });
    this.stopLogFile.button( {disabled: false });
    this.handleChangeRunStatus(false);
    this.mode = "pause";
};

/**
 *
 */
LogPlayer.prototype.stop = function(){
    clearTimeout(this.playerTimeout);
    this.playerInterval = null;
    this.playLogFile.button( {disabled: false });
    this.pauseLogFile.button( {disabled: true });
    this.stopLogFile.button( {disabled: true });

    this.mode = "stop";
    this.handleChangeRunStatus(false);
    this.log.actualIndex = 0;
    this.log.lastSend = 0;
    this.drawFrameState();
};

/**
 *
 */
LogPlayer.prototype.drawFrameState = function(){
    if(this.log.data){
        this.log_info.html( "Frames: " + Math.round(this.log.actualIndex / 1000));

        this.log_progressbar.progressbar(
            {
                value : Math.round((100 / this.log.length) * this.log.actualIndex)
            }
        );
    }

};

/**
 *
 */
LogPlayer.prototype.drawSpeedState = function(){
    this.log_info_speed.html( "Bytes: " + this.log.frameLength + "<br />Speed: " + this.log.repatSpeed + " ms" + "<br />Real Speed: " + (this.mode =="play" ? (this.microtime() - this.log.lastSend) : 0) + " ms");
};

/**
 *
 */
LogPlayer.prototype.reseLogAll = function () {
    clearInterval(this.playerTimeout);
    this.playLogFile.button( {disabled: true });
    this.pauseLogFile.button( {disabled: true });
    this.stopLogFile.button( {disabled: true });
    this.playerTimeout = null;

    this.log.length = false;
    this.log.data = false;
    this.log.actualIndex = 0;

    this.log_info.html("");

    this.log_progressbar.progressbar(
        {
            value : 0
        }
    );
};

/**
 *
 * @returns {string}
 */
LogPlayer.prototype.microtime = function () {
    if (typeof performance !== 'undefined' && performance.now) {
        return Math.round(performance.now() + performance.timing.navigationStart);
    } else {
        return Math.round(Date.now ? Date.now() : new Date().getTime());
    }
};







