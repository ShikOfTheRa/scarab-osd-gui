
var DefaultV18 = '[{"index":0,"values":{"command":9,"values":{"0":18,"1":1,"2":0,"3":0,"4":34,"5":0,"6":8,"7":0,"8":0,"9":4},"specialValues":{}}},{"index":10,"values":{"command":9,"values":{"10":200,"11":0,"12":3,"13":0,"14":0,"15":1,"16":1,"17":1,"18":200,"19":0},"specialValues":{}}},{"index":20,"values":{"command":9,"values":{"20":50,"21":100,"22":2,"23":0,"24":2,"25":0,"26":2,"27":1,"28":0,"29":1},"specialValues":{}}},{"index":30,"values":{"command":9,"values":{"30":0,"31":7,"32":1,"33":0,"34":128,"35":0,"36":0,"37":0,"38":0,"39":8},"specialValues":{}}},{"index":40,"values":{"command":9,"values":{"40":0,"41":0,"42":0,"43":30,"44":30,"45":20,"46":77,"47":87,"48":79,"49":83},"specialValues":{}}},{"index":50,"values":{"command":9,"values":{"50":68,"51":0,"52":32,"53":32,"54":32,"55":32,"56":0,"57":0,"58":10,"59":0},"specialValues":{}}},{"index":60,"values":{"command":9,"values":{"60":1,"61":6,"62":0,"63":0,"64":1,"65":0,"66":0,"67":3,"68":0,"69":0},"specialValues":{}}},{"index":70,"values":{"command":9,"values":{"70":0,"71":150,"72":0,"73":0,"74":0,"75":255,"76":3,"77":0,"78":0,"79":163},"specialValues":{}}},{"index":80,"values":{"command":9,"values":{"80":3,"81":32,"82":192,"83":50,"84":192,"85":52,"86":192,"87":182,"88":192,"89":143},"specialValues":{}}},{"index":90,"values":{"command":9,"values":{"90":0,"91":173,"92":0,"93":36,"94":192,"95":113,"96":0,"97":40,"98":192,"99":203},"specialValues":{}}},{"index":100,"values":{"command":9,"values":{"100":192,"101":202,"102":192,"103":96,"104":193,"105":66,"106":1,"107":126,"108":193,"109":55},"specialValues":{}}},{"index":110,"values":{"command":9,"values":{"110":193,"111":36,"112":1,"113":66,"114":1,"115":2,"116":192,"117":15,"118":192,"119":76},"specialValues":{}}},{"index":120,"values":{"command":9,"values":{"120":193,"121":7,"122":1,"123":106,"124":193,"125":46,"126":1,"127":113,"128":193,"129":120},"specialValues":{}}},{"index":130,"values":{"command":9,"values":{"130":193,"131":194,"132":192,"133":187,"134":192,"135":187,"136":0,"137":3,"138":0,"139":7},"specialValues":{}}},{"index":140,"values":{"command":9,"values":{"140":0,"141":92,"142":0,"143":251,"144":0,"145":6,"146":1,"147":62,"148":192,"149":52},"specialValues":{}}},{"index":150,"values":{"command":9,"values":{"150":0,"151":195,"152":0,"153":100,"154":192,"155":16,"156":1,"157":186,"158":192,"159":86},"specialValues":{}}},{"index":160,"values":{"command":9,"values":{"160":1,"161":220,"162":0,"163":233,"164":0,"165":242,"166":0,"167":212,"168":0,"169":152},"specialValues":{}}},{"index":170,"values":{"command":9,"values":{"170":0,"171":128,"172":0,"173":218,"174":0,"175":82,"176":0,"177":158,"178":0,"179":122},"specialValues":{}}},{"index":180,"values":{"command":9,"values":{"180":0,"181":70,"182":0,"183":100,"184":0,"185":92,"186":0,"187":130,"188":0,"189":75},"specialValues":{}}},{"index":190,"values":{"command":9,"values":{"190":0,"191":32,"192":192,"193":50,"194":192,"195":52,"196":192,"197":182,"198":192,"199":143},"specialValues":{}}},{"index":200,"values":{"command":9,"values":{"200":0,"201":173,"202":0,"203":36,"204":192,"205":113,"206":0,"207":40,"208":192,"209":203},"specialValues":{}}},{"index":210,"values":{"command":9,"values":{"210":192,"211":202,"212":192,"213":96,"214":193,"215":66,"216":1,"217":126,"218":193,"219":55},"specialValues":{}}},{"index":220,"values":{"command":9,"values":{"220":193,"221":36,"222":1,"223":66,"224":1,"225":2,"226":192,"227":15,"228":192,"229":76},"specialValues":{}}},{"index":230,"values":{"command":9,"values":{"230":193,"231":7,"232":1,"233":106,"234":193,"235":46,"236":1,"237":113,"238":193,"239":120},"specialValues":{}}},{"index":240,"values":{"command":9,"values":{"240":193,"241":194,"242":192,"243":187,"244":192,"245":187,"246":0,"247":3,"248":0,"249":7},"specialValues":{}}},{"index":250,"values":{"command":9,"values":{"250":0,"251":92,"252":0,"253":251,"254":0,"255":6,"256":1,"257":62,"258":192,"259":52},"specialValues":{}}},{"index":260,"values":{"command":9,"values":{"260":0,"261":195,"262":0,"263":100,"264":192,"265":16,"266":1,"267":186,"268":192,"269":86},"specialValues":{}}},{"index":270,"values":{"command":9,"values":{"270":1,"271":220,"272":0,"273":233,"274":0,"275":242,"276":0,"277":212,"278":0,"279":152},"specialValues":{}}},{"index":280,"values":{"command":9,"values":{"280":0,"281":128,"282":0,"283":218,"284":0,"285":82,"286":0,"287":158,"288":0,"289":122},"specialValues":{}}},{"index":290,"values":{"command":9,"values":{"290":0,"291":70,"292":0,"293":100,"294":0,"295":92,"296":0,"297":130,"298":0,"299":75},"specialValues":{}}},{"index":300,"values":{"command":9,"values":{"300":0,"301":32,"302":192,"303":50,"304":192,"305":52,"306":192,"307":182,"308":192,"309":143},"specialValues":{}}},{"index":310,"values":{"command":9,"values":{"310":0,"311":173,"312":0,"313":36,"314":192,"315":113,"316":0,"317":40,"318":192,"319":203},"specialValues":{}}},{"index":320,"values":{"command":9,"values":{"320":192,"321":202,"322":192,"323":96,"324":193,"325":66,"326":1,"327":126,"328":193,"329":55},"specialValues":{}}},{"index":330,"values":{"command":9,"values":{"330":193,"331":36,"332":1,"333":66,"334":1,"335":2,"336":192,"337":15,"338":192,"339":76},"specialValues":{}}},{"index":340,"values":{"command":9,"values":{"340":193,"341":7,"342":1,"343":106,"344":193,"345":46,"346":1,"347":113,"348":193,"349":120},"specialValues":{}}},{"index":350,"values":{"command":9,"values":{"350":193,"351":194,"352":192,"353":187,"354":192,"355":187,"356":0,"357":3,"358":0,"359":7},"specialValues":{}}},{"index":360,"values":{"command":9,"values":{"360":0,"361":92,"362":0,"363":251,"364":0,"365":6,"366":1,"367":62,"368":192,"369":52},"specialValues":{}}},{"index":370,"values":{"command":9,"values":{"370":0,"371":195,"372":0,"373":100,"374":192,"375":16,"376":1,"377":186,"378":192,"379":86},"specialValues":{}}},{"index":380,"values":{"command":9,"values":{"380":1,"381":220,"382":0,"383":233,"384":0,"385":242,"386":0,"387":212,"388":0,"389":152},"specialValues":{}}},{"index":390,"values":{"command":9,"values":{"390":0,"391":128,"392":0,"393":218,"394":0,"395":82,"396":0,"397":158,"398":0,"399":122},"specialValues":{}}},{"index":400,"values":{"command":9,"values":{"400":0,"401":70,"402":0,"403":100,"404":0,"405":92,"406":0,"407":130,"408":0,"409":75},"specialValues":{}}},{"index":410,"values":{"command":9,"values":{"410":0,"411":0,"412":0,"413":150,"414":0,"415":0,"416":0,"417":255,"418":3,"419":0},"specialValues":{}}}]'

var layoutAddressV18 = [
    [81, 190], [191, 300], [301, 410]
];



/**
 *
 * @type {*[]}
 */
SettingsElementsV18 = [
    {
        id: 'S_AUTOCELL',
        position: 1,
        description: 'Auto Detect',
        type: SettingsElementsType.select,
        group: [
            SettingsElementsGroup.G_Voltage
//            SettingsElementsGroup.G_Other, //FOR TEST
//            SettingsElementsGroup.G_Alarms,//FOR TEST
//            SettingsElementsGroup.G_Amperage,//FOR TEST
//            SettingsElementsGroup.G_GPS,//FOR TEST
//            SettingsElementsGroup.G_HUD//FOR TEST
        ],
        properties: {
            order: 2,
            values: [
                'Use battery cell count / alarm',
                'Autodetect cell count and cell alarm'
            ]
        }
    },
    {
        id: 'S_VIDVOLTAGEMIN',
        position: 2,
        description: 'Video Voltage Alarm',
        type: SettingsElementsType.range,
        group: [SettingsElementsGroup.G_VVoltage],
        properties: {
            max: 255,
            divider: 10
        }
    },
    {
        id: 'S_RSSI_ALARM',
        position: 3,
        description: 'RSSI Alarm',
        type: SettingsElementsType.range,
        properties: {
            order: 3,
            max: 100,
//			divider: 10,
        },
        group: [SettingsElementsGroup.G_RSSI]
    },
    {
        id: 'S_AUTOCELL_ALARM',
        position: 4,
        description: 'Autodetect cell alarm value',
        type: SettingsElementsType.range,
        properties: {
            max: 255,
            divider: 10,
            order: 3,
        },
        group: [SettingsElementsGroup.G_Voltage]
    },
    {
        id: 'S_MWRSSI',
        position: 5,
        description: 'RSSI source',
        type: SettingsElementsType.select,
        properties: {
            order: 1,
            values: [
                'Direct OSD connect Analog',
                'Direct OSD connect - 50hz PWM',
                'RSSI from Flight Controller',
                'RSSI from RC channel'
            ]
        },
        group: [SettingsElementsGroup.G_RSSI]
    },
    {
        id: 'S_RSSI_CH',
        position: 6,
        description: 'RSSI channel',
        type: SettingsElementsType.select,
        properties: {
            order: 4,
            values: {
                1: "1",
                2: "2",
                3: "3",
                4: "4",
                5: "5",
                6: "6",
                7: "7",
                8: "8",
                9: "9",
                10: "10",
                11: "11",
                12: "12",
                13: "13",
                14: "14",
                15: "15",
                16: "16"
            }
        },
        group: [SettingsElementsGroup.G_RSSI]
    },
    {
        id: 'S_TX_TYPE',
        position: 7,
        description: 'Transmiter type',
        type: SettingsElementsType.select,
        properties: {
            order: 7,
            values: [
                'Roll/Pitch/Yaw/Throttle',
                'Roll/Pitch/Throttle/Yaw',
                'Throttle/Roll/Pitch/Yaw'
            ]},
        group: [
            SettingsElementsGroup.G_GOSD,
            SettingsElementsGroup.G_MAVLINK
        ]
    },
    {
        id: 'S_VOLTAGEMIN',
        position: 8,
        description: 'Voltage Alarm',
        type: SettingsElementsType.range,
        properties: {
            max: 255,
            divider: 10
        },
        group: [SettingsElementsGroup.G_Voltage]
    },
    {
        id: 'S_BATCELLS',
        position: 9,
        description: 'Battery Cell Count',
        type: SettingsElementsType.select,
        properties: {
            order: 6,
            values: {
                1: "1S (3.7V)",
                2: "2S (7.4V)",
                3: "3S (11.1V)",
                4: "4S (14.8V)",
                5: "5S (18.5V)",
                6: "6S (22.2V)",                
            }
        },
        group: [SettingsElementsGroup.G_Voltage]
    },
    {
        id: 'S_DIVIDERRATIO',
        position: 10,
        description: 'Main Voltage Adjust',
        type: SettingsElementsType.range,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_Voltage]
    },
    {
        id: 'S_MAINVOLTAGE_VBAT',
        position: 11,
        description: 'Main Voltage source',
        type: SettingsElementsType.select,
        properties: {
            order: 1,
            values: [
                'Use direct connect voltage',
                'Use Flight Controller voltage'
            ]
        },
        group: [SettingsElementsGroup.G_Voltage]
    },
    {
        id: 'S_SIDEBARHEIGHT',
        position: 12,
        description: 'HUD sidebar height',
        type: SettingsElementsType.select,
        properties: {
            values: {
                3: "3",
                4: "4",
                5: "5",
                6: "6"
            }
        },
        group: [SettingsElementsGroup.G_HUD]
    },
    {
        id: 'S_MWAMPERAGE',
        position: 13,
        description: 'Amperage',
        type: SettingsElementsType.select,
        properties: {
            values: [
                'Use direct connect current sensor',
                'Use Flight Controller amperage',
                'Use Virtual Sensor (throttle)'
            ]
        },
        group: [SettingsElementsGroup.G_Amperage]
    },
    {
        id: 'S_TX_REVERSE',
        position: 14,
        description: 'Transmiter reverse',
        type: SettingsElementsType.select,
        properties: {
             order: 8,
           values: [
                'No reversing',
                'Ch1',
                'Ch2',
                'Ch1, Ch2',
                'Ch3',
                'Ch1, Ch3',
                'Ch2, Ch3',
                'Ch1, Ch2, Ch3',
                'Ch4',
                'Ch1, Ch4',
                'Ch2, Ch4',
                'Ch1, Ch2, Ch4',
                'Ch3, Ch4',
                'Ch1, Ch3, Ch4',
                'Ch2, Ch3, Ch4',
                'Ch1, Ch2, Ch3, Ch4'
            ]
        },
        group: [
            SettingsElementsGroup.G_GOSD,
            SettingsElementsGroup.G_MAVLINK
        ]
    },
    {
        id: 'S_MAV_SYS_ID',
        position: 15,
        description: 'Mavlink System ID',
        type: SettingsElementsType.range,
        properties: {
            order: 1,
            min: 0,
            max: 254
        },
        group: [SettingsElementsGroup.G_MAVLINK]
    },
    {
        id: 'S_ALARMS_TEXT',
        position: 16,
        description: 'Text alarms',
        type: SettingsElementsType.select,
        properties: {
            order: 4,
            values: [
                'Hide text alarms',
                'Show text alarms'
            ]
        },
        group: [SettingsElementsGroup.G_Display]
    },
    {
        id: 'S_CALLSIGN_ALWAYS',
        position: 17,
        description: 'Display callsign',
        type: SettingsElementsType.select,
        properties: {
            values: [
                'Disabled',
                'Show Permanently',
                'Display for 4 seconds every minute',
                'Grafic logo'
            ]
        },
        group: [SettingsElementsGroup.G_CallSign]
    },
    {
        id: 'S_VIDDIVIDERRATIO',
        position: 18,
        description: 'Video Voltage Adjust',
        type: SettingsElementsType.range,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_VVoltage]
    },
    {
        id: 'S_THROTTLE_PWM',
        position: 19,
        description: 'Throttle display',
        type: SettingsElementsType.select,
        properties: {
            order: 6,
            max: 255,
            values: [
                'Display % value',
                'Display PWM value'
            ]
        },
        group: [SettingsElementsGroup.G_Display]
    },
    {
        id: 'S_AMPER_HOUR_ALARM',
        position: 20,
        description: 'mAh Alarm',
        type: SettingsElementsType.range,
        properties: {
            max: 255,
            divider: 0.01,
            step: 100
        },
        group: [SettingsElementsGroup.G_Amperage]
    },
    {
        id: 'S_AMPERAGE_ALARM',
        position: 21,
        description: 'Amp Alarm',
        type: SettingsElementsType.range,
        properties: {
            max: 255
        },
        group: [SettingsElementsGroup.G_Amperage]
    },
    {
        id: 'S_VARIO_SCALE',
        position: 22,
        description: 'VARIO indicator size',
        type: SettingsElementsType.select,
        properties: {
            order: 10,
            values: {
                1: "Single character",
                2: "Three rows high",
                3: "Five rows high",
                4: "Seven rows high",
                5: "Nine rows high"
            }
        },
        group: [SettingsElementsGroup.G_Display]
    },
    {
        id: 'S_GPS_MASK',
        position: 23,
        description: 'GPS display type',
        type: SettingsElementsType.select,
        group: [SettingsElementsGroup.G_Display],
        properties: {
            values: [
                'Display real co-ordinates',
                'Display with false major digits'
            ]
        },
    },
    {
        id: 'S_USEGPSHEADING',
        position: 24,
        description: 'FixedWing alt/heading (MSP FC only)',
        type: SettingsElementsType.select,
        properties: {
            values: [
                'Use BARO altitude, MAG heading',
                'Use BARO altitude, GPS heading',
                'Use GPS altitude, GPS heading'
            ]
        },
        group: [SettingsElementsGroup.G_Other]
    },
    {
        id: 'S_UNITSYSTEM',
        position: 25,
        description: 'Units Of Measure',
        type: SettingsElementsType.select,
        properties: {
            order: 3,
            values: [
                'Metric',
                'Imperial',
            ]
        },
        group: [SettingsElementsGroup.G_Display]
    },
    {
        id: 'S_VIDEOSIGNALTYPE',
        position: 26,
        description: 'Video Signal Type',
        type: SettingsElementsType.select,
        properties: {
            order: 2,
            values: [
                'NTSC',
                'PAL',
                'AUTO'
            ]
        },
        group: [SettingsElementsGroup.G_Other]
    },
    {
        id: 'S_SHOWBATLEVELEVOLUTION',
        position: 27,
        description: 'Main Battery Icon',
        type: SettingsElementsType.select,
        properties: {
            order: 5,
            values: [
                'Static battery icon',
                'Remaining capacity icon'
            ]
        },
        group: [SettingsElementsGroup.G_Voltage]
    },
    {
        id: 'S_RESETSTATISTICS',
        position: 28,
        description: 'Statistics',
        type: SettingsElementsType.select,
        properties: {
            order: 5,
            values: [
                'Show total flight',
                'Show since last armed'
            ]
        },
        group: [SettingsElementsGroup.G_Other]
    },
    {
        id: ' S_MAPMODE',
        position: 29,
        description: 'Map mode display type',
        type: SettingsElementsType.select,
        properties: {
            order: 14,
            values: [
                'Disabled',
                'Show home position',
                'Show aircraft position',
                'Show both positions',
                'Show aircraft position and direction'
            ]
        },
        group: [SettingsElementsGroup.G_Display]
    },
    {
        id: 'S_VREFERENCE',
        position: 30,
        description: 'Analog sensor reference',
        type: SettingsElementsType.select,
        properties: {
            order: 1,
            values: [
                '1.1v - 4s max',
                '5.0v - 6s or analog sensors'
            ]
        },
        group: [SettingsElementsGroup.G_Other]
    },
    {
        id: 'S_SIDEBARWIDTH,',
        position: 31,
        description: 'HUD sidebar width',
        type: SettingsElementsType.select,
        properties: {
            values: {
                3: "3",
                4: "4",
                5: "5",
                6: "6",
                7: "7",
                8: "8",
                9: "9",
                10: "10",
                11: "11",
                12: "12",
                13: "13",
                14: "14"
            }
        },
        group: [SettingsElementsGroup.G_HUD]
    },
   {
        id: 'S_GPSTIME',
        position: 32,
        description: 'Flight date & time',
        type: SettingsElementsType.select,
        properties: {
            values: {
                0: "Do not display",
                1: "Display at arming",
            }
        },
        group: [SettingsElementsGroup.G_Display]
    },
/*    {
        id: 'S_GPSTZAHEAD',
        position: 33,
        description: 'GPS head',
        type: SettingsElementsType.checkbox,
        properties: {},
        group: [SettingsElementsGroup.G_GPS]
    }, */
    {
        id: 'S_GPSTZ',                    
        position: 34,
        description: 'GPS time zone',
        type: SettingsElementsType.range,
        properties: {
            order: 20 ,
            min: -11 + 128,
            max: 14 + 128,
            translate: new TranslateSignedInt()
        },
        group: [SettingsElementsGroup.G_Display]
    }, 
    {
        id: 'S_VTX_POWER',
        position: 35,
        description: 'VTX Power',
        type: SettingsElementsType.select,
        properties: {
            values: [
                '50mW',
                '200mW',
                '600mW',
                '800mW'
            ]
        },
        group: [SettingsElementsGroup.G_VTX]
    },
    {
        id: 'S_VTX_BAND',
        position: 36,
        description: 'VTX Band',
        type: SettingsElementsType.select,
        properties: {
            values: [
                'A',
                'B',
                'E',
                'F',
                'C (Raceband)'
            ]
        },
        group: [SettingsElementsGroup.G_VTX]
    },
    {
        id: 'S_VTX_CHANNEL',
        position: 37,
        description: 'VTX Channel',
        type: SettingsElementsType.select,
        properties: {
            values: [
                'CH 1',
                'CH 2',
                'CH 3',
                'CH 4',
                'CH 5',
                'CH 6',
                'CH 7',
                'CH 8',
            ]},
        group: [SettingsElementsGroup.G_VTX]
    },
    {
        id: 'S_RCWSWITCH',
        position: 38,
        description: ['OSD Screen Switch'],
        type: SettingsElementsType.select,
        properties: {
            order: 1,
            values: [
                'Use Flight Controller OSD switch',
                'Use RC channel'
            ]
        },
        group: [SettingsElementsGroup.G_RCSWITCH]
    },
    {
        id: 'S_RCWSWITCH_CH',
        position: 39,
        description: 'Screen switch RC Channel',
        type: SettingsElementsType.select,
        properties: {
            values: {
                1: "1",
                2: "2",
                3: "3",
                4: "4",
                5: "5",
                6: "6",
                7: "7",
                8: "8",
                9: "9",
                10: "10",
                11: "11",
                12: "12",
                13: "13",
                15: "15",
                16: "16"
            }
        },
        group: [SettingsElementsGroup.G_RCSWITCH]
    },
    {
        id: 'S_DISTANCE_ALARM',
        position: 40,
        description: 'Distance Alarm',
        type: SettingsElementsType.range,
        properties: {
            max: 255,
            divider: 0.01,
            step: 100
        },
        group: [SettingsElementsGroup.G_Alarms]
    },
    {
        id: 'S_ALTITUDE_ALARM',
        position: 41,
        description: 'Altitude Alarm',
        type: SettingsElementsType.range,
        properties: {
            max: 255,
            divider: 0.01,
            step: 100
        },
        group: [SettingsElementsGroup.G_Alarms]
    },
    {
        id: 'S_SPEED_ALARM',
        position: 42,
        description: 'Speed Alarm',
        type: SettingsElementsType.range,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_Alarms]
    },
    {
        id: 'S_FLYTIME_ALARM',
        position: 43,
        description: 'Timer Alarm',
        type: SettingsElementsType.range,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_Alarms]
    },
    {
        id: 'S_AUDVARIO_DEADBAND',
        position: 44,
        description: 'Audio Vario deadband',
        type: SettingsElementsType.range,
        properties: {order: 11, max: 254},
        group: [SettingsElementsGroup.G_Custom]
    }, {
        id: 'S_AUDVARIO_TH_CUT',
        position: 45,
        description: 'Audio Vario throttle switch',
        type: SettingsElementsType.range,
        properties: {
            order: 12,
            min: 10,
            max: 20,
            step: 100,
            divider: 0.01
        },
        group: [SettingsElementsGroup.G_Custom]
    },
    {
        id: 'S_CS0',
        position: 46,
        description: 'S_CS0',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS1',
        position: 47,
        description: 'S_CS1',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS2',
        position: 48,
        description: 'S_CS2',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS3',
        position: 49,
        description: 'S_CS3',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS4',
        position: 50,
        description: 'S_CS4',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS5',
        position: 51,
        description: 'S_CS5',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS6',
        position: 52,
        description: 'S_CS6',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS7',
        position: 53,
        description: 'S_CS7',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS8',
        position: 54,
        description: 'S_CS8',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    }, {
        id: 'S_CS9',
        position: 55,
        description: 'S_CS9',
        type: SettingsElementsType.hidden,
        properties: {max: 255},
        group: [SettingsElementsGroup.G_CallSign]
    },{
        id: 'S_PWM_PPM',
        position: 56,
        description: 'GPS OSD - RC source type',
        type: SettingsElementsType.select,
        properties: {
            order: 9,
            values: [
                'PWM',
                'PPM'
            ]
        },
        group: [SettingsElementsGroup.G_GOSD]
    },{
        id: 'S_ELEVATIONS',
        position: 57,
        description: 'AHI minor elevations',
        type: SettingsElementsType.select,
        properties: {
            values: [
                'Disabled',
                'Enabled'
            ]
        },
        group: [SettingsElementsGroup.G_HUD]
    },{
        id: 'S_ALTRESOLUTION',
        position: 58,
        description: 'High resolution altitude display cutoff',
        type: SettingsElementsType.range,
        group: [SettingsElementsGroup.G_Display],
        properties: {max: 99},
    },{
        id: 'S_FLIGHTMODETEXT',
        position: 59,
        description: 'Flight mode display - MSP FC',
        type: SettingsElementsType.select,
        group: [SettingsElementsGroup.G_Display],
        properties: {
            values: [
                'Text Mode',
                'Icon mode'
            ]
        },
    },{
        id: 'S_BRIGHTNESS',
        position: 60,
        description: 'Brightness',
        type: SettingsElementsType.select,
        group: [SettingsElementsGroup.G_Display],
        properties: {
            values: {
                1 :'Default',
                0: 'High',
                10: 'Medium',
                15: 'Low',
            }
        },
    },{
        id: 'S_MAV_ALARM_LEVEL',
        position: 61,
        description: 'Mavlink alarms',
        type: SettingsElementsType.select,
        group: [SettingsElementsGroup.G_MAVLINK],
        properties: {
            order: 2,
            values: [
                'Emergency',
                'Alert',
                'Critical',
                'Error',
                'Warning',
                'Notice',
                'Info',
                'Debug',
            ]
        },
    },{
    id: 'S_MAV_AUTO',
        position: 64,
        description: 'Mavlink - autoconfigure serial port',
        type: SettingsElementsType.checkbox,
        group: [SettingsElementsGroup.G_MAVLINK],
        properties: {order: 3},
    },


    {
        id: 'S_AAT',
        position: 65,
        description: 'Automatic Antenna Tracker',
        type: SettingsElementsType.select,
        properties: {
            values: {
                0 :'Disabled',
                1: 'Enabled',
            }
        },
        group: [SettingsElementsGroup.G_Other]
    },
    {
        id: 'S_TIMER1',
        position: 66,
        description: 'Timer 1',
        type: SettingsElementsType.select,
        properties: {
            order: 1,
            values: {
                0 :' Dual on / fly time',
                1 : 'On time',
                2 : 'Fly time',
                3 : 'Time remaining',
            }
        },
        group: [SettingsElementsGroup.G_Display]
    },
    {
        id: 'S_TIMER2',
        position: 67,
        description: 'Timer 2',
        type: SettingsElementsType.select,
        properties: {
            order: 2,
            values: {
                0 :' Dual on / fly time',
                1 : 'On time',
                2 : 'Fly time',
                3 : 'Time remaining',
            }
        },
        group: [SettingsElementsGroup.G_Display]
    },
    {
        id: 'S_CUSTOME',
        position: 68,
        description: 'Custom development',
        type: SettingsElementsType.range,
        properties: {max: 255, min: 0},
        group: [SettingsElementsGroup.G_Other]
    },



    {
        id: 'S16_AMPZERO',
        position: 69,
        secondByte: 70,
        description: 'Amps Zero Adjust',
        type: SettingsElementsType.range,
        properties: {max: 1023},
        group: [SettingsElementsGroup.G_Amperage]
    },
    {
        id: ' S16_AMPDIVIDERRATIO',
        position: 71,
        secondByte: 72,
        description: 'Amps adjust',
        type: SettingsElementsType.range,
        properties: {max: 1023},
        group: [SettingsElementsGroup.G_Amperage]
    },
    {
        id: 'S16_RSSIMIN',
        position: 73,
        secondByte: 74,
        description: 'RSSI calibration Minimum',
        type: SettingsElementsType.range,
        properties: {max: 2601},
        group: [SettingsElementsGroup.G_RSSI]
    },
    {
        id: 'S16_RSSIMAX',
        position: 75,
        secondByte: 76,
        description: 'RSSI calibration Maximum',
        type: SettingsElementsType.range,
        properties: {
            order: 2,
            max: 2601
        },
        group: [SettingsElementsGroup.G_RSSI]
    },
    {
        id: 'S16_AIRSPEEDZERO',
        position: 77,
        secondByte: 78,
        description: 'AUX sensor Zero calibration',
        type: SettingsElementsType.range,
        properties: {max: 1023},
        group: [SettingsElementsGroup.G_Custom]
    },
    {
        id: 'S16_AIRSPEEDCAL',
        position: 79,
        secondByte: 80,
        description: 'AUX sensor calibration',
        type: SettingsElementsType.range,
        properties: {max: 1023},
        group: [SettingsElementsGroup.G_Custom]
    }
];

